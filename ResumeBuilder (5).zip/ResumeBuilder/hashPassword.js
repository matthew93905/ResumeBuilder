import crypto from 'crypto';
import { promisify } from 'util';

const scryptAsync = promisify(crypto.scrypt);

async function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const buf = await scryptAsync(password, salt, 64);
  const hashedPassword = `${buf.toString('hex')}.${salt}`;
  console.log('Hashed Password:', hashedPassword);
  return hashedPassword;
}

// Hash the password 'admin123'
hashPassword('admin123').catch(console.error);