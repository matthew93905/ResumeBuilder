import * as schema from "@shared/schema";
import { db } from "./db";
import { sql } from "drizzle-orm";

async function runMigration() {
  try {
    console.log("Running database migrations...");

    // Add isAdmin column to users table if it doesn't exist
    await db.execute(sql`
      DO $$ 
      BEGIN 
        IF NOT EXISTS (
          SELECT 1 
          FROM information_schema.columns 
          WHERE table_name = 'users' AND column_name = 'is_admin'
        ) THEN 
          ALTER TABLE users ADD COLUMN is_admin boolean DEFAULT false; 
        END IF; 
      END $$;
    `);

    // Create affiliate_clicks table if it doesn't exist
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS affiliate_clicks (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id),
        institution TEXT NOT NULL,
        is_affiliate BOOLEAN NOT NULL DEFAULT false,
        earned_credits BOOLEAN NOT NULL DEFAULT false,
        timestamp TIMESTAMP NOT NULL DEFAULT NOW()
      );
    `);

    // Drop existing analytics tables if they exist (in reverse order of dependency)
    await db.execute(sql`
      DROP TABLE IF EXISTS session_recordings;
      DROP TABLE IF EXISTS page_views;
      DROP TABLE IF EXISTS visitors;
    `);
    
    // Create visitors table 
    await db.execute(sql`
      CREATE TABLE visitors (
        id SERIAL PRIMARY KEY,
        visitor_id TEXT NOT NULL UNIQUE,
        user_id INTEGER REFERENCES users(id),
        user_agent TEXT NOT NULL,
        ip TEXT,
        country TEXT,
        city TEXT,
        region TEXT,
        os TEXT,
        browser TEXT,
        device TEXT,
        referrer TEXT,
        landing_page TEXT NOT NULL,
        first_visit TIMESTAMP NOT NULL DEFAULT NOW(),
        last_visit TIMESTAMP NOT NULL DEFAULT NOW(),
        visit_count INTEGER NOT NULL DEFAULT 1
      );
    `);

    // Create page_views table
    await db.execute(sql`
      CREATE TABLE page_views (
        id SERIAL PRIMARY KEY,
        visitor_id TEXT NOT NULL REFERENCES visitors(visitor_id),
        user_id INTEGER REFERENCES users(id),
        path TEXT NOT NULL,
        timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
        duration INTEGER,
        exit_page BOOLEAN DEFAULT false
      );
    `);

    // Create session_recordings table
    await db.execute(sql`
      CREATE TABLE session_recordings (
        id SERIAL PRIMARY KEY,
        visitor_id TEXT NOT NULL REFERENCES visitors(visitor_id),
        user_id INTEGER REFERENCES users(id),
        session_id TEXT NOT NULL UNIQUE,
        start_time TIMESTAMP NOT NULL DEFAULT NOW(),
        end_time TIMESTAMP,
        duration INTEGER,
        events JSONB NOT NULL,
        user_agent TEXT,
        device_type TEXT,
        country TEXT,
        city TEXT
      );
    `);

    console.log("Database migrations completed successfully");
  } catch (error) {
    console.error("Error running migrations:", error);
    throw error;
  }
}

// Run the migration
runMigration();