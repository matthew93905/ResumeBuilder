import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from 'ws';
import { storage } from "./storage";
import path from "path";
import express from "express";
import { z } from "zod";
import { 
  insertResumeSchema, 
  insertCollaboratorSchema, 
  insertCommentSchema, 
  insertInvitationSchema,
  affiliateClicks,
  users
} from "@shared/schema";
import { desc, eq } from 'drizzle-orm';
import { db } from "./db";
import Stripe from "stripe";
import { setupAuth } from "./auth";
import { 
  enhanceSummary, 
  enhanceJobDescriptions, 
  suggestSkills, 
  analyzeResume, 
  generateCareerPathRecommendations,
  generateCareerTrendInsights,
  CareerPathOption,
  CareerTrendReport
} from "./ai";
import { createPaypalOrder, capturePaypalOrder, loadPaypalDefault } from "./paypal";
import geoip from "geoip-lite";
import crypto from "crypto";

let stripe: Stripe | null = null;
if (process.env.STRIPE_SECRET_KEY) {
  stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
    apiVersion: '2025-04-30.basil' as any
  });
}

// Validates request body against schema
function validateRequestBody<T>(schema: z.ZodType<T>) {
  return (req: Request, res: Response, next: Function) => {
    try {
      const result = schema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ errors: result.error.errors });
      }
      next();
    } catch (error) {
      console.error("Validation error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication
  setupAuth(app);
  
  // Health check route
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', database: 'connected' });
  });
  
  // Define middleware first
  // Auth check middleware for protected routes
  const requireAuth = (req: Request, res: Response, next: Function) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "Authentication required" });
    }
    next();
  };
  
  // Admin check middleware
  const requireAdmin = (req: Request, res: Response, next: Function) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "Not authenticated" });
    }
    
    if (!req.user!.isAdmin) {
      return res.status(403).json({ error: "Admin access required" });
    }
    
    next();
  };
  
  // Owner check middleware for resume operations
  const checkResumeOwnership = async (req: Request, res: Response, next: Function) => {
    try {
      const resumeId = parseInt(req.params.id);
      if (isNaN(resumeId)) {
        return res.status(400).json({ error: "Invalid resume ID" });
      }
      
      const resume = await storage.getResume(resumeId);
      if (!resume) {
        return res.status(404).json({ error: "Resume not found" });
      }
      
      // Check if the authenticated user owns this resume
      if (resume.userId !== req.user!.id) {
        return res.status(403).json({ error: "You don't have permission to access this resume" });
      }
      
      next();
    } catch (error) {
      console.error("Error checking resume ownership:", error);
      res.status(500).json({ error: "Server error" });
    }
  };
  
  // Middleware to check if user has access to resume (either owner or collaborator)
  const checkResumeAccess = async (req: Request, res: Response, next: Function) => {
    try {
      const resumeId = parseInt(req.params.id);
      if (isNaN(resumeId)) {
        return res.status(400).json({ error: "Invalid resume ID" });
      }
      
      const resume = await storage.getResume(resumeId);
      if (!resume) {
        return res.status(404).json({ error: "Resume not found" });
      }
      
      // Public resumes are accessible to everyone
      if (resume.isPublic) {
        return next();
      }
      
      // Check if a valid shareable link is being used
      const shareLink = req.query.shareableLink as string;
      if (shareLink && resume.shareableLink === shareLink) {
        return next();
      }
      
      // If not public or shared, user must be authenticated
      if (!req.isAuthenticated()) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      // Owner has access
      if (resume.userId === req.user!.id) {
        return next();
      }
      
      // Check if user is a collaborator
      const collaborator = await storage.getCollaboratorByResumeAndUser(resumeId, req.user!.id);
      if (!collaborator) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      // Add role to the request for use in handlers
      (req as any).collaboratorRole = collaborator.role;
      
      next();
    } catch (error) {
      console.error("Error checking resume access:", error);
      res.status(500).json({ error: "Server error" });
    }
  };
  
  // Helper functions for parsing user agent
  function parseOS(userAgent: string): string {
    // Simple parsing logic - could be improved with a more robust library
    if (/windows/i.test(userAgent)) return 'Windows';
    if (/macintosh|mac os x/i.test(userAgent)) return 'macOS';
    if (/linux/i.test(userAgent)) return 'Linux';
    if (/android/i.test(userAgent)) return 'Android';
    if (/iphone|ipad|ipod/i.test(userAgent)) return 'iOS';
    return 'Unknown';
  }
  
  function parseBrowser(userAgent: string): string {
    // Simple parsing logic
    if (/chrome/i.test(userAgent) && !/edge|opr|chromium/i.test(userAgent)) return 'Chrome';
    if (/firefox/i.test(userAgent)) return 'Firefox';
    if (/safari/i.test(userAgent) && !/chrome|chromium/i.test(userAgent)) return 'Safari';
    if (/edge/i.test(userAgent)) return 'Edge';
    if (/opr/i.test(userAgent) || /opera/i.test(userAgent)) return 'Opera';
    if (/msie|trident/i.test(userAgent)) return 'Internet Explorer';
    return 'Unknown';
  }
  
  function parseDevice(userAgent: string): string {
    // Simple parsing logic
    if (/mobile/i.test(userAgent)) return 'Mobile';
    if (/tablet/i.test(userAgent)) return 'Tablet';
    if (/iPad|iPod|iPhone/i.test(userAgent)) return 'iOS Device';
    return 'Desktop';
  }
  
  //
  // Analytics routes
  //
  
  // Track visitor
  app.post("/api/analytics/track", async (req, res) => {
    try {
      const { visitorId, referrer, path } = req.body;
      
      if (!visitorId) {
        return res.status(400).json({ error: "Visitor ID is required" });
      }
      
      // Get IP address
      const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
      const userAgent = req.headers['user-agent'] || '';
      
      // Get location data using geoip-lite
      const geo = ip ? geoip.lookup(ip.toString()) : null;
      
      // Check if visitor exists
      let visitor = await storage.getVisitorByVisitorId(visitorId);
      
      if (!visitor) {
        // Create new visitor
        visitor = await storage.createOrUpdateVisitor({
          visitorId,
          userAgent,
          ip: ip?.toString(),
          country: geo?.country,
          city: geo?.city,
          region: geo?.region,
          os: parseOS(userAgent),
          browser: parseBrowser(userAgent),
          device: parseDevice(userAgent),
          referrer,
          landingPage: path || '/',
          userId: req.isAuthenticated() ? req.user!.id : undefined,
          firstVisit: new Date(),
          lastVisit: new Date(),
          visitCount: 1
        });
      } else {
        // Update existing visitor
        visitor = await storage.createOrUpdateVisitor({
          ...visitor,
          visitorId,
          userAgent,
          ip: ip?.toString(),
          country: geo?.country,
          city: geo?.city,
          region: geo?.region,
          os: parseOS(userAgent),
          browser: parseBrowser(userAgent),
          device: parseDevice(userAgent),
          referrer,
          lastVisit: new Date(),
          userId: req.isAuthenticated() ? req.user!.id : undefined,
          visitCount: visitor.visitCount + 1
        });
      }
      
      // Create page view
      if (path) {
        await storage.createPageView({
          visitorId,
          userId: req.isAuthenticated() ? req.user!.id : undefined,
          path,
          timestamp: new Date(),
          duration: null, // Will be updated when the user navigates away
          exitPage: false
        });
      }
      
      res.status(200).json({ success: true });
    } catch (error) {
      console.error("Error tracking visitor:", error);
      res.status(500).json({ error: "Failed to track visitor" });
    }
  });
  
  // Record page view with duration
  app.post("/api/analytics/page-view", async (req, res) => {
    try {
      const { visitorId, path, duration, exitPage } = req.body;
      
      if (!visitorId || !path) {
        return res.status(400).json({ error: "Visitor ID and path are required" });
      }
      
      const pageView = await storage.createPageView({
        visitorId,
        userId: req.isAuthenticated() ? req.user!.id : undefined,
        path,
        timestamp: new Date(),
        duration: duration || null,
        exitPage: exitPage || false
      });
      
      res.status(200).json({ success: true, pageView });
    } catch (error) {
      console.error("Error recording page view:", error);
      res.status(500).json({ error: "Failed to record page view" });
    }
  });
  
  // Store session recording
  app.post("/api/analytics/record-session", async (req, res) => {
    try {
      const { visitorId, sessionId, events } = req.body;
      
      if (!visitorId || !sessionId || !events) {
        return res.status(400).json({ error: "Visitor ID, session ID, and events are required" });
      }
      
      // Get IP address and user agent
      const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
      const userAgent = req.headers['user-agent'] || '';
      
      // Get location data using geoip-lite
      const geo = ip ? geoip.lookup(ip.toString()) : null;
      
      const recording = await storage.createSessionRecording({
        visitorId,
        userId: req.isAuthenticated() ? req.user!.id : undefined,
        sessionId,
        startTime: new Date(),
        endTime: null,
        duration: null,
        events,
        userAgent: userAgent,
        deviceType: parseDevice(userAgent),
        country: geo?.country,
        city: geo?.city
      });
      
      res.status(200).json({ success: true, recordingId: recording.id });
    } catch (error) {
      console.error("Error recording session:", error);
      res.status(500).json({ error: "Failed to record session" });
    }
  });
  
  // Admin analytics routes

  // Get visitor statistics
  app.get("/api/admin/analytics/visitors", requireAdmin, async (req, res) => {
    try {
      const statistics = await storage.getVisitorStatistics();
      res.json(statistics);
    } catch (error) {
      console.error("Error fetching visitor statistics:", error);
      res.status(500).json({ error: "Failed to fetch visitor statistics" });
    }
  });
  
  // Get page view statistics
  app.get("/api/admin/analytics/pageviews", requireAdmin, async (req, res) => {
    try {
      const statistics = await storage.getPageViewStatistics();
      res.json(statistics);
    } catch (error) {
      console.error("Error fetching page view statistics:", error);
      res.status(500).json({ error: "Failed to fetch page view statistics" });
    }
  });
  
  // Get visitors by day for last n days
  app.get("/api/admin/analytics/visitors-by-day", requireAdmin, async (req, res) => {
    try {
      const days = Number(req.query.days) || 30;
      const visitorsByDay = await storage.getVisitorsByDay(days);
      res.json(visitorsByDay);
    } catch (error) {
      console.error("Error fetching visitors by day:", error);
      res.status(500).json({ error: "Failed to fetch visitors by day" });
    }
  });
  
  // Get all visitors
  app.get("/api/admin/analytics/visitors-list", requireAdmin, async (req, res) => {
    try {
      const limit = Number(req.query.limit) || 100;
      const offset = Number(req.query.offset) || 0;
      const visitors = await storage.getAllVisitors(limit, offset);
      res.json(visitors);
    } catch (error) {
      console.error("Error fetching visitors list:", error);
      res.status(500).json({ error: "Failed to fetch visitors list" });
    }
  });
  
  // Get visitors from specific location
  app.get("/api/admin/analytics/visitors-by-location", requireAdmin, async (req, res) => {
    try {
      const { country, region, city } = req.query;
      const visitors = await storage.getVisitorsByLocation(
        country as string, 
        region as string, 
        city as string
      );
      res.json(visitors);
    } catch (error) {
      console.error("Error fetching visitors by location:", error);
      res.status(500).json({ error: "Failed to fetch visitors by location" });
    }
  });
  
  // Get most viewed pages
  app.get("/api/admin/analytics/most-viewed-pages", requireAdmin, async (req, res) => {
    try {
      const limit = Number(req.query.limit) || 10;
      const pages = await storage.getMostViewedPages(limit);
      res.json(pages);
    } catch (error) {
      console.error("Error fetching most viewed pages:", error);
      res.status(500).json({ error: "Failed to fetch most viewed pages" });
    }
  });
  
  // Get all session recordings
  app.get("/api/admin/analytics/session-recordings", requireAdmin, async (req, res) => {
    try {
      const limit = Number(req.query.limit) || 100;
      const offset = Number(req.query.offset) || 0;
      const recordings = await storage.getAllSessionRecordings(limit, offset);
      res.json(recordings);
    } catch (error) {
      console.error("Error fetching session recordings:", error);
      res.status(500).json({ error: "Failed to fetch session recordings" });
    }
  });
  
  // Get a specific session recording
  app.get("/api/admin/analytics/session-recordings/:id", requireAdmin, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const recording = await storage.getSessionRecording(id);
      
      if (!recording) {
        return res.status(404).json({ error: "Session recording not found" });
      }
      
      res.json(recording);
    } catch (error) {
      console.error("Error fetching session recording:", error);
      res.status(500).json({ error: "Failed to fetch session recording" });
    }
  });
  
  //
  // AI Enhancement routes
  //
  
  // Enhance resume summary
  app.post('/api/ai/enhance-summary', requireAuth, async (req, res) => {
    try {
      const { summary, context } = req.body;
      
      if (!summary) {
        return res.status(400).json({ error: "Summary text is required" });
      }
      
      const enhancedSummary = await enhanceSummary(summary, context);
      res.json({ enhancedSummary });
    } catch (error) {
      console.error("Error enhancing summary:", error);
      res.status(500).json({ error: "Failed to enhance summary" });
    }
  });
  
  // Enhance job descriptions
  app.post('/api/ai/enhance-job-descriptions', requireAuth, async (req, res) => {
    try {
      const { descriptions, jobTitle } = req.body;
      
      if (!descriptions || !Array.isArray(descriptions)) {
        return res.status(400).json({ error: "Descriptions must be an array" });
      }
      
      if (!jobTitle) {
        return res.status(400).json({ error: "Job title is required" });
      }
      
      const enhancedDescriptions = await enhanceJobDescriptions(descriptions, jobTitle);
      res.json({ enhancedDescriptions });
    } catch (error) {
      console.error("Error enhancing job descriptions:", error);
      res.status(500).json({ error: "Failed to enhance job descriptions" });
    }
  });
  
  // Suggest relevant skills
  app.post('/api/ai/suggest-skills', requireAuth, async (req, res) => {
    try {
      const { jobTitle, industry, existingSkills } = req.body;
      
      if (!jobTitle) {
        return res.status(400).json({ error: "Job title is required" });
      }
      
      const suggestedSkills = await suggestSkills(jobTitle, industry, existingSkills);
      res.json({ suggestedSkills });
    } catch (error) {
      console.error("Error suggesting skills:", error);
      res.status(500).json({ error: "Failed to suggest skills" });
    }
  });
  
  // Analyze entire resume
  app.post('/api/ai/analyze-resume', requireAuth, async (req, res) => {
    try {
      const { resumeData } = req.body;
      
      if (!resumeData) {
        return res.status(400).json({ error: "Resume data is required" });
      }
      
      const analysis = await analyzeResume(resumeData);
      res.json({ analysis });
    } catch (error) {
      console.error("Error analyzing resume:", error);
      res.status(500).json({ error: "Failed to analyze resume" });
    }
  });
  
  // Generate career trend insights
  app.post('/api/ai/career-trends', requireAuth, async (req, res) => {
    try {
      const { industry, skills, jobTitle, location } = req.body;
      
      if (!industry) {
        return res.status(400).json({ error: "Industry is required" });
      }
      
      if (!skills || !Array.isArray(skills)) {
        return res.status(400).json({ error: "Skills must be an array" });
      }
      
      if (!jobTitle) {
        return res.status(400).json({ error: "Job title is required" });
      }
      
      const trendReport = await generateCareerTrendInsights(industry, skills, jobTitle, location);
      res.json(trendReport);
    } catch (error) {
      console.error("Error generating career trend insights:", error);
      res.status(500).json({ error: "Failed to generate career trend insights" });
    }
  });
  
  // Generate career path visualization data
  app.post('/api/ai/career-paths', requireAuth, async (req, res) => {
    try {
      const { currentRole, yearsOfExperience, skills, interests, educationLevel, industry, location } = req.body;
      
      // For this feature, we're not going to call the AI API, instead we'll return a success message
      // that matches the component's expectations. The visualization component uses static data.
      
      res.json({
        success: true,
        message: "Career path visualization data loaded"
      });
    } catch (error) {
      console.error("Error fetching career path data:", error);
      res.status(500).json({ error: "Failed to fetch career path data" });
    }
  });
  
  // Get affiliate marketing analytics for admin
  app.get('/api/admin/affiliate-analytics', requireAdmin, async (req, res) => {
    try {
      // Get total clicks
      const totalClicksResult = await db.select({ count: sql`COUNT(*)` })
        .from(affiliateClicks);
      const totalClicks = Number(totalClicksResult[0].count);
      
      // Get affiliate clicks
      const affiliateClicksResult = await db.select({ count: sql`COUNT(*)` })
        .from(affiliateClicks)
        .where(eq(affiliateClicks.isAffiliate, true));
      const affiliateClicksCount = Number(affiliateClicksResult[0].count);
      
      // Calculate conversion rate
      const conversionRate = totalClicks > 0 ? (affiliateClicksCount / totalClicks) * 100 : 0;
      
      // Get top institutions
      const topInstitutionsResult = await db.select({
        name: affiliateClicks.institution,
        count: sql<number>`COUNT(*)`.as('count')
      })
      .from(affiliateClicks)
      .groupBy(affiliateClicks.institution)
      .orderBy(desc(affiliateClicks.count))
      .limit(5);
      
      const topInstitutions = topInstitutionsResult.map(row => ({
        name: row.name,
        count: Number(row.count)
      }));
      
      // Get recent clicks
      const recentClicksQueryResult = await db.select({
        id: affiliateClicks.id,
        institution: affiliateClicks.institution,
        isAffiliate: affiliateClicks.isAffiliate,
        earnedCredits: affiliateClicks.earnedCredits,
        timestamp: affiliateClicks.timestamp,
        userId: affiliateClicks.userId
      })
      .from(affiliateClicks)
      .orderBy(desc(affiliateClicks.timestamp))
      .limit(10);
      
      // Get usernames for the clicks
      const recentClicks = await Promise.all(
        recentClicksQueryResult.map(async (click) => {
          let username = "Anonymous";
          if (click.userId) {
            const user = await storage.getUser(click.userId);
            if (user) {
              username = user.username;
            }
          }
          
          return {
            id: click.id,
            institution: click.institution,
            isAffiliate: click.isAffiliate,
            earnedCredits: click.earnedCredits,
            timestamp: click.timestamp.toISOString(),
            username
          };
        })
      );
      
      res.json({
        totalClicks,
        affiliateClicks: affiliateClicksCount,
        conversionRate,
        topInstitutions,
        recentClicks
      });
    } catch (error) {
      console.error("Error fetching affiliate analytics:", error);
      res.status(500).json({ error: "Failed to fetch affiliate analytics" });
    }
  });

  // Payment routes
  // Stripe payment route
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      if (!stripe) {
        return res.status(500).json({ error: "Stripe is not configured" });
      }
      
      const { amount } = req.body;
      
      if (!amount || isNaN(parseFloat(amount)) || parseFloat(amount) <= 0) {
        return res.status(400).json({ error: "Invalid amount" });
      }
      
      // Create a payment intent with the order amount and currency
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(parseFloat(amount) * 100), // Convert to cents
        currency: "usd",
        automatic_payment_methods: {
          enabled: true,
        },
      });
      
      res.json({
        clientSecret: paymentIntent.client_secret,
      });
    } catch (error: any) {
      console.error("Error creating payment intent:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Get or create subscription with Stripe
  app.post("/api/get-or-create-subscription", requireAuth, async (req, res) => {
    try {
      if (!stripe) {
        return res.status(500).json({ error: "Stripe is not configured" });
      }
      
      // Get user from request
      const user = req.user!;
      
      // If user already has a subscription, return it
      if (user.stripeSubscriptionId) {
        const subscription = await stripe.subscriptions.retrieve(user.stripeSubscriptionId);
        
        return res.json({
          subscriptionId: subscription.id,
          clientSecret: subscription.latest_invoice?.payment_intent?.client_secret,
        });
      }
      
      // Create a new customer if the user doesn't have one
      let customerId = user.stripeCustomerId;
      
      if (!customerId) {
        const customer = await stripe.customers.create({
          email: user.email,
          name: user.username,
        });
        
        customerId = customer.id;
        
        // Update user with customer ID
        await db
          .update(users)
          .set({ stripeCustomerId: customerId })
          .where(eq(users.id, user.id));
      }
      
      // Create subscription
      const subscription = await stripe.subscriptions.create({
        customer: customerId,
        items: [{
          price: process.env.STRIPE_PRICE_ID || 'price_1NsKb8LkdIwHu7ixLfIVsEiz', // Default to a test price ID
        }],
        payment_behavior: 'default_incomplete',
        expand: ['latest_invoice.payment_intent'],
      });
      
      // Update user with subscription ID
      await db
        .update(users)
        .set({ 
          stripeSubscriptionId: subscription.id,
          isPremium: true
        })
        .where(eq(users.id, user.id));
      
      res.json({
        subscriptionId: subscription.id,
        clientSecret: (subscription.latest_invoice as any)?.payment_intent?.client_secret,
      });
    } catch (error: any) {
      console.error("Error creating subscription:", error);
      res.status(500).json({ error: error.message });
    }
  });
  
  // PayPal routes
  app.get("/api/paypal/setup", async (req, res) => {
    await loadPaypalDefault(req, res);
  });

  app.post("/api/paypal/order", async (req, res) => {
    await createPaypalOrder(req, res);
  });

  app.post("/api/paypal/order/:orderID/capture", async (req, res) => {
    await capturePaypalOrder(req, res);
  });

  // Resume comments endpoints
  app.get("/api/resume/:id/comments", requireAuth, checkResumeAccess, async (req, res) => {
    try {
      const resumeId = parseInt(req.params.id);
      const comments = await storage.getComments(resumeId);
      
      // Fetch user information for each comment
      const commentsWithUsers = await Promise.all(
        comments.map(async (comment) => {
          const user = await storage.getUser(comment.userId);
          return {
            ...comment,
            user: {
              id: user?.id || 0,
              username: user?.username || 'Unknown',
              fullName: user?.fullName || null,
            }
          };
        })
      );
      
      res.json(commentsWithUsers);
    } catch (error) {
      console.error("Error fetching comments:", error);
      res.status(500).json({ error: "Failed to fetch comments" });
    }
  });

  app.post("/api/resume/:id/comments", requireAuth, checkResumeAccess, async (req, res) => {
    try {
      const { content, section } = req.body;
      if (!content) {
        return res.status(400).json({ error: "Comment content is required" });
      }
      
      const resumeId = parseInt(req.params.id);
      const comment = await storage.createComment({
        resumeId,
        userId: req.user!.id,
        content,
        section,
        resolved: false
      });
      
      // Get user data to include in response
      const user = await storage.getUser(req.user!.id);
      const commentWithUser = {
        ...comment,
        user: {
          id: user?.id || 0,
          username: user?.username || 'Unknown',
          fullName: user?.fullName || null,
        }
      };
      
      // Create a notification for resume owner and collaborators
      const resume = await storage.getResume(resumeId);
      if (resume && resume.userId !== req.user!.id) {
        await storage.createNotification({
          userId: resume.userId,
          type: 'comment',
          content: `${req.user!.username} commented on your resume: "${content.substring(0, 50)}${content.length > 50 ? '...' : ''}"`,
          relatedId: comment.id
        });
      }
      
      // Notify other collaborators
      const collaborators = await storage.getCollaborators(resumeId);
      for (const collaborator of collaborators) {
        if (collaborator.userId !== req.user!.id && collaborator.userId !== resume?.userId) {
          await storage.createNotification({
            userId: collaborator.userId,
            type: 'comment',
            content: `${req.user!.username} commented on a resume you're collaborating on: "${content.substring(0, 50)}${content.length > 50 ? '...' : ''}"`,
            relatedId: comment.id
          });
        }
      }
      
      res.status(201).json(commentWithUser);
    } catch (error) {
      console.error("Error creating comment:", error);
      res.status(500).json({ error: "Failed to create comment" });
    }
  });

  app.patch("/api/resume/:resumeId/comments/:commentId", requireAuth, async (req, res) => {
    try {
      const commentId = parseInt(req.params.commentId);
      const { resolved } = req.body;
      
      if (resolved === undefined) {
        return res.status(400).json({ error: "Resolved status is required" });
      }
      
      // Check if user has permission to resolve this comment
      const comment = await storage.getComment(commentId);
      
      if (!comment) {
        return res.status(404).json({ error: "Comment not found" });
      }
      
      const resumeId = parseInt(req.params.resumeId);
      const resume = await storage.getResume(resumeId);
      
      if (!resume) {
        return res.status(404).json({ error: "Resume not found" });
      }
      
      // Allow comment owner or resume owner to resolve/unresolve
      const isCommentOwner = comment.userId === req.user!.id;
      const isResumeOwner = resume.userId === req.user!.id;
      
      // Also check if user is an editor collaborator
      const collaborators = await storage.getCollaborators(resumeId);
      const collaborator = collaborators.find(c => c.userId === req.user!.id);
      const isEditor = collaborator && collaborator.role === 'editor';
      
      if (!isCommentOwner && !isResumeOwner && !isEditor) {
        return res.status(403).json({ error: "You don't have permission to update this comment" });
      }
      
      const updatedComment = await storage.resolveComment(commentId, resolved);
      
      if (!updatedComment) {
        return res.status(500).json({ error: "Failed to update comment" });
      }
      
      // Get user data to include in response
      const user = await storage.getUser(updatedComment.userId);
      const commentWithUser = {
        ...updatedComment,
        user: {
          id: user?.id || 0,
          username: user?.username || 'Unknown',
          fullName: user?.fullName || null,
        }
      };
      
      res.json(commentWithUser);
    } catch (error) {
      console.error("Error updating comment:", error);
      res.status(500).json({ error: "Failed to update comment" });
    }
  });

  app.delete("/api/resume/:resumeId/comments/:commentId", requireAuth, async (req, res) => {
    try {
      const commentId = parseInt(req.params.commentId);
      const resumeId = parseInt(req.params.resumeId);
      
      // Check if user has permission to delete this comment
      const comment = await storage.getComment(commentId);
      
      if (!comment) {
        return res.status(404).json({ error: "Comment not found" });
      }
      
      const resume = await storage.getResume(resumeId);
      
      if (!resume) {
        return res.status(404).json({ error: "Resume not found" });
      }
      
      const isCommentOwner = comment.userId === req.user!.id;
      const isResumeOwner = resume.userId === req.user!.id;
      
      if (!isCommentOwner && !isResumeOwner) {
        return res.status(403).json({ error: "You don't have permission to delete this comment" });
      }
      
      const success = await storage.deleteComment(commentId);
      
      if (!success) {
        return res.status(500).json({ error: "Failed to delete comment" });
      }
      
      res.sendStatus(204);
    } catch (error) {
      console.error("Error deleting comment:", error);
      res.status(500).json({ error: "Failed to delete comment" });
    }
  });

  // Collaboration invitation endpoints
  app.post("/api/resume/:id/invite", requireAuth, checkResumeOwnership, async (req, res) => {
    try {
      const { email, role } = req.body;
      if (!email) {
        return res.status(400).json({ error: "Email is required" });
      }
      
      if (!['viewer', 'editor'].includes(role)) {
        return res.status(400).json({ error: "Invalid role. Must be 'viewer' or 'editor'" });
      }
      
      const resumeId = parseInt(req.params.id);
      
      // Check if user with this email already exists
      const existingUser = await storage.getUserByEmail(email);
      
      // Check if there's already an active invitation for this email and resume
      const pendingInvitations = await storage.getPendingInvitationsByEmail(email);
      const existingInvitation = pendingInvitations.find(inv => inv.resumeId === resumeId);
      
      if (existingInvitation) {
        return res.status(400).json({ error: "An invitation has already been sent to this email" });
      }
      
      // If user exists, check if they're already a collaborator
      if (existingUser) {
        const collaborators = await storage.getCollaborators(resumeId);
        const isAlreadyCollaborator = collaborators.some(c => c.userId === existingUser.id);
        
        if (isAlreadyCollaborator) {
          return res.status(400).json({ error: "This user is already a collaborator" });
        }
      }
      
      // Generate a unique token
      const token = crypto.randomBytes(32).toString('hex');
      
      // Set expiration date (48 hours from now)
      const expiresAt = new Date();
      expiresAt.setHours(expiresAt.getHours() + 48);
      
      // Create the invitation
      const invitation = await storage.createInvitation({
        resumeId,
        invitedByUserId: req.user!.id,
        email,
        role,
        token,
        expiresAt,
      });
      
      // TODO: Send email to the invited user (would use a service like SendGrid here)
      
      res.status(201).json({ success: true, message: `Invitation sent to ${email}` });
    } catch (error) {
      console.error("Error sending invitation:", error);
      res.status(500).json({ error: "Failed to send invitation" });
    }
  });

  app.get("/api/invitations", requireAuth, async (req, res) => {
    try {
      // Find invitations for the authenticated user's email
      const pendingInvitations = await storage.getPendingInvitationsByEmail(req.user!.email);
      
      // Enhance with resume and inviter information
      const enhancedInvitations = await Promise.all(
        pendingInvitations.map(async (invitation) => {
          const resume = await storage.getResume(invitation.resumeId);
          const inviter = await storage.getUser(invitation.invitedByUserId);
          
          return {
            ...invitation,
            resumeTitle: resume?.title || 'Unknown Resume',
            inviterName: inviter?.username || 'Unknown User'
          };
        })
      );
      
      res.json(enhancedInvitations);
    } catch (error) {
      console.error("Error fetching invitations:", error);
      res.status(500).json({ error: "Failed to fetch invitations" });
    }
  });

  app.post("/api/invitations/:token/accept", requireAuth, async (req, res) => {
    try {
      const { token } = req.params;
      
      // Find the invitation
      const invitation = await storage.getInvitationByToken(token);
      
      if (!invitation) {
        return res.status(404).json({ error: "Invitation not found" });
      }
      
      if (invitation.accepted) {
        return res.status(400).json({ error: "Invitation has already been accepted" });
      }
      
      if (new Date(invitation.expiresAt) < new Date()) {
        return res.status(400).json({ error: "Invitation has expired" });
      }
      
      // Verify that the current user's email matches the invitation
      if (invitation.email !== req.user!.email) {
        return res.status(403).json({ error: "This invitation is not for your account" });
      }
      
      // Check if user is already a collaborator
      const collaborators = await storage.getCollaborators(invitation.resumeId);
      const isAlreadyCollaborator = collaborators.some(c => c.userId === req.user!.id);
      
      if (isAlreadyCollaborator) {
        return res.status(400).json({ error: "You are already a collaborator on this resume" });
      }
      
      // Accept the invitation
      const success = await storage.acceptInvitation(token, req.user!.id);
      
      if (!success) {
        return res.status(500).json({ error: "Failed to accept invitation" });
      }
      
      // Add the user as a collaborator
      const collaborator = await storage.addCollaborator({
        resumeId: invitation.resumeId,
        userId: req.user!.id,
        role: invitation.role
      });
      
      // Create a notification for the resume owner
      const resume = await storage.getResume(invitation.resumeId);
      if (resume) {
        await storage.createNotification({
          userId: resume.userId,
          type: 'collaboration',
          content: `${req.user!.username} accepted your invitation to collaborate on "${resume.title}"`,
          relatedId: collaborator.id
        });
      }
      
      res.json({ success: true, message: "Invitation accepted", resumeId: invitation.resumeId });
    } catch (error) {
      console.error("Error accepting invitation:", error);
      res.status(500).json({ error: "Failed to accept invitation" });
    }
  });

  // Create an HTTP server from our Express app
  const httpServer = createServer(app);
  
  // Set up WebSocket server for collaborative editing
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Simple protocol for collaborative editing
  type ClientConnection = {
    socket: WebSocket;
    userId: number;
    resumeId: number;
    role: string;
    username: string;
  };
  
  const clients: ClientConnection[] = [];
  
  wss.on('connection', async (ws) => {
    console.log('WebSocket client connected');
    let clientConnection: ClientConnection | null = null;
    
    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        if (data.type === 'auth') {
          // Authenticate the WebSocket connection
          const { userId, resumeId, token } = data;
          
          if (!userId || !resumeId) {
            ws.send(JSON.stringify({ 
              type: 'error', 
              message: 'Missing required fields' 
            }));
            return;
          }
          
          // Check if user exists
          const user = await storage.getUser(userId);
          if (!user) {
            ws.send(JSON.stringify({ 
              type: 'error', 
              message: 'User not found' 
            }));
            return;
          }
          
          // Check if resume exists
          const resume = await storage.getResume(resumeId);
          if (!resume) {
            ws.send(JSON.stringify({ 
              type: 'error', 
              message: 'Resume not found' 
            }));
            return;
          }
          
          // Determine the user's role
          let role = 'viewer';
          
          if (resume.userId === userId) {
            role = 'owner';
          } else {
            // Check if user is a collaborator
            const collaborators = await storage.getCollaborators(resumeId);
            const collaborator = collaborators.find(c => c.userId === userId);
            if (collaborator) {
              role = collaborator.role;
            } else if (token && token === resume.shareableLink) {
              // Valid share link
              role = 'viewer';
            } else {
              ws.send(JSON.stringify({ 
                type: 'error', 
                message: 'Access denied' 
              }));
              return;
            }
          }
          
          // Store client connection details
          clientConnection = {
            socket: ws,
            userId,
            resumeId,
            role,
            username: user.username
          };
          
          clients.push(clientConnection);
          
          // Send confirmation
          ws.send(JSON.stringify({
            type: 'auth_success',
            role,
            resumeId,
            message: 'Successfully connected'
          }));
          
          // Notify other clients about new collaborator
          broadcastToResumeClients(
            resumeId, 
            {
              type: 'collaborator_joined',
              userId,
              username: user.username,
              role
            },
            userId // Exclude the sender
          );
          
          // Send the list of active collaborators
          ws.send(JSON.stringify({
            type: 'collaborators',
            collaborators: getActiveCollaborators(resumeId)
          }));
        }
        else if (data.type === 'update') {
          // Handle resume update
          if (!clientConnection) {
            ws.send(JSON.stringify({ 
              type: 'error', 
              message: 'Not authenticated' 
            }));
            return;
          }
          
          if (clientConnection.role !== 'owner' && clientConnection.role !== 'editor') {
            ws.send(JSON.stringify({ 
              type: 'error', 
              message: 'You do not have permission to edit this resume' 
            }));
            return;
          }
          
          const { resumeId, changes } = data;
          
          // Update the resume in the database
          await storage.updateResume(resumeId, { data: changes });
          
          // Broadcast the changes to other clients
          broadcastToResumeClients(
            resumeId,
            {
              type: 'update',
              changes,
              username: clientConnection.username
            },
            clientConnection.userId
          );
        }
        else if (data.type === 'comment') {
          // Handle adding a comment
          if (!clientConnection) {
            ws.send(JSON.stringify({ 
              type: 'error', 
              message: 'Not authenticated' 
            }));
            return;
          }
          
          const { resumeId, content, section } = data;
          
          // Create the comment in the database
          const comment = await storage.createComment({
            resumeId,
            userId: clientConnection.userId,
            content,
            section,
            resolved: false
          });
          
          // Get the user details
          const user = await storage.getUser(comment.userId);
          
          // Broadcast the comment to all clients
          broadcastToResumeClients(
            resumeId,
            {
              type: 'comment',
              comment: {
                ...comment,
                username: user?.username
              }
            }
          );
          
          // Create a notification for the resume owner
          const resume = await storage.getResume(resumeId);
          if (resume && resume.userId !== clientConnection.userId) {
            await storage.createNotification({
              userId: resume.userId,
              type: 'comment',
              content: `${user?.username} commented on your resume "${resume.title}"`,
              relatedId: comment.id
            });
          }
        }
        else if (data.type === 'resolve_comment') {
          // Handle resolving a comment
          if (!clientConnection) {
            ws.send(JSON.stringify({ 
              type: 'error', 
              message: 'Not authenticated' 
            }));
            return;
          }
          
          const { commentId, resolved } = data;
          
          // Verify that the user has permission
          const comment = await storage.getComment(commentId);
          if (!comment) {
            ws.send(JSON.stringify({ 
              type: 'error', 
              message: 'Comment not found' 
            }));
            return;
          }
          
          const resume = await storage.getResume(comment.resumeId);
          if (!resume || (resume.userId !== clientConnection.userId && comment.userId !== clientConnection.userId)) {
            ws.send(JSON.stringify({ 
              type: 'error', 
              message: 'You do not have permission to resolve this comment' 
            }));
            return;
          }
          
          // Update the comment
          await storage.resolveComment(commentId, resolved);
          
          // Broadcast the update to all clients
          broadcastToResumeClients(
            comment.resumeId,
            {
              type: 'comment_resolved',
              commentId,
              resolved,
              username: clientConnection.username
            }
          );
        }
        else if (data.type === 'ping') {
          // Keep-alive ping
          ws.send(JSON.stringify({ type: 'pong' }));
        }
      } catch (error) {
        console.error('Error handling WebSocket message:', error);
        ws.send(JSON.stringify({ 
          type: 'error', 
          message: 'Invalid message format' 
        }));
      }
    });
    
    ws.on('close', () => {
      if (clientConnection) {
        // Remove client from list
        const index = clients.findIndex(c => c.socket === ws);
        if (index !== -1) {
          clients.splice(index, 1);
        }
        
        // Notify other clients
        broadcastToResumeClients(
          clientConnection.resumeId,
          {
            type: 'collaborator_left',
            userId: clientConnection.userId,
            username: clientConnection.username
          },
          clientConnection.userId
        );
      }
    });
  });
  
  // Helper function to broadcast to resume clients
  function broadcastToResumeClients(resumeId: number, data: any, excludeUserId?: number) {
    clients
      .filter(client => 
        client.resumeId === resumeId && 
        (excludeUserId === undefined || client.userId !== excludeUserId)
      )
      .forEach(client => {
        try {
          if (client.socket.readyState === WebSocket.OPEN) {
            client.socket.send(JSON.stringify(data));
          }
        } catch (error) {
          console.error('Error broadcasting to client:', error);
        }
      });
  }
  
  // Helper function to get active collaborators
  function getActiveCollaborators(resumeId: number) {
    return clients
      .filter(client => client.resumeId === resumeId)
      .map(client => ({
        userId: client.userId,
        username: client.username,
        role: client.role
      }));
  }
  
  // Get active collaborators
  app.get('/api/resumes/:id/active-collaborators', requireAuth, async (req, res) => {
    try {
      const resumeId = parseInt(req.params.id);
      if (isNaN(resumeId)) {
        return res.status(400).json({ error: "Invalid resume ID" });
      }
      
      // Check if user has access to this resume
      const resume = await storage.getResume(resumeId);
      if (!resume) {
        return res.status(404).json({ error: "Resume not found" });
      }
      
      if (resume.userId !== req.user!.id) {
        const collaborators = await storage.getCollaborators(resumeId);
        const collaborator = collaborators.find(c => c.userId === req.user!.id);
        if (!collaborator) {
          return res.status(403).json({ error: "Access denied" });
        }
      }
      
      const activeCollaborators = getActiveCollaborators(resumeId);
      res.json(activeCollaborators);
    } catch (error) {
      console.error("Error fetching active collaborators:", error);
      res.status(500).json({ error: "Server error" });
    }
  });
  
  // Career paths AI API endpoint
  app.post('/api/ai/career-paths', requireAuth, async (req, res) => {
    try {
      const { 
        currentRole, 
        yearsOfExperience, 
        skills, 
        interests, 
        educationLevel, 
        industry,
        location 
      } = req.body;
      
      // In a real application, we would process this data with an AI model
      // For now, we'll return a stub response that matches the expected format
      
      // Simple validation
      if (!currentRole || !skills || !interests) {
        return res.status(400).json({ 
          error: "Missing required fields. Please provide currentRole, skills, and interests."
        });
      }
      
      // Here we would normally call Claude or another AI model
      // For now, return a static response
      res.json({
        currentAssessment: "Based on your profile as a " + currentRole + " with " + yearsOfExperience + 
          " years of experience, you have a strong foundation in " + skills.join(", ") + 
          ". Your interest in " + interests.join(", ") + " opens up several career paths.",
        recommendedPaths: [
          {
            title: "Technical Leadership Track",
            description: "Progress towards becoming a technical leader, architect, or engineering manager.",
            requiredSkills: ["Team Leadership", "System Design", "Project Management", "Communication"],
            recommendedSkills: ["Mentoring", "Architecture Patterns", "Cross-functional Collaboration"],
            salary: "$120,000 - $180,000+",
            growthPotential: "High demand with 15% growth expected over 5 years",
            timeframe: "2-4 years to reach senior positions",
            recommendedEducation: ["Leadership training", "System design courses"]
          },
          {
            title: "Specialization Track",
            description: "Deepen expertise in a specific technology area to become a subject matter expert.",
            requiredSkills: ["Deep Technical Knowledge", "Problem Solving", "Continuous Learning"],
            recommendedSkills: ["Open Source Contribution", "Technical Writing", "Conference Speaking"],
            salary: "$110,000 - $160,000+",
            growthPotential: "Stable demand with premium for rare specializations",
            timeframe: "1-3 years to establish expertise",
            recommendedEducation: ["Advanced certifications", "Specialized workshops"]
          },
          {
            title: "Product-Focused Track",
            description: "Transition towards product management or product-focused development roles.",
            requiredSkills: ["User Empathy", "Product Thinking", "Data Analysis", "Communication"],
            recommendedSkills: ["User Research", "Market Analysis", "Strategy Development"],
            salary: "$115,000 - $170,000+",
            growthPotential: "Growing demand as companies emphasize product-led growth",
            timeframe: "1-2 years for initial transition, 3-5 for senior positions",
            recommendedEducation: ["Product management courses", "UX design fundamentals"]
          }
        ],
        generalAdvice: "Based on your profile, focus on building projects that demonstrate both technical skills and " +
          "business impact. Consider finding a mentor in your desired path who can provide guidance specific to your industry."
      });
    } catch (error) {
      console.error("Error processing career path request:", error);
      res.status(500).json({ error: "Failed to generate career path recommendations" });
    }
  });

  // WebSocket server is already set up above at line 1093
  
  return httpServer;
}