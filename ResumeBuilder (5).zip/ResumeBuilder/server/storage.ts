import { 
  users, 
  resumes,
  collaborators,
  comments,
  invitations,
  notifications,
  visitors,
  pageViews,
  sessionRecordings,
  type User, 
  type InsertUser, 
  type Resume, 
  type InsertResume,
  type Collaborator,
  type InsertCollaborator,
  type Comment,
  type InsertComment,
  type Invitation,
  type InsertInvitation,
  type Notification,
  type InsertNotification,
  type Visitor,
  type InsertVisitor,
  type PageView,
  type InsertPageView,
  type SessionRecording,
  type InsertSessionRecording
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, or, isNull, ne, sql, asc, count, between } from "drizzle-orm";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import { v4 as uuidv4 } from 'uuid';

// Updated interface with resume-related methods and session store
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<User>): Promise<User | undefined>;
  
  // Resume methods
  getResume(id: number): Promise<Resume | undefined>;
  getResumesByUserId(userId: number): Promise<Resume[]>;
  getDefaultResume(userId: number): Promise<Resume | undefined>;
  createResume(resume: InsertResume): Promise<Resume>;
  updateResume(id: number, data: Partial<InsertResume>): Promise<Resume | undefined>;
  deleteResume(id: number): Promise<boolean>;
  getResumeByShareableLink(link: string): Promise<Resume | undefined>;
  generateShareableLink(resumeId: number): Promise<string | undefined>;
  
  // Collaborator methods
  getCollaborators(resumeId: number): Promise<Collaborator[]>;
  getCollaborationsForUser(userId: number): Promise<Collaborator[]>;
  getCollaborator(id: number): Promise<Collaborator | undefined>;
  addCollaborator(collaborator: InsertCollaborator): Promise<Collaborator>;
  updateCollaboratorRole(id: number, role: string): Promise<Collaborator | undefined>;
  removeCollaborator(id: number): Promise<boolean>;
  
  // Comment methods
  getComments(resumeId: number): Promise<Comment[]>;
  getComment(id: number): Promise<Comment | undefined>;
  createComment(comment: InsertComment): Promise<Comment>;
  resolveComment(id: number, resolved: boolean): Promise<Comment | undefined>;
  deleteComment(id: number): Promise<boolean>;
  
  // Invitation methods
  createInvitation(invitation: InsertInvitation): Promise<Invitation>;
  getInvitationByToken(token: string): Promise<Invitation | undefined>;
  getInvitation(id: number): Promise<Invitation | undefined>;
  acceptInvitation(token: string, userId: number): Promise<boolean>;
  getInvitationsForResume(resumeId: number): Promise<Invitation[]>;
  getPendingInvitationsByEmail(email: string): Promise<Invitation[]>;
  deleteInvitation(id: number): Promise<boolean>;
  
  // Notification methods
  getNotificationsForUser(userId: number): Promise<Notification[]>;
  getUnreadNotificationCount(userId: number): Promise<number>;
  getNotification(id: number): Promise<Notification | undefined>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: number): Promise<boolean>;
  markAllNotificationsAsRead(userId: number): Promise<boolean>;
  deleteNotification(id: number): Promise<boolean>;
  
  // Analytics methods - New
  // Visitor methods
  getVisitor(id: number): Promise<Visitor | undefined>;
  getVisitorByVisitorId(visitorId: string): Promise<Visitor | undefined>;
  createOrUpdateVisitor(visitor: InsertVisitor): Promise<Visitor>;
  getAllVisitors(limit?: number, offset?: number): Promise<Visitor[]>;
  getTotalVisitors(): Promise<number>;
  getVisitorsByDateRange(startDate: Date, endDate: Date): Promise<Visitor[]>;
  getVisitorsByLocation(country?: string, region?: string, city?: string): Promise<Visitor[]>;
  
  // Page view methods
  createPageView(pageView: InsertPageView): Promise<PageView>;
  getPageViewsByVisitorId(visitorId: string): Promise<PageView[]>;
  getMostViewedPages(limit?: number): Promise<{path: string, count: number}[]>;
  getPageViewsForPath(path: string): Promise<PageView[]>;
  
  // Session recording methods
  createSessionRecording(recording: InsertSessionRecording): Promise<SessionRecording>;
  getSessionRecording(id: number): Promise<SessionRecording | undefined>;
  getSessionRecordingBySessionId(sessionId: string): Promise<SessionRecording | undefined>;
  getSessionRecordingsByVisitorId(visitorId: string): Promise<SessionRecording[]>;
  getAllSessionRecordings(limit?: number, offset?: number): Promise<SessionRecording[]>;
  
  // Analytics summaries
  getVisitorStatistics(): Promise<{
    totalVisitors: number;
    newVisitorsToday: number;
    averagePageViews: number;
    topCountries: {country: string, count: number}[];
  }>;
  
  getPageViewStatistics(): Promise<{
    totalPageViews: number;
    uniquePages: number;
    topPages: {path: string, views: number}[];
    averageTimeOnPage: number;
  }>;
  
  getVisitorsByDay(days: number): Promise<{date: string, count: number}[]>;
  
  // For session store
  sessionStore: session.Store;
}

// Database implementation of the storage interface

export class DatabaseStorage implements IStorage {
  // Initialize session store
  sessionStore: session.Store;
  
  constructor() {
    // Create PostgreSQL session store
    const PostgresStore = connectPgSimple(session);
    this.sessionStore = new PostgresStore({
      conObject: {
        connectionString: process.env.DATABASE_URL,
      },
      createTableIfMissing: true
    });
  }
  
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  async updateUser(id: number, data: Partial<User>): Promise<User | undefined> {
    // Update the timestamp
    const updateData = {
      ...data,
      updatedAt: new Date()
    };
    
    const [updatedUser] = await db
      .update(users)
      .set(updateData as any) // Type assertion needed due to the timestamp
      .where(eq(users.id, id))
      .returning();
    
    return updatedUser;
  }

  // Resume methods
  async getResume(id: number): Promise<Resume | undefined> {
    const [resume] = await db.select().from(resumes).where(eq(resumes.id, id));
    return resume;
  }

  async getResumesByUserId(userId: number): Promise<Resume[]> {
    return db.select()
      .from(resumes)
      .where(eq(resumes.userId, userId))
      .orderBy(desc(resumes.updatedAt));
  }

  async getDefaultResume(userId: number): Promise<Resume | undefined> {
    const [resume] = await db.select()
      .from(resumes)
      .where(
        and(
          eq(resumes.userId, userId),
          eq(resumes.isDefault, true)
        )
      );
    return resume;
  }

  async createResume(resume: InsertResume): Promise<Resume> {
    // If this is set as default, unset any existing default resumes for this user
    if (resume.isDefault) {
      await db.update(resumes)
        .set({ isDefault: false })
        .where(
          and(
            eq(resumes.userId, resume.userId),
            eq(resumes.isDefault, true)
          )
        );
    }
    
    const [createdResume] = await db.insert(resumes).values(resume).returning();
    return createdResume;
  }

  async updateResume(id: number, data: Partial<InsertResume>): Promise<Resume | undefined> {
    // If this is being set as default, unset any existing default resumes for this user
    if (data.isDefault) {
      const [resume] = await db.select().from(resumes).where(eq(resumes.id, id));
      if (resume) {
        await db.update(resumes)
          .set({ isDefault: false })
          .where(
            and(
              eq(resumes.userId, resume.userId),
              eq(resumes.isDefault, true)
            )
          );
      }
    }
    
    // Update the timestamp
    const updateData = {
      ...data,
      updatedAt: new Date()
    };
    
    const [updatedResume] = await db
      .update(resumes)
      .set(updateData as any) // Type assertion needed due to the timestamp
      .where(eq(resumes.id, id))
      .returning();
    
    return updatedResume;
  }

  async deleteResume(id: number): Promise<boolean> {
    const result = await db.delete(resumes).where(eq(resumes.id, id)).returning();
    return result.length > 0;
  }
  
  async getResumeByShareableLink(link: string): Promise<Resume | undefined> {
    const [resume] = await db.select()
      .from(resumes)
      .where(eq(resumes.shareableLink, link));
    return resume;
  }
  
  async generateShareableLink(resumeId: number): Promise<string | undefined> {
    const [resume] = await db.select().from(resumes).where(eq(resumes.id, resumeId));
    if (!resume) return undefined;
    
    const shareableLink = uuidv4();
    const [updatedResume] = await db
      .update(resumes)
      .set({ 
        shareableLink,
        updatedAt: new Date()
      })
      .where(eq(resumes.id, resumeId))
      .returning();
    
    return updatedResume.shareableLink || undefined;
  }
  
  // Collaborator methods
  async getCollaborators(resumeId: number): Promise<Collaborator[]> {
    return db.select()
      .from(collaborators)
      .where(eq(collaborators.resumeId, resumeId));
  }
  
  async getCollaborationsForUser(userId: number): Promise<Collaborator[]> {
    return db.select()
      .from(collaborators)
      .where(eq(collaborators.userId, userId));
  }
  
  async addCollaborator(collaborator: InsertCollaborator): Promise<Collaborator> {
    // Check if collaboration already exists
    const [existingCollab] = await db.select()
      .from(collaborators)
      .where(and(
        eq(collaborators.resumeId, collaborator.resumeId),
        eq(collaborators.userId, collaborator.userId)
      ));
    
    if (existingCollab) {
      // Update the role if it exists
      const [updatedCollab] = await db.update(collaborators)
        .set({ 
          role: collaborator.role,
          updatedAt: new Date()
        })
        .where(eq(collaborators.id, existingCollab.id))
        .returning();
      return updatedCollab;
    }
    
    // Otherwise create a new collaboration
    const [newCollab] = await db.insert(collaborators)
      .values(collaborator)
      .returning();
    return newCollab;
  }
  
  async updateCollaboratorRole(id: number, role: string): Promise<Collaborator | undefined> {
    const [updatedCollab] = await db.update(collaborators)
      .set({ 
        role,
        updatedAt: new Date()
      })
      .where(eq(collaborators.id, id))
      .returning();
    return updatedCollab;
  }
  
  async removeCollaborator(id: number): Promise<boolean> {
    const result = await db.delete(collaborators)
      .where(eq(collaborators.id, id))
      .returning();
    return result.length > 0;
  }
  
  // Comment methods
  async getComments(resumeId: number): Promise<Comment[]> {
    return db.select()
      .from(comments)
      .where(eq(comments.resumeId, resumeId))
      .orderBy(desc(comments.createdAt));
  }
  
  async createComment(comment: InsertComment): Promise<Comment> {
    const [newComment] = await db.insert(comments)
      .values(comment)
      .returning();
    return newComment;
  }
  
  async resolveComment(id: number, resolved: boolean): Promise<Comment | undefined> {
    const [updatedComment] = await db.update(comments)
      .set({ 
        resolved,
        updatedAt: new Date()
      })
      .where(eq(comments.id, id))
      .returning();
    return updatedComment;
  }
  
  async deleteComment(id: number): Promise<boolean> {
    const result = await db.delete(comments)
      .where(eq(comments.id, id))
      .returning();
    return result.length > 0;
  }
  
  // Invitation methods
  async createInvitation(invitation: InsertInvitation): Promise<Invitation> {
    // Check if there's already a pending invitation for this email and resume
    const [existingInvitation] = await db.select()
      .from(invitations)
      .where(and(
        eq(invitations.resumeId, invitation.resumeId),
        eq(invitations.email, invitation.email),
        eq(invitations.accepted, false)
      ));
    
    if (existingInvitation) {
      // Update the existing invitation
      const [updatedInvitation] = await db.update(invitations)
        .set({ 
          role: invitation.role,
          token: invitation.token,
          expiresAt: invitation.expiresAt,
          updatedAt: new Date()
        })
        .where(eq(invitations.id, existingInvitation.id))
        .returning();
      return updatedInvitation;
    }
    
    // Create new invitation
    const [newInvitation] = await db.insert(invitations)
      .values(invitation)
      .returning();
    return newInvitation;
  }
  
  async getInvitationByToken(token: string): Promise<Invitation | undefined> {
    const [invitation] = await db.select()
      .from(invitations)
      .where(eq(invitations.token, token));
    return invitation;
  }
  
  async acceptInvitation(token: string, userId: number): Promise<boolean> {
    const [invitation] = await db.select()
      .from(invitations)
      .where(and(
        eq(invitations.token, token),
        eq(invitations.accepted, false)
      ));
    
    if (!invitation) return false;
    
    // Check if invitation has expired
    const now = new Date();
    if (now > invitation.expiresAt) return false;
    
    // Mark invitation as accepted
    await db.update(invitations)
      .set({ 
        accepted: true,
        updatedAt: now
      })
      .where(eq(invitations.id, invitation.id));
    
    // Add the user as a collaborator
    await this.addCollaborator({
      resumeId: invitation.resumeId,
      userId,
      role: invitation.role
    });
    
    return true;
  }
  
  async getInvitationsForResume(resumeId: number): Promise<Invitation[]> {
    return db.select()
      .from(invitations)
      .where(eq(invitations.resumeId, resumeId))
      .orderBy(desc(invitations.createdAt));
  }
  
  async getPendingInvitationsByEmail(email: string): Promise<Invitation[]> {
    const now = new Date();
    return db.select()
      .from(invitations)
      .where(and(
        eq(invitations.email, email),
        eq(invitations.accepted, false),
        sql`${invitations.expiresAt} > ${now}`
      ));
  }
  
  async deleteInvitation(id: number): Promise<boolean> {
    const result = await db.delete(invitations)
      .where(eq(invitations.id, id))
      .returning();
    return result.length > 0;
  }
  
  // Notification methods
  async getNotificationsForUser(userId: number): Promise<Notification[]> {
    return db.select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }
  
  async getUnreadNotificationCount(userId: number): Promise<number> {
    const result = await db.select({ count: sql`COUNT(*)` })
      .from(notifications)
      .where(and(
        eq(notifications.userId, userId),
        eq(notifications.read, false)
      ));
    
    return Number(result[0].count);
  }
  
  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [newNotification] = await db.insert(notifications)
      .values(notification)
      .returning();
    return newNotification;
  }
  
  async markNotificationAsRead(id: number): Promise<boolean> {
    const result = await db.update(notifications)
      .set({ read: true })
      .where(eq(notifications.id, id))
      .returning();
    return result.length > 0;
  }
  
  async markAllNotificationsAsRead(userId: number): Promise<boolean> {
    const result = await db.update(notifications)
      .set({ read: true })
      .where(and(
        eq(notifications.userId, userId),
        eq(notifications.read, false)
      ))
      .returning();
    return result.length > 0;
  }
  
  async deleteNotification(id: number): Promise<boolean> {
    const result = await db.delete(notifications)
      .where(eq(notifications.id, id))
      .returning();
    return result.length > 0;
  }
  
  // Additional methods needed for API routes
  
  async getCollaborator(id: number): Promise<Collaborator | undefined> {
    const [collaborator] = await db.select()
      .from(collaborators)
      .where(eq(collaborators.id, id));
    return collaborator;
  }
  
  async getCollaboratorByResumeAndUser(resumeId: number, userId: number): Promise<Collaborator | undefined> {
    const [collaborator] = await db.select()
      .from(collaborators)
      .where(and(
        eq(collaborators.resumeId, resumeId),
        eq(collaborators.userId, userId)
      ));
    return collaborator;
  }
  
  async getComment(id: number): Promise<Comment | undefined> {
    const [comment] = await db.select()
      .from(comments)
      .where(eq(comments.id, id));
    return comment;
  }
  
  async getInvitation(id: number): Promise<Invitation | undefined> {
    const [invitation] = await db.select()
      .from(invitations)
      .where(eq(invitations.id, id));
    return invitation;
  }
  
  async getNotification(id: number): Promise<Notification | undefined> {
    const [notification] = await db.select()
      .from(notifications)
      .where(eq(notifications.id, id));
    return notification;
  }
  
  // Analytics methods - New
  
  // Visitor methods
  async getVisitor(id: number): Promise<Visitor | undefined> {
    const [visitor] = await db.select().from(visitors).where(eq(visitors.id, id));
    return visitor;
  }
  
  async getVisitorByVisitorId(visitorId: string): Promise<Visitor | undefined> {
    const [visitor] = await db.select().from(visitors).where(eq(visitors.visitorId, visitorId));
    return visitor;
  }
  
  async createOrUpdateVisitor(visitor: InsertVisitor): Promise<Visitor> {
    // Check if visitor exists
    const existingVisitor = await this.getVisitorByVisitorId(visitor.visitorId);
    
    if (existingVisitor) {
      // Update existing visitor
      const [updatedVisitor] = await db.update(visitors)
        .set({
          userAgent: visitor.userAgent,
          lastVisit: new Date(),
          visitCount: existingVisitor.visitCount + 1,
          // Only update these if provided
          userId: visitor.userId || existingVisitor.userId,
          ip: visitor.ip || existingVisitor.ip,
          country: visitor.country || existingVisitor.country,
          city: visitor.city || existingVisitor.city,
          region: visitor.region || existingVisitor.region,
          os: visitor.os || existingVisitor.os,
          browser: visitor.browser || existingVisitor.browser,
          device: visitor.device || existingVisitor.device,
          referrer: visitor.referrer || existingVisitor.referrer
        })
        .where(eq(visitors.id, existingVisitor.id))
        .returning();
      
      return updatedVisitor;
    } else {
      // Create new visitor
      const [newVisitor] = await db.insert(visitors).values(visitor).returning();
      return newVisitor;
    }
  }
  
  async getAllVisitors(limit: number = 100, offset: number = 0): Promise<Visitor[]> {
    return db.select()
      .from(visitors)
      .orderBy(desc(visitors.lastVisit))
      .limit(limit)
      .offset(offset);
  }
  
  async getTotalVisitors(): Promise<number> {
    const result = await db.select({ count: sql`COUNT(*)` }).from(visitors);
    return Number(result[0].count);
  }
  
  async getVisitorsByDateRange(startDate: Date, endDate: Date): Promise<Visitor[]> {
    return db.select()
      .from(visitors)
      .where(
        and(
          sql`${visitors.firstVisit} >= ${startDate}`,
          sql`${visitors.firstVisit} <= ${endDate}`
        )
      )
      .orderBy(asc(visitors.firstVisit));
  }
  
  async getVisitorsByLocation(country?: string, region?: string, city?: string): Promise<Visitor[]> {
    let query = db.select().from(visitors);
    
    if (country) {
      query = query.where(eq(visitors.country, country));
    }
    
    if (region) {
      query = query.where(eq(visitors.region, region));
    }
    
    if (city) {
      query = query.where(eq(visitors.city, city));
    }
    
    return query.orderBy(desc(visitors.lastVisit));
  }
  
  // Page view methods
  async createPageView(pageView: InsertPageView): Promise<PageView> {
    const [newPageView] = await db.insert(pageViews).values(pageView).returning();
    return newPageView;
  }
  
  async getPageViewsByVisitorId(visitorId: string): Promise<PageView[]> {
    return db.select()
      .from(pageViews)
      .where(eq(pageViews.visitorId, visitorId))
      .orderBy(desc(pageViews.timestamp));
  }
  
  async getMostViewedPages(limit: number = 10): Promise<{path: string, count: number}[]> {
    const result = await db.select({
      path: pageViews.path,
      count: sql<number>`COUNT(*)`.as('count')
    })
    .from(pageViews)
    .groupBy(pageViews.path)
    .orderBy(sql`count DESC`)
    .limit(limit);
    
    return result.map(row => ({
      path: row.path,
      count: Number(row.count)
    }));
  }
  
  async getPageViewsForPath(path: string): Promise<PageView[]> {
    return db.select()
      .from(pageViews)
      .where(eq(pageViews.path, path))
      .orderBy(desc(pageViews.timestamp));
  }
  
  // Session recording methods
  async createSessionRecording(recording: InsertSessionRecording): Promise<SessionRecording> {
    const [newRecording] = await db.insert(sessionRecordings).values(recording).returning();
    return newRecording;
  }
  
  async getSessionRecording(id: number): Promise<SessionRecording | undefined> {
    const [recording] = await db.select().from(sessionRecordings).where(eq(sessionRecordings.id, id));
    return recording;
  }
  
  async getSessionRecordingBySessionId(sessionId: string): Promise<SessionRecording | undefined> {
    const [recording] = await db.select()
      .from(sessionRecordings)
      .where(eq(sessionRecordings.sessionId, sessionId));
    return recording;
  }
  
  async getSessionRecordingsByVisitorId(visitorId: string): Promise<SessionRecording[]> {
    return db.select()
      .from(sessionRecordings)
      .where(eq(sessionRecordings.visitorId, visitorId))
      .orderBy(desc(sessionRecordings.startTime));
  }
  
  async getAllSessionRecordings(limit: number = 100, offset: number = 0): Promise<SessionRecording[]> {
    return db.select()
      .from(sessionRecordings)
      .orderBy(desc(sessionRecordings.startTime))
      .limit(limit)
      .offset(offset);
  }
  
  // Analytics summaries
  async getVisitorStatistics(): Promise<{
    totalVisitors: number;
    newVisitorsToday: number;
    averagePageViews: number;
    topCountries: {country: string, count: number}[];
  }> {
    // Total visitors
    const totalVisitors = await this.getTotalVisitors();
    
    // New visitors today
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const newVisitorsResult = await db.select({ count: sql`COUNT(*)` })
      .from(visitors)
      .where(sql`${visitors.firstVisit} >= ${today}`);
    const newVisitorsToday = Number(newVisitorsResult[0].count);
    
    // Average page views per visitor
    const pageViewsResult = await db.select({
      count: sql`COUNT(*)`,
      visitors: sql`COUNT(DISTINCT ${pageViews.visitorId})`
    })
    .from(pageViews);
    
    const totalPageViews = Number(pageViewsResult[0].count);
    const uniqueVisitors = Number(pageViewsResult[0].visitors);
    const averagePageViews = uniqueVisitors > 0 ? totalPageViews / uniqueVisitors : 0;
    
    // Top countries
    const topCountriesResult = await db.select({
      country: visitors.country,
      count: sql<number>`COUNT(*)`.as('count')
    })
    .from(visitors)
    .where(ne(visitors.country, null as any))
    .groupBy(visitors.country)
    .orderBy(sql`count DESC`)
    .limit(5);
    
    const topCountries = topCountriesResult.map(row => ({
      country: row.country || 'Unknown',
      count: Number(row.count)
    }));
    
    return {
      totalVisitors,
      newVisitorsToday,
      averagePageViews,
      topCountries
    };
  }
  
  async getPageViewStatistics(): Promise<{
    totalPageViews: number;
    uniquePages: number;
    topPages: {path: string, views: number}[];
    averageTimeOnPage: number;
  }> {
    // Total page views
    const totalResult = await db.select({ count: sql`COUNT(*)` }).from(pageViews);
    const totalPageViews = Number(totalResult[0].count);
    
    // Unique pages
    const uniquePagesResult = await db.select({
      count: sql`COUNT(DISTINCT ${pageViews.path})`
    })
    .from(pageViews);
    const uniquePages = Number(uniquePagesResult[0].count);
    
    // Top pages
    const topPagesResult = await db.select({
      path: pageViews.path,
      views: sql<number>`COUNT(*)`.as('views')
    })
    .from(pageViews)
    .groupBy(pageViews.path)
    .orderBy(sql`views DESC`)
    .limit(10);
    
    const topPages = topPagesResult.map(row => ({
      path: row.path,
      views: Number(row.views)
    }));
    
    // Average time on page (based on duration field)
    const timeResult = await db.select({
      avg: sql`AVG(${pageViews.duration})`
    })
    .from(pageViews)
    .where(ne(pageViews.duration, null as any));
    
    const averageTimeOnPage = Number(timeResult[0].avg) || 0;
    
    return {
      totalPageViews,
      uniquePages,
      topPages,
      averageTimeOnPage
    };
  }
  
  async getVisitorsByDay(days: number): Promise<{date: string, count: number}[]> {
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    
    // Create a query that groups visitors by day
    const result = await db.select({
      date: sql`DATE(${visitors.firstVisit})`.as('date'),
      count: sql<number>`COUNT(*)`.as('count')
    })
    .from(visitors)
    .where(
      and(
        sql`${visitors.firstVisit} >= ${startDate}`,
        sql`${visitors.firstVisit} <= ${endDate}`
      )
    )
    .groupBy(sql`DATE(${visitors.firstVisit})`)
    .orderBy(asc(sql`date`));
    
    return result.map(row => ({
      date: row.date.toString(),
      count: Number(row.count)
    }));
  }
}

// Export an instance of the database storage class
export const storage = new DatabaseStorage();
