import Anthropic from '@anthropic-ai/sdk';

// the newest Anthropic model is "claude-3-7-sonnet-20250219" which was released February 24, 2025
const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

/**
 * Enhances a resume summary with AI
 * @param originalSummary The original summary text
 * @param context Additional context about the user's background
 * @returns An improved, professional summary
 */
export async function enhanceSummary(originalSummary: string, context?: string): Promise<string> {
  try {
    const prompt = `
      I need help improving a professional resume summary. Please enhance the following summary
      to be more impactful, professional, and highlight key strengths. Keep it concise (3-5 sentences).
      Make it achievement-oriented with measurable results where possible. Don't fabricate information.
      
      ${context ? `Context about the person: ${context}` : ''}
      
      Original summary:
      ${originalSummary}
    `;

    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      max_tokens: 500,
      messages: [{ role: 'user', content: prompt }],
    });

    // Access the text content safely
    if (response.content[0].type === 'text') {
      return response.content[0].text.trim();
    }
    
    return 'Could not generate enhancement';
  } catch (error) {
    console.error('Error enhancing summary:', error);
    throw new Error('Failed to enhance summary with AI');
  }
}

/**
 * Enhances job descriptions with AI
 * @param originalDescriptions Array of job description bullet points
 * @param jobTitle The job title for context
 * @returns Array of improved job descriptions
 */
export async function enhanceJobDescriptions(
  originalDescriptions: string[],
  jobTitle: string
): Promise<string[]> {
  try {
    const prompt = `
      I need help improving the bullet points for a job description on a resume.
      Please enhance each bullet point to be more impactful, focus on achievements,
      and use strong action verbs. Keep each bullet point concise (1-2 sentences).
      Don't fabricate information or specific metrics.
      
      Job Title: ${jobTitle}
      
      Original bullet points:
      ${originalDescriptions.map(desc => `- ${desc}`).join('\n')}
      
      Please return only the enhanced bullet points, one per line, with no prefixes or additional text.
    `;

    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      max_tokens: 1000,
      messages: [{ role: 'user', content: prompt }],
    });

    // Process the response to extract bullet points
    let enhancedText = '';
    
    if (response.content[0].type === 'text') {
      enhancedText = response.content[0].text.trim();
    }
    
    // Split by newlines and clean up
    const enhancedBullets = enhancedText
      .split('\n')
      .map((line: string) => line.replace(/^[-•⁃∙◦★]\s*/, '').trim())
      .filter((line: string) => line.length > 0);

    return enhancedBullets;
  } catch (error) {
    console.error('Error enhancing job descriptions:', error);
    throw new Error('Failed to enhance job descriptions with AI');
  }
}

/**
 * Suggests skills relevant to a job position
 * @param jobTitle The job title
 * @param industry The industry
 * @param existingSkills Array of existing skills
 * @returns Array of suggested skills
 */
export async function suggestSkills(
  jobTitle: string,
  industry?: string,
  existingSkills: string[] = []
): Promise<string[]> {
  try {
    const prompt = `
      I need suggestions for professional skills to include on a resume.
      Please suggest relevant technical skills, soft skills, and industry-specific
      skills that would be valuable for this position. Don't suggest skills that 
      are already included in the existing skills list.
      
      Job Title: ${jobTitle}
      ${industry ? `Industry: ${industry}` : ''}
      
      ${existingSkills.length > 0 ? `Existing skills (don't repeat these):\n${existingSkills.join(', ')}` : ''}
      
      Please return only a list of skills, separated by newlines, with no prefixes or additional text.
      Suggest 5-10 skills.
    `;

    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      max_tokens: 400,
      messages: [{ role: 'user', content: prompt }],
    });

    // Process the response to extract skills
    let suggestedText = '';
    
    if (response.content[0].type === 'text') {
      suggestedText = response.content[0].text.trim();
    }
    
    // Split by newlines and clean up
    const suggestedSkills = suggestedText
      .split('\n')
      .map((line: string) => line.replace(/^[-•⁃∙◦★]\s*/, '').trim())
      .filter((line: string) => line.length > 0 && !existingSkills.includes(line));

    return suggestedSkills;
  } catch (error) {
    console.error('Error suggesting skills:', error);
    throw new Error('Failed to suggest skills with AI');
  }
}

// Resume data types
type PersonalInfo = {
  name: string;
  jobTitle: string;
  email: string;
  phone: string;
  city: string;
  state: string;
  linkedin?: string;
  photo?: string;
};

type Summary = {
  content: string;
};

type Job = {
  id: string | number;
  position: string;
  company: string;
  location: string;
  startDate: string;
  endDate: string;
  current: boolean;
  description: string[];
};

type Education = {
  id: string | number;
  degree: string;
  field: string;
  institution: string;
  location: string;
  startDate: string;
  endDate: string;
  description?: string;
};

type Skill = {
  id: string | number;
  name: string;
};

type ResumeData = {
  personalInfo: PersonalInfo;
  summary: Summary;
  experience: Job[];
  education: Education[];
  skills: Skill[];
};

/**
 * Analyzes a resume for improvement suggestions
 * @param resumeData The full resume data
 * @returns Analysis and improvement suggestions
 */
export async function analyzeResume(resumeData: ResumeData): Promise<string> {
  try {
    // Create a text representation of the resume
    const resumeText = `
      Name: ${resumeData.personalInfo.name}
      Job Title: ${resumeData.personalInfo.jobTitle}
      
      Summary:
      ${resumeData.summary.content}
      
      Experience:
      ${resumeData.experience.map((job: Job) => `
        - ${job.position} at ${job.company} (${job.startDate} - ${job.current ? 'Present' : job.endDate})
          ${job.description.join('\n          ')}
      `).join('\n')}
      
      Education:
      ${resumeData.education.map((edu: Education) => `
        - ${edu.degree} in ${edu.field} from ${edu.institution} (${edu.startDate} - ${edu.endDate})
      `).join('\n')}
      
      Skills:
      ${resumeData.skills.map((skill: Skill) => skill.name).join(', ')}
    `;

    const prompt = `
      Please analyze this resume and provide specific improvement suggestions.
      Focus on:
      1. Content gaps or weaknesses
      2. Improvement opportunities for impact and clarity
      3. Format and structure suggestions
      4. Industry best practices for this type of role
      
      Resume:
      ${resumeText}
      
      Provide a concise, actionable analysis with specific suggestions.
    `;

    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      max_tokens: 1200,
      messages: [{ role: 'user', content: prompt }],
    });

    if (response.content[0].type === 'text') {
      return response.content[0].text.trim();
    }
    
    return "Could not generate analysis";
  } catch (error) {
    console.error('Error analyzing resume:', error);
    throw new Error('Failed to analyze resume with AI');
  }
}

type CareerPathQuery = {
  currentRole: string;
  yearsOfExperience: number;
  skills: string[];
  interests: string[];
  educationLevel: string;
  industry?: string;
  location?: string;
};

export type CareerPathOption = {
  title: string;
  description: string;
  requiredSkills: string[];
  recommendedSkills: string[];
  salary: string;
  growthPotential: string;
  timeframe: string;
  recommendedEducation?: string[];
};

export type CareerPathResponse = {
  currentAssessment: string;
  recommendedPaths: CareerPathOption[];
  generalAdvice: string;
};

/**
 * Generates career path recommendations based on the user's background and interests
 * @param query User's current career information and preferences
 * @returns Career path recommendations and advice
 */
export async function generateCareerPathRecommendations(query: CareerPathQuery): Promise<CareerPathResponse> {
  try {
    const response = await anthropic.messages.create({
      model: "claude-3-7-sonnet-20250219",
      max_tokens: 1500,
      temperature: 0.7,
      system: "You are a career guidance expert. Provide structured career path recommendations based on the user's current role, skills, and interests. Your output should be detailed, realistic, and actionable.",
      messages: [{
        role: 'user',
        content: `I need career path recommendations based on the following information:

Current Role: ${query.currentRole}
Years of Experience: ${query.yearsOfExperience}
Skills: ${query.skills.join(', ')}
Interests: ${query.interests.join(', ')}
Education Level: ${query.educationLevel}
${query.industry ? `Industry: ${query.industry}` : ''}
${query.location ? `Location: ${query.location}` : ''}

Please format your response as valid JSON with the following structure:
{
  "currentAssessment": "A brief assessment of the user's current career position",
  "recommendedPaths": [
    {
      "title": "Job title of recommended path",
      "description": "Description of this career path and why it's suitable",
      "requiredSkills": ["Skill 1", "Skill 2", "Skill 3"],
      "recommendedSkills": ["Skill 1", "Skill 2", "Skill 3"],
      "salary": "Salary range for this role",
      "growthPotential": "Description of growth potential",
      "timeframe": "Estimated timeframe to transition to this role",
      "recommendedEducation": ["Educational Institution 1", "Educational Institution 2"]
    }
  ],
  "generalAdvice": "General career advancement advice specific to the user's situation"
}

Provide 3-5 distinct career paths. Make sure all the JSON is properly formatted and valid.

${query.location ? `For the "recommendedEducation" field in each career path, suggest 2-3 real educational institutions, programs, or online learning platforms in or near ${query.location} that offer relevant courses or degrees for that career path. If you don't know specific institutions in that location, suggest well-known online learning platforms that would be accessible from anywhere.` : 'You can leave the "recommendedEducation" field as an empty array if no specific educational recommendations are available.'}`
      }]
    });
    
    // Access the text content safely
    let responseText = '';
    if (response.content[0].type === 'text') {
      responseText = response.content[0].text;
    } else {
      throw new Error("Unexpected response format from AI");
    }
    
    try {
      // Extract JSON from the response (in case there's additional text)
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        throw new Error("No valid JSON found in response");
      }
      
      const parsedResponse: CareerPathResponse = JSON.parse(jsonMatch[0]);
      
      // Validate structure to ensure it matches our expected format
      if (!parsedResponse.currentAssessment || 
          !Array.isArray(parsedResponse.recommendedPaths) || 
          !parsedResponse.generalAdvice) {
        throw new Error("Invalid response structure");
      }
      
      return parsedResponse;
    } catch (jsonError) {
      console.error("Error parsing AI response:", jsonError);
      throw new Error("Failed to process career recommendations. Please try again.");
    }
  } catch (error) {
    console.error("Error generating career path recommendations:", error);
    throw new Error("Failed to generate career recommendations. Please try again later.");
  }
}

export type TrendInsight = {
  trendName: string;
  description: string;
  impactLevel: 'High' | 'Medium' | 'Low';
  timeframe: 'Current' | 'Emerging' | 'Future';
  relevantSkills: string[];
  industries: string[];
  demandMetric: number; // 1-100
  recommendedActions: string[];
};

export type CareerTrendReport = {
  industryOverview: string;
  topTrends: TrendInsight[];
  skillsAnalysis: {
    inDemandSkills: string[];
    decliningSkills: string[];
    emergingSkills: string[];
  };
  salaryTrends: {
    overview: string;
    ranges: {
      role: string;
      range: string;
      growth: string;
    }[];
  };
  recommendations: {
    shortTerm: string[];
    longTerm: string[];
  };
};

/**
 * Generates career trend insights based on the industry and skills
 * @param industry The target industry
 * @param skills Current skills the user has
 * @param jobTitle Current or target job title
 * @param location Optional location for regional insights
 * @returns Career trend insights and recommendations
 */
export async function generateCareerTrendInsights(
  industry: string,
  skills: string[],
  jobTitle: string,
  location?: string
): Promise<CareerTrendReport> {
  try {
    const response = await anthropic.messages.create({
      model: "claude-3-7-sonnet-20250219",
      max_tokens: 2000,
      temperature: 0.7,
      system: "You are a career market analysis expert with access to the latest labor market data and trends. Provide detailed, actionable, and data-backed insights on career trends.",
      messages: [{
        role: 'user',
        content: `Generate a detailed career trend analysis for the following profile:

Industry: ${industry}
Current/Target Role: ${jobTitle}
Skills: ${skills.join(', ')}
${location ? `Location: ${location}` : 'Location: Global (provide general insights)'}

Please format your response as valid JSON with the following structure:
{
  "industryOverview": "A paragraph with a concise overview of the current state and direction of the industry",
  "topTrends": [
    {
      "trendName": "Name of the trend",
      "description": "Detailed description of the trend",
      "impactLevel": "High/Medium/Low",
      "timeframe": "Current/Emerging/Future",
      "relevantSkills": ["Skill 1", "Skill 2", "Skill 3"],
      "industries": ["Industry 1", "Industry 2"],
      "demandMetric": 85,
      "recommendedActions": ["Action 1", "Action 2"]
    }
  ],
  "skillsAnalysis": {
    "inDemandSkills": ["Skill 1", "Skill 2", "Skill 3"],
    "decliningSkills": ["Skill 1", "Skill 2"],
    "emergingSkills": ["Skill 1", "Skill 2", "Skill 3"]
  },
  "salaryTrends": {
    "overview": "Overview of salary trends in this field",
    "ranges": [
      {
        "role": "Role title",
        "range": "Salary range",
        "growth": "Year-over-year growth percentage or description"
      }
    ]
  },
  "recommendations": {
    "shortTerm": ["Short term recommendation 1", "Short term recommendation 2"],
    "longTerm": ["Long term recommendation 1", "Long term recommendation 2"]
  }
}

Include 4-6 topTrends and provide accurate, realistic data based on actual market conditions. Make the insights specific to the provided industry, skills, and job title. All demand metrics should be 1-100, with higher numbers indicating higher demand. Provide 3-5 actionable recommendations for each timeframe.

Ensure all JSON is properly formatted and valid. Keep the response focused on real, evidence-based market trends without speculative information.`
      }]
    });
    
    // Access the text content safely
    let responseText = '';
    if (response.content[0].type === 'text') {
      responseText = response.content[0].text;
    } else {
      throw new Error("Unexpected response format from AI");
    }
    
    try {
      // Extract JSON from the response (in case there's additional text)
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        throw new Error("No valid JSON found in response");
      }
      
      const parsedResponse: CareerTrendReport = JSON.parse(jsonMatch[0]);
      
      // Validate structure to ensure it matches our expected format
      if (!parsedResponse.industryOverview || 
          !Array.isArray(parsedResponse.topTrends) || 
          !parsedResponse.skillsAnalysis ||
          !parsedResponse.recommendations) {
        throw new Error("Invalid response structure");
      }
      
      return parsedResponse;
    } catch (jsonError) {
      console.error("Error parsing AI response:", jsonError);
      throw new Error("Failed to process career trend insights. Please try again.");
    }
  } catch (error) {
    console.error("Error generating career trend insights:", error);
    throw new Error("Failed to generate career trend insights. Please try again later.");
  }
}