import { pgTable, text, serial, integer, boolean, timestamp, jsonb, varchar, primaryKey } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from 'drizzle-orm';

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  fullName: text("full_name"),
  isPremium: boolean("is_premium").default(false),
  isAdmin: boolean("is_admin").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Resumes table
export const resumes = pgTable("resumes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  data: jsonb("data").notNull(), // Stores the entire resume data as JSON
  templateId: text("template_id").notNull(),
  isDefault: boolean("is_default").default(false),
  isPublic: boolean("is_public").default(false), // Controls if resume can be publicly shared
  shareableLink: text("shareable_link").unique(), // UUID for sharing without login
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Team/Collaboration table - store resume collaborators
export const collaborators = pgTable("collaborators", {
  id: serial("id").primaryKey(),
  resumeId: integer("resume_id").notNull().references(() => resumes.id),
  userId: integer("user_id").notNull().references(() => users.id),
  role: text("role").notNull().default('viewer'), // 'viewer', 'editor', 'owner'
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Feedback/Comments table
export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  resumeId: integer("resume_id").notNull().references(() => resumes.id),
  userId: integer("user_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  section: text("section"), // Which section of the resume (e.g., 'summary', 'experience-1', etc.)
  resolved: boolean("resolved").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Invitations for resume collaboration
export const invitations = pgTable("invitations", {
  id: serial("id").primaryKey(),
  resumeId: integer("resume_id").notNull().references(() => resumes.id),
  invitedByUserId: integer("invited_by_user_id").notNull().references(() => users.id),
  email: text("email").notNull(),
  role: text("role").notNull().default('viewer'), // 'viewer', 'editor'
  token: text("token").notNull().unique(), // Invitation token
  accepted: boolean("accepted").default(false),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Affiliate marketing tracking
export const affiliateClicks = pgTable("affiliate_clicks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  institution: text("institution").notNull(),
  isAffiliate: boolean("is_affiliate").notNull().default(false),
  earnedCredits: boolean("earned_credits").notNull().default(false),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

// Notifications
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  type: text("type").notNull(), // 'comment', 'invitation', etc.
  content: text("content").notNull(),
  relatedId: integer("related_id"), // ID of the related item (comment, invitation, etc.)
  read: boolean("read").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Visitor/Analytics tracking - New Table
export const visitors = pgTable("visitors", {
  id: serial("id").primaryKey(),
  visitorId: text("visitor_id").notNull(), // Fingerprint ID
  userId: integer("user_id").references(() => users.id), // If logged in
  userAgent: text("user_agent").notNull(),
  ip: text("ip"),
  country: text("country"),
  city: text("city"),
  region: text("region"), 
  os: text("os"),
  browser: text("browser"),
  device: text("device"),
  referrer: text("referrer"),
  landingPage: text("landing_page").notNull(),
  firstVisit: timestamp("first_visit").notNull().defaultNow(),
  lastVisit: timestamp("last_visit").notNull().defaultNow(),
  visitCount: integer("visit_count").notNull().default(1),
});

// Page Views - New Table
export const pageViews = pgTable("page_views", {
  id: serial("id").primaryKey(),
  visitorId: text("visitor_id").notNull().references(() => visitors.visitorId),
  userId: integer("user_id").references(() => users.id), // If logged in
  path: text("path").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  duration: integer("duration"), // Time spent on page in seconds
  exitPage: boolean("exit_page").default(false), // Was this the last page in the session
});

// Session Recordings - New Table
export const sessionRecordings = pgTable("session_recordings", {
  id: serial("id").primaryKey(),
  visitorId: text("visitor_id").notNull().references(() => visitors.visitorId),
  userId: integer("user_id").references(() => users.id), // If logged in
  sessionId: text("session_id").notNull().unique(),
  startTime: timestamp("start_time").notNull().defaultNow(),
  endTime: timestamp("end_time"),
  duration: integer("duration"), // Session duration in seconds
  events: jsonb("events").notNull(), // Compressed session replay data
  userAgent: text("user_agent"),
  deviceType: text("device_type"),
  country: text("country"),
  city: text("city"),
});

// Define relationships
export const usersRelations = relations(users, ({ many }) => ({
  resumes: many(resumes),
  collaborations: many(collaborators),
  comments: many(comments),
  sentInvitations: many(invitations, { relationName: "sentInvitations" }),
  notifications: many(notifications),
  affiliateClicks: many(affiliateClicks),
  visitors: many(visitors),
  pageViews: many(pageViews),
  sessionRecordings: many(sessionRecordings),
}));

export const affiliateClicksRelations = relations(affiliateClicks, ({ one }) => ({
  user: one(users, {
    fields: [affiliateClicks.userId],
    references: [users.id],
  }),
}));

export const resumesRelations = relations(resumes, ({ one, many }) => ({
  user: one(users, {
    fields: [resumes.userId],
    references: [users.id],
  }),
  collaborators: many(collaborators),
  comments: many(comments),
  invitations: many(invitations),
}));

export const collaboratorsRelations = relations(collaborators, ({ one }) => ({
  resume: one(resumes, {
    fields: [collaborators.resumeId],
    references: [resumes.id],
  }),
  user: one(users, {
    fields: [collaborators.userId],
    references: [users.id],
  }),
}));

export const commentsRelations = relations(comments, ({ one }) => ({
  resume: one(resumes, {
    fields: [comments.resumeId],
    references: [resumes.id],
  }),
  user: one(users, {
    fields: [comments.userId],
    references: [users.id],
  }),
}));

export const invitationsRelations = relations(invitations, ({ one }) => ({
  resume: one(resumes, {
    fields: [invitations.resumeId],
    references: [resumes.id],
  }),
  invitedBy: one(users, {
    fields: [invitations.invitedByUserId],
    references: [users.id],
    relationName: "sentInvitations"
  }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, {
    fields: [notifications.userId],
    references: [users.id],
  }),
}));

// Visitor relations - New
export const visitorsRelations = relations(visitors, ({ one, many }) => ({
  user: one(users, {
    fields: [visitors.userId],
    references: [users.id],
  }),
  pageViews: many(pageViews),
  sessionRecordings: many(sessionRecordings),
}));

// Page views relations - New
export const pageViewsRelations = relations(pageViews, ({ one }) => ({
  visitor: one(visitors, {
    fields: [pageViews.visitorId],
    references: [visitors.visitorId],
  }),
  user: one(users, {
    fields: [pageViews.userId],
    references: [users.id],
  }),
}));

// Session recordings relations - New
export const sessionRecordingsRelations = relations(sessionRecordings, ({ one }) => ({
  visitor: one(visitors, {
    fields: [sessionRecordings.visitorId],
    references: [visitors.visitorId],
  }),
  user: one(users, {
    fields: [sessionRecordings.userId],
    references: [users.id],
  }),
}));

// Create insert schemas for validation
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  fullName: true,
  isPremium: true,
  isAdmin: true,
});

export const insertResumeSchema = createInsertSchema(resumes).pick({
  userId: true,
  title: true,
  data: true,
  templateId: true,
  isDefault: true,
  isPublic: true,
  shareableLink: true,
});

export const insertCollaboratorSchema = createInsertSchema(collaborators).pick({
  resumeId: true,
  userId: true,
  role: true,
});

export const insertCommentSchema = createInsertSchema(comments).pick({
  resumeId: true,
  userId: true,
  content: true,
  section: true,
  resolved: true,
});

export const insertInvitationSchema = createInsertSchema(invitations).pick({
  resumeId: true,
  invitedByUserId: true,
  email: true,
  role: true,
  token: true,
  expiresAt: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).pick({
  userId: true,
  type: true,
  content: true,
  relatedId: true,
});

export const insertAffiliateClickSchema = createInsertSchema(affiliateClicks).pick({
  userId: true,
  institution: true,
  isAffiliate: true,
  earnedCredits: true,
});

// New insert schemas for visitors, page views, and session recordings
export const insertVisitorSchema = createInsertSchema(visitors).pick({
  visitorId: true,
  userId: true,
  userAgent: true,
  ip: true,
  country: true,
  city: true,
  region: true,
  os: true,
  browser: true,
  device: true,
  referrer: true,
  landingPage: true,
  firstVisit: true,
  lastVisit: true,
  visitCount: true,
});

export const insertPageViewSchema = createInsertSchema(pageViews).pick({
  visitorId: true,
  userId: true,
  path: true,
  timestamp: true,
  duration: true,
  exitPage: true,
});

export const insertSessionRecordingSchema = createInsertSchema(sessionRecordings).pick({
  visitorId: true,
  userId: true,
  sessionId: true,
  startTime: true,
  endTime: true,
  duration: true,
  events: true,
  userAgent: true,
  deviceType: true,
  country: true,
  city: true,
});

// Define types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertResume = z.infer<typeof insertResumeSchema>;
export type Resume = typeof resumes.$inferSelect;

export type InsertCollaborator = z.infer<typeof insertCollaboratorSchema>;
export type Collaborator = typeof collaborators.$inferSelect;

export type InsertComment = z.infer<typeof insertCommentSchema>;
export type Comment = typeof comments.$inferSelect;

export type InsertInvitation = z.infer<typeof insertInvitationSchema>;
export type Invitation = typeof invitations.$inferSelect;

export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;

export type InsertAffiliateClick = z.infer<typeof insertAffiliateClickSchema>;
export type AffiliateClick = typeof affiliateClicks.$inferSelect;

// New types for visitors, page views, and session recordings
export type InsertVisitor = z.infer<typeof insertVisitorSchema>;
export type Visitor = typeof visitors.$inferSelect;

export type InsertPageView = z.infer<typeof insertPageViewSchema>;
export type PageView = typeof pageViews.$inferSelect;

export type InsertSessionRecording = z.infer<typeof insertSessionRecordingSchema>;
export type SessionRecording = typeof sessionRecordings.$inferSelect;
