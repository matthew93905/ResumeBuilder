# Architecture

## Overview

ResumeX is a full-stack web application designed to help users create professional resumes. The application features a client-server architecture with a React frontend and a Node.js Express backend. It leverages PostgreSQL for data persistence through Drizzle ORM and includes several third-party integrations (Stripe, PayPal, Anthropic AI, etc.) to enhance the user experience.

## System Architecture

The application follows a modern web architecture pattern:

1. **Frontend**: React-based single-page application (SPA) with TypeScript
2. **Backend**: Node.js with Express.js, running in ESM module format
3. **Database**: PostgreSQL accessed through Drizzle ORM
4. **Authentication**: Custom session-based authentication with Passport.js
5. **AI Integration**: Claude AI by Anthropic for resume content enhancement
6. **Payment Processing**: Stripe and PayPal integrations
7. **Build & Bundling**: Vite for frontend, esbuild for backend

The application is structured with clear separation between client and server components:

```
/
├── client/                 # Frontend React application
├── server/                 # Backend Express server
├── shared/                 # Shared code (schemas, types)
└── migrations/             # Database migrations
```

## Key Components

### Frontend Architecture

The frontend is built with React and follows a component-based architecture:

1. **Pages**: Main route components that compose the application views
   - Home, Builder, ResumeList, Checkout, etc.

2. **Components**: Reusable UI elements
   - Form inputs, resume templates, collaboration tools, etc.

3. **Hooks**: Custom React hooks for state management and business logic
   - `useAuth`, `useResume`, `useTheme`, `useSaveResume`, etc.

4. **Libraries**:
   - UI Framework: Custom components based on Radix UI with Tailwind CSS
   - Routing: Wouter (lightweight alternative to React Router)
   - Data Fetching: TanStack Query (React Query)
   - Form Handling: React Hook Form

### Backend Architecture

The server is built with Express.js and follows a modular architecture:

1. **API Routes**: RESTful endpoints for client-server communication
   - Authentication, resume operations, payment processing, etc.

2. **Database Access**: Storage layer with Drizzle ORM
   - SQL schema definitions in `shared/schema.ts`
   - Database connection and query execution

3. **Authentication**: Passport.js with local strategy
   - Session management with express-session
   - Password hashing with crypto scrypt

4. **External Service Integrations**:
   - AI: Anthropic's Claude for content enhancement
   - Payments: Stripe and PayPal
   - Email: SendGrid

### Database Schema

The database schema is defined using Drizzle ORM and includes the following key tables:

1. **users**: User accounts and authentication
2. **resumes**: User-created resumes with JSON data
3. **collaborators**: Tracks resume collaboration permissions
4. **comments**: Feedback and comments on resumes
5. **visitors**, **page_views**, **session_recordings**: Analytics tracking

Additional tables support features like invitations, notifications, and affiliate tracking.

## Data Flow

### Resume Creation Flow

1. User authenticates via `/api/login` endpoint
2. Client loads the resume builder interface
3. User inputs resume data, which is stored in client-side state
4. On save, data is sent to the server via `/api/resume` endpoint
5. Server validates and stores resume data in the PostgreSQL database
6. User can view all resumes via `/api/resumes` endpoint
7. PDF export is generated client-side using html2canvas and jsPDF

### Collaboration Flow

1. Resume owner invites collaborators via email
2. Server creates invitation record and sends notification
3. Collaborator accepts invitation and gains access based on assigned role
4. Real-time collaboration occurs via WebSocket connections
5. Comments and feedback are stored in the database and synchronized between users

### Payment Processing Flow

1. User selects premium features or subscription
2. Client initiates checkout process with Stripe or PayPal
3. Payment confirmation is processed by the server
4. User account is updated with premium status
5. User gains access to premium templates and features

## External Dependencies

### Frontend Dependencies

- **UI Components**: Radix UI primitives with TailwindCSS styling
- **State Management**: React Context and TanStack Query
- **Data Fetching**: TanStack Query for server-state management
- **PDF Generation**: html2canvas and jsPDF

### Backend Dependencies

- **Database**: PostgreSQL via Neon Database (serverless Postgres)
- **ORM**: Drizzle ORM for type-safe database access
- **Authentication**: Passport.js with session-based auth
- **AI**: Anthropic Claude for content enhancement
- **Payments**: Stripe and PayPal SDKs
- **Email**: SendGrid for transactional emails
- **Analytics**: Custom implementation with fingerprinting and session tracking

## Deployment Strategy

The application is configured for deployment on Replit, with different environments:

### Development Environment

- Uses `npm run dev` command
- Vite's hot module replacement for frontend development
- Node server with automatic restart through tsx

### Production Environment

- Build process:
  1. Vite builds the frontend assets
  2. esbuild bundles the server code
- Runtime:
  - Static assets served by Express
  - API routes handled by the same Express server
  - WebSocket server for real-time collaboration

### Environment Variables

Key environment variables include:
- `DATABASE_URL`: PostgreSQL connection string
- `SESSION_SECRET`: For secure session cookies
- `STRIPE_SECRET_KEY`/`PAYPAL_CLIENT_ID`: Payment API credentials
- `ANTHROPIC_API_KEY`: For AI features
- `NODE_ENV`: To differentiate between development and production

### Scaling Considerations

- Database: Using Neon Database (serverless Postgres) allows for automatic scaling
- Stateless architecture: The application can horizontally scale behind a load balancer
- Session management: Sessions are stored in PostgreSQL, enabling distributed deployments