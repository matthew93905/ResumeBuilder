import { apiRequest } from "./queryClient";

// Dynamically import heavy libraries to prevent them from blocking initial page load
let FingerprintJS: any = null;
let rrweb: any = null;

// Import libraries only when needed
const loadDependencies = async () => {
  if (!FingerprintJS) {
    FingerprintJS = (await import('@fingerprintjs/fingerprintjs')).default;
  }
  if (!rrweb) {
    rrweb = await import('rrweb');
  }
};

// Initialize fingerprint instance
let fpPromise: Promise<import('@fingerprintjs/fingerprintjs').Agent> | null = null;

// Initialize analytics state
let initialized = false;
let visitorId: string | null = null;
let sessionId: string | null = null;
let sessionEvents: any[] = [];
let pageViewStartTime: number = 0;
let currentPath: string = '';
let recordingActive = false;
let stopRecordingCallback: (() => void) | null = null;

/**
 * Initialize the analytics tracking
 */
export async function initAnalytics() {
  if (initialized) return;
  
  try {
    // First load all required dependencies
    await loadDependencies();
    
    // Generate visitor ID using FingerprintJS
    if (!fpPromise && FingerprintJS) {
      fpPromise = FingerprintJS.load();
    }
    
    if (fpPromise) {
      const fp = await fpPromise;
      const result = await fp.get();
      
      // Get unique visitor ID
      visitorId = result.visitorId;
      
      // Generate a session ID
      sessionId = generateSessionId();
      
      // Track the initial page view
      const referrer = document.referrer;
      const path = window.location.pathname;
      
      // Send tracking information to the server
      await trackVisitor(referrer, path);
      
      // Start page view timer
      startPageViewTimer(path);
      
      // Set up event listeners for page navigation
      window.addEventListener('beforeunload', handleBeforeUnload);
      
      // Initialize session recording with rrweb if in production
      if (process.env.NODE_ENV === 'production' && rrweb) {
        startSessionRecording();
      }
      
      initialized = true;
      console.log('Analytics initialized successfully');
    } else {
      console.warn('Failed to initialize FingerprintJS');
    }
  } catch (error) {
    console.error('Failed to initialize analytics:', error);
    // Don't block the application if analytics fails
    initialized = true; // Mark as initialized to prevent repeated attempts
  }
}

/**
 * Get tracking parameters from localStorage
 */
function getStoredTrackingParams() {
  try {
    // Get stored tracking parameters
    const utmParams = localStorage.getItem('resumex_utm_params');
    const referralParams = localStorage.getItem('resumex_referral_params');
    const clickIdParams = localStorage.getItem('resumex_click_ids');
    const firstTouch = localStorage.getItem('resumex_first_touch');
    
    return {
      utm: utmParams ? JSON.parse(utmParams) : {},
      referral: referralParams ? JSON.parse(referralParams) : {},
      clickIds: clickIdParams ? JSON.parse(clickIdParams) : {},
      firstTouch: firstTouch ? JSON.parse(firstTouch) : {}
    };
  } catch (error) {
    console.error('Failed to parse tracking parameters:', error);
    return { utm: {}, referral: {}, clickIds: {}, firstTouch: {} };
  }
}

/**
 * Track visitor information
 */
async function trackVisitor(referrer: string, path: string) {
  if (!visitorId) return;
  
  try {
    // Get stored tracking parameters
    const trackingParams = getStoredTrackingParams();
    
    await apiRequest('POST', '/api/analytics/track', {
      visitorId,
      referrer,
      path,
      trackingData: {
        ...trackingParams.utm,
        ...trackingParams.referral,
        ...trackingParams.clickIds,
        firstTouch: trackingParams.firstTouch
      }
    });
  } catch (error) {
    console.error('Failed to track visitor:', error);
  }
}

/**
 * Track a page view with duration
 */
export async function trackPageView(path: string, exitPage = false) {
  if (!visitorId || !initialized) return;
  
  // Calculate duration of the previous page view
  const duration = pageViewStartTime > 0 ? Math.floor((Date.now() - pageViewStartTime) / 1000) : null;
  
  // Only track if there was a previous page
  if (currentPath && currentPath !== path) {
    try {
      await apiRequest('POST', '/api/analytics/page-view', {
        visitorId,
        path: currentPath,
        duration,
        exitPage
      });
    } catch (error) {
      console.error('Failed to track page view:', error);
    }
  }
  
  // Update current path and reset timer
  currentPath = path;
  startPageViewTimer(path);
}

/**
 * Start the timer for the current page view
 */
function startPageViewTimer(path: string) {
  pageViewStartTime = Date.now();
  currentPath = path;
}

/**
 * Handle the beforeunload event to track the final page view
 */
function handleBeforeUnload() {
  // Track the current page view with exit flag
  trackPageView(currentPath, true);
  
  // Stop recording session
  if (stopRecordingCallback) {
    stopRecordingCallback();
  }
  
  // Send the recording data (using sendBeacon for reliability during page unload)
  if (sessionEvents.length > 0 && visitorId && sessionId) {
    const data = {
      visitorId,
      sessionId,
      events: sessionEvents
    };
    
    // Use navigator.sendBeacon for reliability during page unload
    navigator.sendBeacon('/api/analytics/record-session', JSON.stringify(data));
  }
}

/**
 * Start recording the user session
 */
function startSessionRecording() {
  if (recordingActive || !visitorId || !sessionId || !rrweb) return;
  
  try {
    // Start recording
    const stopFn = rrweb.record({
      emit(event: any) {
        // Add event to the buffer
        sessionEvents.push(event);
        
        // Send events to the server in batches if needed
        if (sessionEvents.length > 100) {
          sendRecordingEvents();
        }
      },
      recordCanvas: true,
      recordCrossOriginIframes: false,
      blockClass: 'rrweb-block', // Add this class to elements you don't want to record
      ignoreClass: 'rrweb-ignore', // Add this class to elements you want to skip entirely
      maskAllInputs: true, // Mask all input values
    });
    
    // Assign the stop function to our callback (and handle the type correctly)
    stopRecordingCallback = typeof stopFn === 'function' ? stopFn : null;
    
    if (stopRecordingCallback) {
      recordingActive = true;
      console.log('Session recording started');
      
      // Set up automatic sending of events every minute
      const intervalId = setInterval(() => {
        if (sessionEvents.length > 0) {
          sendRecordingEvents();
        }
      }, 60000);
      
      // Enhance the stop callback to clear the interval
      const originalStopCallback = stopRecordingCallback;
      stopRecordingCallback = () => {
        if (originalStopCallback) {
          originalStopCallback();
        }
        clearInterval(intervalId);
        sendRecordingEvents();
        recordingActive = false;
      };
    } else {
      console.warn('Session recording could not be started: invalid stop function');
    }
  } catch (error) {
    console.error('Failed to start session recording:', error);
    recordingActive = false;
  }
}

/**
 * Send recording events to the server
 */
async function sendRecordingEvents() {
  if (sessionEvents.length === 0 || !visitorId || !sessionId) return;
  
  try {
    await apiRequest('POST', '/api/analytics/record-session', {
      visitorId,
      sessionId,
      events: sessionEvents.slice() // Send a copy of events
    });
    
    // Clear the events array after successful send
    sessionEvents = [];
  } catch (error) {
    console.error('Failed to send recording events:', error);
  }
}

/**
 * Generate a unique session ID
 */
function generateSessionId(): string {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 15)}`;
}

/**
 * Clean up event listeners and recordings
 */
export function cleanupAnalytics() {
  window.removeEventListener('beforeunload', handleBeforeUnload);
  
  if (stopRecordingCallback) {
    stopRecordingCallback();
    stopRecordingCallback = null;
  }
  
  initialized = false;
  recordingActive = false;
}