import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

// Generate a PDF from a resume object
export async function exportResumeToPdf(resume: any, filename: string = 'resume'): Promise<void> {
  // Create a temporary container to render the resume
  const container = document.createElement('div');
  container.style.position = 'absolute';
  container.style.left = '-9999px';
  container.style.width = '8.5in'; // US Letter size
  container.style.height = 'auto';
  container.style.backgroundColor = 'white';
  container.style.color = 'black';
  container.style.padding = '0.5in';
  container.style.overflow = 'hidden';
  document.body.appendChild(container);
  
  try {
    // Format and render the resume data into the container
    await renderResumeToContainer(resume, container);
    
    // Convert to canvas
    const canvas = await html2canvas(container, {
      scale: 2, // Higher resolution
      useCORS: true,
      allowTaint: true,
      backgroundColor: '#ffffff'
    });
    
    // Initialize PDF
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'px',
      format: 'letter'
    });
    
    // Calculate dimensions
    const imgWidth = 8.5 * 72; // 8.5 inches at 72 PPI
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    
    // Add image to PDF (the canvas)
    pdf.addImage(
      canvas.toDataURL('image/png'),
      'PNG',
      0,
      0,
      imgWidth,
      imgHeight,
      undefined,
      'FAST'
    );
    
    // Save the PDF
    pdf.save(`${filename}.pdf`);
  } catch (error) {
    console.error('Error generating PDF:', error);
    throw new Error('Failed to generate PDF');
  } finally {
    // Clean up the temporary container
    document.body.removeChild(container);
  }
}

// Helper function to render resume data into the HTML container
async function renderResumeToContainer(resume: any, container: HTMLElement): Promise<void> {
  // For now, we'll create a simple layout; 
  // This can be enhanced to match any of your resume templates
  
  // Create header with personal info
  const header = document.createElement('div');
  header.style.textAlign = 'center';
  header.style.marginBottom = '20px';
  
  const name = document.createElement('h1');
  name.textContent = resume.personalInfo?.name || 'Your Name';
  name.style.fontSize = '28px';
  name.style.margin = '0 0 10px 0';
  
  const jobTitle = document.createElement('h2');
  jobTitle.textContent = resume.personalInfo?.jobTitle || 'Professional Title';
  jobTitle.style.fontSize = '18px';
  jobTitle.style.fontWeight = 'normal';
  jobTitle.style.margin = '0 0 10px 0';
  jobTitle.style.color = '#555';
  
  const contactInfo = document.createElement('div');
  contactInfo.style.fontSize = '14px';
  contactInfo.style.display = 'flex';
  contactInfo.style.justifyContent = 'center';
  contactInfo.style.gap = '20px';
  
  contactInfo.innerHTML = `
    <span>${resume.personalInfo?.email || 'email@example.com'}</span> |
    <span>${resume.personalInfo?.phone || '(123) 456-7890'}</span> |
    <span>${resume.personalInfo?.city || 'City'}, ${resume.personalInfo?.state || 'State'}</span>
    ${resume.personalInfo?.linkedin ? `| <span>${resume.personalInfo.linkedin}</span>` : ''}
  `;
  
  header.appendChild(name);
  header.appendChild(jobTitle);
  header.appendChild(contactInfo);
  
  // Summary section
  const summary = document.createElement('div');
  summary.style.marginBottom = '20px';
  
  const summaryTitle = document.createElement('h3');
  summaryTitle.textContent = 'Professional Summary';
  summaryTitle.style.fontSize = '16px';
  summaryTitle.style.borderBottom = '1px solid #ddd';
  summaryTitle.style.paddingBottom = '5px';
  
  const summaryContent = document.createElement('p');
  summaryContent.textContent = resume.summary?.content || 'Professional summary goes here.';
  summaryContent.style.fontSize = '14px';
  summaryContent.style.lineHeight = '1.5';
  
  summary.appendChild(summaryTitle);
  summary.appendChild(summaryContent);
  
  // Experience section
  const experience = document.createElement('div');
  experience.style.marginBottom = '20px';
  
  const experienceTitle = document.createElement('h3');
  experienceTitle.textContent = 'Work Experience';
  experienceTitle.style.fontSize = '16px';
  experienceTitle.style.borderBottom = '1px solid #ddd';
  experienceTitle.style.paddingBottom = '5px';
  
  experience.appendChild(experienceTitle);
  
  if (resume.experience && resume.experience.length > 0) {
    resume.experience.forEach((job: any) => {
      const jobItem = document.createElement('div');
      jobItem.style.marginBottom = '15px';
      
      const jobHeader = document.createElement('div');
      jobHeader.style.display = 'flex';
      jobHeader.style.justifyContent = 'space-between';
      jobHeader.style.alignItems = 'flex-start';
      
      const positionCompany = document.createElement('div');
      
      const position = document.createElement('h4');
      position.textContent = job.position || 'Job Title';
      position.style.fontSize = '15px';
      position.style.margin = '0';
      
      const company = document.createElement('div');
      company.textContent = `${job.company || 'Company'}, ${job.location || 'Location'}`;
      company.style.fontSize = '14px';
      
      const dates = document.createElement('div');
      dates.textContent = `${job.startDate || 'Start Date'} - ${job.current ? 'Present' : (job.endDate || 'End Date')}`;
      dates.style.fontSize = '14px';
      
      positionCompany.appendChild(position);
      positionCompany.appendChild(company);
      
      jobHeader.appendChild(positionCompany);
      jobHeader.appendChild(dates);
      
      jobItem.appendChild(jobHeader);
      
      if (job.description && job.description.length > 0) {
        const descList = document.createElement('ul');
        descList.style.fontSize = '14px';
        descList.style.paddingLeft = '20px';
        
        job.description.forEach((desc: string) => {
          const item = document.createElement('li');
          item.textContent = desc;
          item.style.marginBottom = '5px';
          descList.appendChild(item);
        });
        
        jobItem.appendChild(descList);
      }
      
      experience.appendChild(jobItem);
    });
  }
  
  // Education section
  const education = document.createElement('div');
  education.style.marginBottom = '20px';
  
  const educationTitle = document.createElement('h3');
  educationTitle.textContent = 'Education';
  educationTitle.style.fontSize = '16px';
  educationTitle.style.borderBottom = '1px solid #ddd';
  educationTitle.style.paddingBottom = '5px';
  
  education.appendChild(educationTitle);
  
  if (resume.education && resume.education.length > 0) {
    resume.education.forEach((edu: any) => {
      const eduItem = document.createElement('div');
      eduItem.style.marginBottom = '15px';
      
      const eduHeader = document.createElement('div');
      eduHeader.style.display = 'flex';
      eduHeader.style.justifyContent = 'space-between';
      eduHeader.style.alignItems = 'flex-start';
      
      const degreeSchool = document.createElement('div');
      
      const degree = document.createElement('h4');
      degree.textContent = `${edu.degree || 'Degree'} ${edu.field ? 'in ' + edu.field : ''}`;
      degree.style.fontSize = '15px';
      degree.style.margin = '0';
      
      const school = document.createElement('div');
      school.textContent = `${edu.institution || 'Institution'}, ${edu.location || 'Location'}`;
      school.style.fontSize = '14px';
      
      const dates = document.createElement('div');
      dates.textContent = `${edu.startDate || 'Start Date'} - ${edu.endDate || 'End Date'}`;
      dates.style.fontSize = '14px';
      
      degreeSchool.appendChild(degree);
      degreeSchool.appendChild(school);
      
      eduHeader.appendChild(degreeSchool);
      eduHeader.appendChild(dates);
      
      eduItem.appendChild(eduHeader);
      
      if (edu.description) {
        const desc = document.createElement('p');
        desc.textContent = edu.description;
        desc.style.fontSize = '14px';
        desc.style.margin = '5px 0 0 0';
        eduItem.appendChild(desc);
      }
      
      education.appendChild(eduItem);
    });
  }
  
  // Skills section
  const skills = document.createElement('div');
  skills.style.marginBottom = '20px';
  
  const skillsTitle = document.createElement('h3');
  skillsTitle.textContent = 'Skills';
  skillsTitle.style.fontSize = '16px';
  skillsTitle.style.borderBottom = '1px solid #ddd';
  skillsTitle.style.paddingBottom = '5px';
  
  skills.appendChild(skillsTitle);
  
  if (resume.skills && resume.skills.length > 0) {
    const skillList = document.createElement('div');
    skillList.style.display = 'flex';
    skillList.style.flexWrap = 'wrap';
    skillList.style.gap = '10px';
    skillList.style.fontSize = '14px';
    
    resume.skills.forEach((skill: any) => {
      const skillItem = document.createElement('span');
      skillItem.textContent = skill.name;
      skillItem.style.padding = '3px 8px';
      skillItem.style.backgroundColor = '#f0f0f0';
      skillItem.style.borderRadius = '4px';
      skillList.appendChild(skillItem);
    });
    
    skills.appendChild(skillList);
  }
  
  // Add all sections to container
  container.appendChild(header);
  container.appendChild(summary);
  container.appendChild(experience);
  container.appendChild(education);
  container.appendChild(skills);
}