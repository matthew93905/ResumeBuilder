// Import all template images
import essentialTemplate from '../assets/templates/essential-template.svg';
import executiveTemplate from '../assets/templates/executive-template.svg';
import creativeTemplate from '../assets/templates/creative-template.svg';
import minimalistTemplate from '../assets/templates/minimalist-template.svg';
import modernTemplate from '../assets/templates/modern-template.svg';
import visualImpactTemplate from '../assets/templates/visual-impact-template.svg';
import infographicTemplate from '../assets/templates/infographic-template.svg';
import executivePlusTemplate from '../assets/templates/executive-plus-template.svg';

// Export a mapping of template IDs to imported images
export const templateImages = {
  'essential': essentialTemplate,
  'executive': executiveTemplate,
  'creative': creativeTemplate,
  'minimalist': minimalistTemplate,
  'modern': modernTemplate,
  'visual-impact': visualImpactTemplate,
  'infographic': infographicTemplate,
  'executive-plus': executivePlusTemplate,
};