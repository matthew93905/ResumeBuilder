import { apiRequest } from "./queryClient";

// List of affiliate partner institutions
export const AFFILIATE_PARTNERS = [
  "Harvard University",
  "Stanford University",
  "MIT",
  "Oxford University",
  "Cambridge University",
  "Udemy",
  "Coursera",
  "edX",
  "LinkedIn Learning",
  "Udacity"
];

// Check if an institution is an affiliate partner
export function isAffiliatePartner(institution: string): boolean {
  return AFFILIATE_PARTNERS.includes(institution);
}

// Get stored tracking parameters from localStorage
function getTrackingParams(): Record<string, string> {
  try {
    // Get UTM parameters
    const storedUtmParams = localStorage.getItem('resumex_utm_params');
    const utmParams = storedUtmParams ? JSON.parse(storedUtmParams) : {};
    
    // Get first touch information (for attribution)
    const storedFirstTouch = localStorage.getItem('resumex_first_touch');
    const firstTouch = storedFirstTouch ? JSON.parse(storedFirstTouch) : {};
    
    // Return a simplified object with the key tracking parameters
    return {
      utm_source: utmParams.utm_source || firstTouch.utm_source || 'direct',
      utm_medium: utmParams.utm_medium || firstTouch.utm_medium || 'none',
      utm_campaign: utmParams.utm_campaign || firstTouch.utm_campaign || 'organic',
      referrer: firstTouch.referrer || 'direct',
      source: 'resumex' // Always identify our platform as the source
    };
  } catch (error) {
    console.error('Error retrieving tracking parameters:', error);
    return {
      utm_source: 'direct',
      utm_medium: 'none',
      utm_campaign: 'organic',
      referrer: 'direct',
      source: 'resumex'
    };
  }
}

// Get affiliate link information for an institution
export function getAffiliateLink(institution: string): { url: string; isAffiliate: boolean } {
  const isAffiliate = isAffiliatePartner(institution);
  
  // Generate a URL - in a real implementation, this would be a proper affiliate link
  // For now, we'll create a Google search URL with tracking parameters
  const encodedName = encodeURIComponent(institution);
  
  // Get tracking parameters
  const trackingParams = getTrackingParams();
  
  // Build query parameters for affiliate tracking
  const queryParams = new URLSearchParams({
    q: `${institution} courses`,
    partner: 'resumex',
    utm_source: 'resumex',
    utm_medium: 'affiliate',
    utm_campaign: 'career_recommendations',
    utm_content: encodedName,
    utm_term: encodedName
  }).toString();
  
  const url = `https://www.google.com/search?${queryParams}`;
  
  return { url, isAffiliate };
}

// Track an affiliate link click
export async function trackAffiliateClick(institution: string, isAffiliate?: boolean): Promise<void> {
  try {
    // If isAffiliate is not provided, determine it
    const affiliateStatus = isAffiliate ?? isAffiliatePartner(institution);
    
    // Get tracking parameters from localStorage
    const trackingParams = getTrackingParams();
    
    await apiRequest("POST", "/api/analytics/affiliate-click", {
      institution,
      isAffiliate: affiliateStatus,
      trackingData: {
        ...trackingParams,
        click_timestamp: new Date().toISOString(),
        user_agent: navigator.userAgent,
        screen_size: `${window.innerWidth}x${window.innerHeight}`
      }
    });
    
    console.log(`Tracked ${affiliateStatus ? "affiliate" : "non-affiliate"} click for ${institution}`);
    
    // Store this click in localStorage for client-side tracking
    try {
      const storedClicks = localStorage.getItem('resumex_affiliate_clicks');
      const clicks = storedClicks ? JSON.parse(storedClicks) : [];
      
      clicks.push({
        institution,
        isAffiliate: affiliateStatus,
        timestamp: new Date().toISOString(),
        ...trackingParams
      });
      
      // Keep only the last 20 clicks to avoid localStorage size limits
      if (clicks.length > 20) {
        clicks.shift(); // Remove oldest click
      }
      
      localStorage.setItem('resumex_affiliate_clicks', JSON.stringify(clicks));
    } catch (storageError) {
      console.error("Error saving affiliate click to localStorage:", storageError);
    }
  } catch (error) {
    console.error("Error tracking affiliate click:", error);
  }
}

// Get educational institution recommendations based on location
export function getInstitutionRecommendations(
  location?: string,
  count: number = 3
): { name: string; isAffiliate: boolean }[] {
  // Default recommendations if no location provided
  if (!location) {
    return [
      { name: "Udemy", isAffiliate: true },
      { name: "Coursera", isAffiliate: true },
      { name: "edX", isAffiliate: true }
    ];
  }
  
  // Location-based recommendations
  const locationMap: Record<string, string[]> = {
    "USA": ["Harvard University", "Stanford University", "MIT"],
    "UK": ["Oxford University", "Cambridge University", "Imperial College London"],
    "Canada": ["University of Toronto", "McGill University", "University of British Columbia"],
    "Australia": ["University of Melbourne", "University of Sydney", "Australian National University"],
    "India": ["Indian Institute of Technology", "Indian Institute of Management", "Delhi University"],
    "Germany": ["Technical University of Munich", "Ludwig Maximilian University", "Heidelberg University"],
    "Japan": ["University of Tokyo", "Kyoto University", "Osaka University"],
    "China": ["Tsinghua University", "Peking University", "Fudan University"],
    "France": ["Sorbonne University", "École Normale Supérieure", "Sciences Po"],
    "Singapore": ["National University of Singapore", "Nanyang Technological University", "Singapore Management University"]
  };
  
  // Normalize location to match our keys
  const normalizedLocation = Object.keys(locationMap).find(
    key => location.toLowerCase().includes(key.toLowerCase())
  );
  
  // Get institutions based on location or default to online platforms
  const institutions = normalizedLocation 
    ? locationMap[normalizedLocation]
    : ["Udemy", "Coursera", "edX"];
  
  // Map to objects with affiliate status
  return institutions
    .slice(0, count)
    .map(name => ({
      name,
      isAffiliate: isAffiliatePartner(name)
    }));
}