import { ResumeData } from "@/hooks/use-resume";
import React from "react";
import {
  EssentialTemplateThumbnail,
  ExecutiveTemplateThumbnail,
  CreativeTemplateThumbnail,
  MinimalistTemplateThumbnail,
  ModernTemplateThumbnail,
  VisualImpactTemplateThumbnail,
  InfographicTemplateThumbnail,
  ExecutivePlusTemplateThumbnail
} from '@/components/RealisticTemplateThumbnails';

// Template definitions
export interface Template {
  id: string;
  name: string;
  description: string;
  isPremium: boolean;
  thumbnail: React.ReactNode;
  render: (resumeData: ResumeData) => React.ReactNode;
}

// Essential Template (Free)
export const EssentialTemplate: React.FC<{ resumeData: ResumeData }> = ({ resumeData }) => {
  const { personalInfo, summary, experience, education, skills } = resumeData;

  // Format date display
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
  };

  return (
    <div className="p-8 bg-white text-primary">
      {/* Header Section */}
      <div className="flex items-center space-x-4 mb-6">
        {personalInfo.photo && (
          <div className="w-20 h-20 bg-gray-200 rounded-full overflow-hidden">
            <img 
              src={personalInfo.photo}
              alt={personalInfo.name} 
              className="w-full h-full object-cover"
            />
          </div>
        )}
        <div>
          <h1 className="font-montserrat font-bold text-2xl">{personalInfo.name}</h1>
          <p className="text-gray-600">{personalInfo.jobTitle}</p>
        </div>
      </div>
      
      {/* Contact Details */}
      <div className="grid grid-cols-2 gap-2 text-sm mb-6">
        <div className="flex items-center space-x-1">
          <i className="ri-mail-line text-secondary"></i>
          <span>{personalInfo.email}</span>
        </div>
        <div className="flex items-center space-x-1">
          <i className="ri-phone-line text-secondary"></i>
          <span>{personalInfo.phone}</span>
        </div>
        <div className="flex items-center space-x-1">
          <i className="ri-map-pin-line text-secondary"></i>
          <span>{personalInfo.city}, {personalInfo.state}</span>
        </div>
        {personalInfo.linkedin && (
          <div className="flex items-center space-x-1">
            <i className="ri-linkedin-box-line text-secondary"></i>
            <span>{personalInfo.linkedin}</span>
          </div>
        )}
      </div>
      
      {/* Summary Section */}
      <div className="mb-6">
        <h2 className="font-montserrat font-semibold text-lg border-b border-gray-200 pb-2 mb-3">
          Professional Summary
        </h2>
        <p className="text-sm text-gray-700">
          {summary.content}
        </p>
      </div>
      
      {/* Work Experience */}
      {experience.length > 0 && (
        <div className="mb-6">
          <h2 className="font-montserrat font-semibold text-lg border-b border-gray-200 pb-2 mb-3">
            Work Experience
          </h2>
          
          {experience.map((job) => (
            <div key={job.id} className="mb-4">
              <div className="flex justify-between items-start">
                <h3 className="font-medium text-base">{job.position}</h3>
                <span className="text-sm text-gray-600">
                  {formatDate(job.startDate)} - {job.current ? 'Present' : formatDate(job.endDate)}
                </span>
              </div>
              <p className="text-sm text-gray-600 mb-1">{job.company}, {job.location}</p>
              <ul className="text-sm text-gray-700 list-disc list-inside space-y-1">
                {job.description.map((desc, i) => (
                  <li key={i}>{desc}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      )}
      
      {/* Education */}
      {education.length > 0 && (
        <div className="mb-6">
          <h2 className="font-montserrat font-semibold text-lg border-b border-gray-200 pb-2 mb-3">
            Education
          </h2>
          {education.map((edu) => (
            <div key={edu.id}>
              <div className="flex justify-between items-start">
                <h3 className="font-medium text-base">{edu.degree} in {edu.field}</h3>
                <span className="text-sm text-gray-600">
                  {formatDate(edu.startDate)} - {formatDate(edu.endDate)}
                </span>
              </div>
              <p className="text-sm text-gray-600">{edu.institution}, {edu.location}</p>
              {edu.description && <p className="text-sm mt-1">{edu.description}</p>}
            </div>
          ))}
        </div>
      )}
      
      {/* Skills */}
      {skills.length > 0 && (
        <div>
          <h2 className="font-montserrat font-semibold text-lg border-b border-gray-200 pb-2 mb-3">
            Skills
          </h2>
          <div className="flex flex-wrap gap-2">
            {skills.map((skill) => (
              <span key={skill.id} className="px-3 py-1 bg-gray-100 text-gray-800 text-xs rounded-full">
                {skill.name}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

// Executive Template (Premium)
export const ExecutiveTemplate: React.FC<{ resumeData: ResumeData }> = ({ resumeData }) => {
  const { personalInfo, summary, experience, education, skills } = resumeData;
  
  // Format date display
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
  };

  return (
    <div className="p-8 bg-white text-primary">
      {/* Header Section - Different layout for executive */}
      <div className="border-b-2 border-secondary pb-4 mb-6">
        <h1 className="font-montserrat font-bold text-3xl text-center">{personalInfo.name}</h1>
        <p className="text-center text-secondary font-medium mt-1">{personalInfo.jobTitle}</p>
        
        {/* Contact row - centered and elegant */}
        <div className="flex justify-center space-x-4 mt-4 text-sm">
          <div className="flex items-center space-x-1">
            <i className="ri-mail-line text-secondary"></i>
            <span>{personalInfo.email}</span>
          </div>
          <div className="flex items-center space-x-1">
            <i className="ri-phone-line text-secondary"></i>
            <span>{personalInfo.phone}</span>
          </div>
          <div className="flex items-center space-x-1">
            <i className="ri-linkedin-box-line text-secondary"></i>
            <span>{personalInfo.linkedin}</span>
          </div>
        </div>
      </div>
      
      {/* Summary Section - More prominent for executive */}
      <div className="mb-6 bg-gray-50 p-4 border-l-4 border-secondary">
        <h2 className="font-montserrat font-semibold text-lg mb-2">
          Executive Summary
        </h2>
        <p className="text-sm text-gray-700 italic">
          {summary.content}
        </p>
      </div>
      
      {/* Work Experience - More structured for executive */}
      {experience.length > 0 && (
        <div className="mb-6">
          <h2 className="font-montserrat font-semibold text-lg text-secondary mb-4">
            Professional Experience
          </h2>
          
          {experience.map((job) => (
            <div key={job.id} className="mb-5">
              <div className="flex justify-between items-start border-b border-gray-200 pb-1 mb-2">
                <h3 className="font-bold text-base">{job.position}</h3>
                <span className="text-sm text-gray-600 font-medium">
                  {formatDate(job.startDate)} - {job.current ? 'Present' : formatDate(job.endDate)}
                </span>
              </div>
              <p className="text-sm font-medium mb-2">{job.company}, {job.location}</p>
              <ul className="text-sm text-gray-700 list-disc ml-5 space-y-1">
                {job.description.map((desc, i) => (
                  <li key={i}>{desc}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      )}
      
      {/* Education - Cleaner formatting for executive */}
      {education.length > 0 && (
        <div className="mb-6">
          <h2 className="font-montserrat font-semibold text-lg text-secondary mb-4">
            Education
          </h2>
          <div className="grid grid-cols-2 gap-4">
            {education.map((edu) => (
              <div key={edu.id} className="bg-gray-50 p-3 rounded">
                <h3 className="font-medium text-base">{edu.degree} in {edu.field}</h3>
                <p className="text-sm text-gray-600">{edu.institution}</p>
                <p className="text-sm text-gray-600">
                  {formatDate(edu.startDate)} - {formatDate(edu.endDate)}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Skills - Two column layout for executive */}
      {skills.length > 0 && (
        <div>
          <h2 className="font-montserrat font-semibold text-lg text-secondary mb-4">
            Core Competencies
          </h2>
          <div className="grid grid-cols-2 gap-2">
            {skills.map((skill) => (
              <div key={skill.id} className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-secondary rounded-full"></div>
                <span className="text-sm">{skill.name}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

// Creative Template (Premium)
export const CreativeTemplate: React.FC<{ resumeData: ResumeData }> = ({ resumeData }) => {
  const { personalInfo, summary, experience, education, skills } = resumeData;
  
  // Format date display
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
  };

  return (
    <div className="bg-white text-primary">
      {/* Creative header with sidebar */}
      <div className="grid grid-cols-3">
        {/* Sidebar */}
        <div className="bg-secondary text-white p-6">
          {personalInfo.photo && (
            <div className="w-32 h-32 bg-white rounded-full overflow-hidden mx-auto mb-6">
              <img 
                src={personalInfo.photo}
                alt={personalInfo.name} 
                className="w-full h-full object-cover"
              />
            </div>
          )}
          
          <h2 className="font-montserrat font-semibold text-lg mb-4 border-b border-white pb-2">
            Contact
          </h2>
          
          <div className="space-y-3 mb-6">
            <div className="flex items-center space-x-2">
              <i className="ri-mail-line"></i>
              <span className="text-sm">{personalInfo.email}</span>
            </div>
            <div className="flex items-center space-x-2">
              <i className="ri-phone-line"></i>
              <span className="text-sm">{personalInfo.phone}</span>
            </div>
            <div className="flex items-center space-x-2">
              <i className="ri-map-pin-line"></i>
              <span className="text-sm">{personalInfo.city}, {personalInfo.state}</span>
            </div>
            {personalInfo.linkedin && (
              <div className="flex items-center space-x-2">
                <i className="ri-linkedin-box-line"></i>
                <span className="text-sm">{personalInfo.linkedin}</span>
              </div>
            )}
          </div>
          
          {/* Skills in sidebar */}
          {skills.length > 0 && (
            <div>
              <h2 className="font-montserrat font-semibold text-lg mb-4 border-b border-white pb-2">
                Skills
              </h2>
              <div className="space-y-2">
                {skills.map((skill) => (
                  <div key={skill.id} className="text-sm">
                    <div className="flex justify-between mb-1">
                      <span>{skill.name}</span>
                    </div>
                    <div className="w-full bg-white bg-opacity-30 h-1.5 rounded-full">
                      <div className="bg-white h-1.5 rounded-full w-4/5"></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
        
        {/* Main Content */}
        <div className="col-span-2 p-6">
          <div className="mb-6">
            <h1 className="font-montserrat font-bold text-3xl">{personalInfo.name}</h1>
            <p className="text-secondary font-medium text-lg">{personalInfo.jobTitle}</p>
          </div>
          
          {/* Summary */}
          <div className="mb-6">
            <h2 className="font-montserrat font-semibold text-lg text-secondary mb-3">
              About Me
            </h2>
            <p className="text-sm">
              {summary.content}
            </p>
          </div>
          
          {/* Experience */}
          {experience.length > 0 && (
            <div className="mb-6">
              <h2 className="font-montserrat font-semibold text-lg text-secondary mb-3">
                Experience
              </h2>
              
              <div className="space-y-4">
                {experience.map((job) => (
                  <div key={job.id} className="relative pl-6 before:content-[''] before:absolute before:left-0 before:top-0 before:bottom-0 before:w-0.5 before:bg-secondary">
                    <div className="absolute w-2.5 h-2.5 bg-secondary rounded-full left-[-4px] top-1.5"></div>
                    <h3 className="font-bold text-base">{job.position}</h3>
                    <p className="text-sm text-secondary mb-1">{job.company}, {job.location}</p>
                    <p className="text-xs text-gray-600 mb-2">
                      {formatDate(job.startDate)} - {job.current ? 'Present' : formatDate(job.endDate)}
                    </p>
                    <ul className="text-sm text-gray-700 list-disc list-inside space-y-1">
                      {job.description.map((desc, i) => (
                        <li key={i}>{desc}</li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* Education */}
          {education.length > 0 && (
            <div>
              <h2 className="font-montserrat font-semibold text-lg text-secondary mb-3">
                Education
              </h2>
              
              <div className="space-y-4">
                {education.map((edu) => (
                  <div key={edu.id} className="relative pl-6 before:content-[''] before:absolute before:left-0 before:top-0 before:bottom-0 before:w-0.5 before:bg-secondary">
                    <div className="absolute w-2.5 h-2.5 bg-secondary rounded-full left-[-4px] top-1.5"></div>
                    <h3 className="font-bold text-base">{edu.degree} in {edu.field}</h3>
                    <p className="text-sm text-secondary mb-1">{edu.institution}, {edu.location}</p>
                    <p className="text-xs text-gray-600">
                      {formatDate(edu.startDate)} - {formatDate(edu.endDate)}
                    </p>
                    {edu.description && <p className="text-sm mt-1">{edu.description}</p>}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Minimalist Template (Premium)
export const MinimalistTemplate: React.FC<{ resumeData: ResumeData }> = ({ resumeData }) => {
  const { personalInfo, summary, experience, education, skills } = resumeData;
  
  // Format date display
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
  };
  
  return (
    <div className="p-8 bg-white text-gray-800 max-w-4xl mx-auto">
      {/* Header - Ultra minimal */}
      <div className="mb-8 border-b border-gray-200 pb-4">
        <h1 className="font-montserrat text-4xl font-light tracking-wide mb-1">{personalInfo.name}</h1>
        <p className="text-gray-500 text-lg">{personalInfo.jobTitle}</p>
        
        {/* Contact details - horizontal and minimal */}
        <div className="flex flex-wrap gap-x-6 gap-y-2 mt-4 text-sm text-gray-600">
          <span>{personalInfo.email}</span>
          <span>{personalInfo.phone}</span>
          <span>{personalInfo.city}, {personalInfo.state}</span>
          {personalInfo.linkedin && <span>{personalInfo.linkedin}</span>}
        </div>
      </div>

      {/* Summary */}
      <div className="mb-8">
        <p className="text-gray-700 leading-relaxed">
          {summary.content}
        </p>
      </div>
      
      {/* Skills - horizontal list */}
      {skills.length > 0 && (
        <div className="mb-8">
          <h2 className="font-montserrat text-lg font-light uppercase tracking-wider mb-3 text-gray-500">
            Skills
          </h2>
          <div className="flex flex-wrap gap-x-4 gap-y-2">
            {skills.map((skill) => (
              <span key={skill.id} className="text-gray-700">
                {skill.name}
              </span>
            ))}
          </div>
        </div>
      )}
      
      {/* Experience */}
      {experience.length > 0 && (
        <div className="mb-8">
          <h2 className="font-montserrat text-lg font-light uppercase tracking-wider mb-4 text-gray-500">
            Experience
          </h2>
          
          <div className="space-y-6">
            {experience.map((job) => (
              <div key={job.id} className="grid grid-cols-[1fr_3fr] gap-4">
                <div>
                  <p className="text-sm text-gray-500">
                    {formatDate(job.startDate)} - {job.current ? 'Present' : formatDate(job.endDate)}
                  </p>
                  <p className="text-sm mt-1">{job.location}</p>
                </div>
                <div>
                  <h3 className="font-medium text-gray-800">{job.position}</h3>
                  <p className="text-gray-600 mb-2">{job.company}</p>
                  <div className="text-sm text-gray-700 space-y-1">
                    {job.description.map((desc, i) => (
                      <p key={i}>{desc}</p>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Education */}
      {education.length > 0 && (
        <div>
          <h2 className="font-montserrat text-lg font-light uppercase tracking-wider mb-4 text-gray-500">
            Education
          </h2>
          
          <div className="space-y-6">
            {education.map((edu) => (
              <div key={edu.id} className="grid grid-cols-[1fr_3fr] gap-4">
                <div>
                  <p className="text-sm text-gray-500">
                    {formatDate(edu.startDate)} - {formatDate(edu.endDate)}
                  </p>
                  <p className="text-sm mt-1">{edu.location}</p>
                </div>
                <div>
                  <h3 className="font-medium text-gray-800">{edu.degree} in {edu.field}</h3>
                  <p className="text-gray-600">{edu.institution}</p>
                  {edu.description && <p className="text-sm mt-1 text-gray-700">{edu.description}</p>}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

// Modern Template (Free)
export const ModernTemplate: React.FC<{ resumeData: ResumeData }> = ({ resumeData }) => {
  const { personalInfo, summary, experience, education, skills } = resumeData;
  
  // Format date display
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
  };
  
  return (
    <div className="p-6 bg-white text-gray-800">
      {/* Modern Header */}
      <div className="flex flex-col items-center mb-8">
        <h1 className="font-montserrat text-3xl font-bold mb-1">{personalInfo.name}</h1>
        <p className="text-primary text-xl mb-4">{personalInfo.jobTitle}</p>
        
        {/* Contact info in a row */}
        <div className="flex flex-wrap justify-center gap-4 text-sm">
          <div className="flex items-center">
            <span className="bg-primary text-white p-1 rounded-full mr-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" />
                <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />
              </svg>
            </span>
            <span>{personalInfo.email}</span>
          </div>
          <div className="flex items-center">
            <span className="bg-primary text-white p-1 rounded-full mr-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z" />
              </svg>
            </span>
            <span>{personalInfo.phone}</span>
          </div>
          <div className="flex items-center">
            <span className="bg-primary text-white p-1 rounded-full mr-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
              </svg>
            </span>
            <span>{personalInfo.city}, {personalInfo.state}</span>
          </div>
        </div>
      </div>

      {/* Professional Summary */}
      <div className="mb-8">
        <h2 className="text-2xl font-semibold text-primary border-b-2 border-primary pb-2 mb-4">
          Professional Summary
        </h2>
        <p className="leading-relaxed">
          {summary.content}
        </p>
      </div>
      
      {/* Two column layout for main content */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left column - Skills and Education */}
        <div className="md:col-span-1">
          {/* Skills */}
          {skills.length > 0 && (
            <div className="mb-8">
              <h2 className="text-xl font-semibold text-primary border-b-2 border-primary pb-2 mb-4">
                Skills
              </h2>
              <ul className="space-y-2">
                {skills.map((skill) => (
                  <li key={skill.id} className="flex items-center">
                    <span className="w-2 h-2 bg-primary rounded-full mr-2"></span>
                    <span>{skill.name}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
          
          {/* Education */}
          {education.length > 0 && (
            <div>
              <h2 className="text-xl font-semibold text-primary border-b-2 border-primary pb-2 mb-4">
                Education
              </h2>
              <div className="space-y-4">
                {education.map((edu) => (
                  <div key={edu.id} className="border-l-2 border-primary pl-4">
                    <h3 className="font-medium">{edu.degree}</h3>
                    <p className="text-sm text-gray-600">{edu.field}</p>
                    <p className="text-sm">{edu.institution}</p>
                    <p className="text-xs text-gray-500">
                      {formatDate(edu.startDate)} - {formatDate(edu.endDate)}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
        
        {/* Right column - Experience */}
        <div className="md:col-span-2">
          {experience.length > 0 && (
            <div>
              <h2 className="text-xl font-semibold text-primary border-b-2 border-primary pb-2 mb-4">
                Work Experience
              </h2>
              <div className="space-y-6">
                {experience.map((job) => (
                  <div key={job.id} className="border-l-2 border-primary pl-4">
                    <div className="flex flex-wrap justify-between items-start mb-2">
                      <h3 className="font-bold">{job.position}</h3>
                      <span className="bg-gray-100 text-gray-700 text-xs px-2 py-1 rounded-full">
                        {formatDate(job.startDate)} - {job.current ? 'Present' : formatDate(job.endDate)}
                      </span>
                    </div>
                    <p className="text-sm text-primary font-medium mb-2">{job.company}, {job.location}</p>
                    <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                      {job.description.map((desc, i) => (
                        <li key={i}>{desc}</li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Templates catalog
export const templates: Template[] = [
  {
    id: 'essential',
    name: 'Essential',
    description: 'A clean, professional template perfect for most industries',
    isPremium: false,
    thumbnail: <EssentialTemplateThumbnail />,
    render: (resumeData) => <EssentialTemplate resumeData={resumeData} />
  },
  {
    id: 'executive',
    name: 'Executive',
    description: 'An elegant template for senior positions and leadership roles',
    isPremium: true,
    thumbnail: <ExecutiveTemplateThumbnail />,
    render: (resumeData) => <ExecutiveTemplate resumeData={resumeData} />
  },
  {
    id: 'creative',
    name: 'Creative',
    description: 'A modern design for creative professionals and designers',
    isPremium: true,
    thumbnail: <CreativeTemplateThumbnail />,
    render: (resumeData) => <CreativeTemplate resumeData={resumeData} />
  },
  {
    id: 'minimalist',
    name: 'Minimalist',
    description: 'A clean, minimalist design focusing on content with elegant typography',
    isPremium: true,
    thumbnail: <MinimalistTemplateThumbnail />,
    render: (resumeData) => <MinimalistTemplate resumeData={resumeData} />
  },
  {
    id: 'modern',
    name: 'Modern',
    description: 'A contemporary layout with a focus on readability and visual appeal',
    isPremium: false,
    thumbnail: <ModernTemplateThumbnail />,
    render: (resumeData) => <ModernTemplate resumeData={resumeData} />
  },
  {
    id: 'visual-impact',
    name: 'Visual Impact',
    description: 'A visually striking modern template with a gradient header and timeline elements',
    isPremium: true,
    thumbnail: <VisualImpactTemplateThumbnail />,
    render: (resumeData) => <VisualImpactTemplate resumeData={resumeData} />
  },
  {
    id: 'infographic',
    name: 'Infographic',
    description: 'A data-driven template with visual elements highlighting your experience and skills',
    isPremium: true,
    thumbnail: <InfographicTemplateThumbnail />,
    render: (resumeData) => <InfographicTemplate resumeData={resumeData} />
  },
  {
    id: 'executive-plus',
    name: 'Executive Plus',
    description: 'A sophisticated premium template for senior professionals with elegant design elements',
    isPremium: true,
    thumbnail: <ExecutivePlusTemplateThumbnail />,
    render: (resumeData) => <ExecutivePlusTemplate resumeData={resumeData} />
  }
];

// Visual Impact Template (Premium)
export const VisualImpactTemplate: React.FC<{ resumeData: ResumeData }> = ({ resumeData }) => {
  const { personalInfo, summary, experience, education, skills } = resumeData;
  
  // Format date display
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
  };
  
  return (
    <div className="bg-white text-gray-800">
      {/* Bold colored header section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-montserrat font-bold text-3xl">{personalInfo.name}</h1>
            <p className="text-xl mt-1 text-blue-100">{personalInfo.jobTitle}</p>
            
            <div className="grid grid-cols-2 gap-4 mt-4 text-sm text-blue-100">
              <div className="flex items-center space-x-2">
                <i className="ri-mail-line text-white"></i>
                <span>{personalInfo.email}</span>
              </div>
              <div className="flex items-center space-x-2">
                <i className="ri-phone-line text-white"></i>
                <span>{personalInfo.phone}</span>
              </div>
              <div className="flex items-center space-x-2">
                <i className="ri-map-pin-line text-white"></i>
                <span>{personalInfo.city}, {personalInfo.state}</span>
              </div>
              {personalInfo.linkedin && (
                <div className="flex items-center space-x-2">
                  <i className="ri-linkedin-box-line text-white"></i>
                  <span>{personalInfo.linkedin}</span>
                </div>
              )}
            </div>
          </div>
          
          {personalInfo.photo && (
            <div className="w-32 h-32 bg-white p-1 rounded-full overflow-hidden shadow-lg">
              <img 
                src={personalInfo.photo}
                alt={personalInfo.name} 
                className="w-full h-full object-cover rounded-full"
              />
            </div>
          )}
        </div>
      </div>
      
      <div className="p-8">
        {/* Profile summary in a highlighted box */}
        <div className="bg-gray-50 p-6 rounded-lg mb-8 border-l-4 border-blue-600 shadow-sm">
          <h2 className="font-montserrat font-semibold text-xl text-blue-600 mb-3">
            Professional Profile
          </h2>
          <p className="text-gray-700">
            {summary.content}
          </p>
        </div>
        
        <div className="grid grid-cols-12 gap-8">
          {/* Main column for experience and education */}
          <div className="col-span-8">
            {/* Experience section with timeline design */}
            {experience.length > 0 && (
              <div className="mb-8">
                <h2 className="font-montserrat font-semibold text-xl text-gray-800 mb-4 pb-2 border-b border-gray-200">
                  <span className="text-blue-600">Professional</span> Experience
                </h2>
                
                <div className="space-y-6">
                  {experience.map((job) => (
                    <div key={job.id} className="relative pl-8 before:content-[''] before:absolute before:left-0 before:top-2 before:bottom-0 before:w-0.5 before:bg-gray-200">
                      <div className="absolute w-4 h-4 bg-blue-600 rounded-full left-[-8px] top-1"></div>
                      <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                        <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-2">
                          <h3 className="font-bold text-lg text-blue-600">{job.position}</h3>
                          <span className="inline-block text-sm bg-blue-50 text-blue-800 px-3 py-1 rounded-full">
                            {formatDate(job.startDate)} - {job.current ? 'Present' : formatDate(job.endDate)}
                          </span>
                        </div>
                        <p className="text-sm font-medium text-gray-600 mb-3">{job.company}, {job.location}</p>
                        <ul className="text-sm text-gray-700 space-y-2">
                          {job.description.map((desc, i) => (
                            <li key={i} className="flex items-start">
                              <span className="inline-block w-1.5 h-1.5 bg-blue-500 rounded-full mt-1.5 mr-2 flex-shrink-0"></span>
                              <span>{desc}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {/* Education with card design */}
            {education.length > 0 && (
              <div>
                <h2 className="font-montserrat font-semibold text-xl text-gray-800 mb-4 pb-2 border-b border-gray-200">
                  <span className="text-blue-600">Academic</span> Background
                </h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {education.map((edu) => (
                    <div key={edu.id} className="bg-white rounded-lg p-4 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                      <h3 className="font-bold text-blue-600 mb-1">{edu.degree}</h3>
                      <p className="text-sm font-medium">{edu.field}</p>
                      <p className="text-sm text-gray-600 mb-1">{edu.institution}, {edu.location}</p>
                      <p className="text-xs text-gray-500 mb-2">
                        {formatDate(edu.startDate)} - {formatDate(edu.endDate)}
                      </p>
                      {edu.description && <p className="text-sm border-t border-gray-100 pt-2 mt-2">{edu.description}</p>}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
          
          {/* Side column with skills */}
          <div className="col-span-4">
            {skills.length > 0 && (
              <div className="bg-gray-50 rounded-lg p-6 shadow-sm">
                <h2 className="font-montserrat font-semibold text-xl text-gray-800 mb-4 pb-2 border-b border-gray-200">
                  <span className="text-blue-600">Key</span> Skills
                </h2>
                
                <div className="space-y-4">
                  {skills.map((skill) => (
                    <div key={skill.id} className="group">
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium group-hover:text-blue-600 transition-colors">{skill.name}</span>
                      </div>
                      <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
                        <div 
                          className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full" 
                          style={{ width: '90%' }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
                
                {/* Extra career highlights section */}
                <div className="mt-8 pt-6 border-t border-gray-200">
                  <h3 className="font-medium text-lg text-blue-600 mb-3">Career Highlights</h3>
                  <ul className="space-y-2">
                    {experience.slice(0, 2).flatMap(job => 
                      job.description.slice(0, 1).map((highlight, idx) => (
                        <li key={idx} className="flex items-start">
                          <span className="inline-block w-1.5 h-1.5 bg-purple-500 rounded-full mt-1.5 mr-2 flex-shrink-0"></span>
                          <span className="text-sm">{highlight}</span>
                        </li>
                      ))
                    )}
                  </ul>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// Infographic Template (Premium)
export const InfographicTemplate: React.FC<{ resumeData: ResumeData }> = ({ resumeData }) => {
  const { personalInfo, summary, experience, education, skills } = resumeData;
  
  // Format date display
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
  };
  
  // Calculate years of experience
  const calculateExperienceYears = () => {
    let totalYears = 0;
    
    experience.forEach(job => {
      const startDate = new Date(job.startDate);
      const endDate = job.current ? new Date() : new Date(job.endDate);
      
      const diffTime = Math.abs(endDate.getTime() - startDate.getTime());
      const diffYears = diffTime / (1000 * 60 * 60 * 24 * 365.25);
      
      totalYears += diffYears;
    });
    
    return Math.round(totalYears);
  };
  
  return (
    <div className="bg-white">
      {/* Header with personal stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 bg-gradient-to-br from-teal-500 to-emerald-700 text-white">
        {/* Left column with photo and personal info */}
        <div className="md:col-span-1 p-8 flex flex-col items-center justify-center">
          {personalInfo.photo ? (
            <div className="w-40 h-40 rounded-full border-4 border-white overflow-hidden mb-4">
              <img 
                src={personalInfo.photo}
                alt={personalInfo.name} 
                className="w-full h-full object-cover"
              />
            </div>
          ) : (
            <div className="w-40 h-40 rounded-full border-4 border-white bg-teal-400 flex items-center justify-center mb-4">
              <span className="text-5xl font-bold">{personalInfo.name.charAt(0)}</span>
            </div>
          )}
          
          <h1 className="font-montserrat font-bold text-2xl text-center">{personalInfo.name}</h1>
          <p className="text-teal-100 text-lg mb-4">{personalInfo.jobTitle}</p>
          
          <div className="flex flex-wrap justify-center gap-2 text-sm">
            <a href={`mailto:${personalInfo.email}`} className="px-3 py-1 bg-white bg-opacity-20 rounded-full flex items-center hover:bg-opacity-30">
              <i className="ri-mail-line mr-1"></i> Email
            </a>
            <a href={`tel:${personalInfo.phone}`} className="px-3 py-1 bg-white bg-opacity-20 rounded-full flex items-center hover:bg-opacity-30">
              <i className="ri-phone-line mr-1"></i> Call
            </a>
            {personalInfo.linkedin && (
              <a href={personalInfo.linkedin} className="px-3 py-1 bg-white bg-opacity-20 rounded-full flex items-center hover:bg-opacity-30">
                <i className="ri-linkedin-box-line mr-1"></i> LinkedIn
              </a>
            )}
          </div>
        </div>
        
        {/* Right columns with experience stats */}
        <div className="md:col-span-2 grid grid-cols-2 gap-4 p-8">
          <div className="text-center p-4 bg-white bg-opacity-10 rounded-lg backdrop-blur-sm">
            <div className="text-4xl font-bold mb-1">{calculateExperienceYears()}</div>
            <div className="text-teal-100">Years of Experience</div>
          </div>
          
          <div className="text-center p-4 bg-white bg-opacity-10 rounded-lg backdrop-blur-sm">
            <div className="text-4xl font-bold mb-1">{experience.length}</div>
            <div className="text-teal-100">Positions Held</div>
          </div>
          
          <div className="text-center p-4 bg-white bg-opacity-10 rounded-lg backdrop-blur-sm">
            <div className="text-4xl font-bold mb-1">{education.length}</div>
            <div className="text-teal-100">Degrees</div>
          </div>
          
          <div className="text-center p-4 bg-white bg-opacity-10 rounded-lg backdrop-blur-sm">
            <div className="text-4xl font-bold mb-1">{skills.length}</div>
            <div className="text-teal-100">Core Skills</div>
          </div>
          
          {/* Summary quote */}
          <div className="col-span-2 p-4 bg-white bg-opacity-10 rounded-lg backdrop-blur-sm">
            <p className="text-sm italic">"{summary.content.length > 160 ? summary.content.substring(0, 160) + '...' : summary.content}"</p>
          </div>
        </div>
      </div>
      
      <div className="p-8">
        {/* About me section */}
        <div className="mb-10">
          <h2 className="font-montserrat font-bold text-xl text-teal-700 mb-4 pb-2 border-b-2 border-teal-100">
            About Me
          </h2>
          <p className="text-gray-700">
            {summary.content}
          </p>
        </div>
        
        {/* Skills with visual chart */}
        {skills.length > 0 && (
          <div className="mb-10">
            <h2 className="font-montserrat font-bold text-xl text-teal-700 mb-4 pb-2 border-b-2 border-teal-100">
              Skills & Expertise
            </h2>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {skills.map((skill, index) => (
                <div key={skill.id} className="text-center">
                  <div className="inline-block w-20 h-20 relative mb-2">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-16 h-16 rounded-full bg-teal-50 flex items-center justify-center">
                        <span className="font-bold text-teal-700">{skill.name.split(' ')[0]}</span>
                      </div>
                    </div>
                    <svg viewBox="0 0 36 36" className="w-20 h-20 transform -rotate-90">
                      <path
                        d="M18 2.0845
                          a 15.9155 15.9155 0 0 1 0 31.831
                          a 15.9155 15.9155 0 0 1 0 -31.831"
                        fill="none"
                        stroke="#e2e8f0"
                        strokeWidth="3"
                        strokeDasharray="100, 100"
                      />
                      <path
                        d="M18 2.0845
                          a 15.9155 15.9155 0 0 1 0 31.831
                          a 15.9155 15.9155 0 0 1 0 -31.831"
                        fill="none"
                        stroke={`hsl(${(index * 20) % 360}, 70%, 50%)`}
                        strokeWidth="3"
                        strokeDasharray={`${75 + (index % 3) * 8}, 100`}
                      />
                    </svg>
                  </div>
                  <p className="text-sm text-gray-600">{skill.name}</p>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {/* Experience with timeline */}
        {experience.length > 0 && (
          <div className="mb-10">
            <h2 className="font-montserrat font-bold text-xl text-teal-700 mb-4 pb-2 border-b-2 border-teal-100">
              Experience Timeline
            </h2>
            
            <div className="space-y-8">
              {experience.map((job, index) => (
                <div key={job.id} className="relative pl-8 pb-8 border-l-2 border-teal-200 last:border-0">
                  <div className="absolute w-4 h-4 bg-teal-500 rounded-full left-[-9px] top-0"></div>
                  <div className="absolute text-xs text-gray-500 left-[-70px] top-0">{formatDate(job.startDate)}</div>
                  
                  <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
                    <h3 className="font-bold text-teal-700">{job.position}</h3>
                    <p className="text-sm font-medium text-gray-600">{job.company}, {job.location}</p>
                    <p className="text-xs text-gray-500 mb-3">{formatDate(job.startDate)} - {job.current ? 'Present' : formatDate(job.endDate)}</p>
                    
                    <div className="mt-3 space-y-2">
                      {job.description.map((desc, i) => (
                        <div key={i} className="flex items-start">
                          <div className="flex-shrink-0 w-5 h-5 bg-teal-100 rounded-full flex items-center justify-center mr-2 mt-0.5">
                            <span className="w-2 h-2 bg-teal-500 rounded-full"></span>
                          </div>
                          <p className="text-sm text-gray-700">{desc}</p>
                        </div>
                      ))}
                    </div>
                    
                    {/* Key achievement highlight */}
                    {job.description[0] && (
                      <div className="mt-4 pt-3 border-t border-gray-100">
                        <div className="text-xs font-medium text-teal-700 mb-1">KEY ACHIEVEMENT</div>
                        <p className="text-sm italic">{job.description[0]}</p>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {/* Education in cards */}
        {education.length > 0 && (
          <div>
            <h2 className="font-montserrat font-bold text-xl text-teal-700 mb-4 pb-2 border-b-2 border-teal-100">
              Education
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {education.map((edu) => (
                <div key={edu.id} className="bg-white rounded-lg p-5 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="inline-block px-2 py-1 bg-teal-100 text-teal-800 text-xs rounded mb-2">
                        {formatDate(edu.startDate)} - {formatDate(edu.endDate)}
                      </div>
                      <h3 className="font-bold text-gray-800">{edu.degree}</h3>
                      <p className="text-teal-600 font-medium">{edu.field}</p>
                      <p className="text-sm text-gray-600">{edu.institution}, {edu.location}</p>
                    </div>
                    <div className="w-12 h-12 bg-teal-100 rounded-full flex items-center justify-center">
                      <i className="ri-graduation-cap-line text-teal-700 text-xl"></i>
                    </div>
                  </div>
                  {edu.description && (
                    <div className="mt-3 pt-3 border-t border-gray-100">
                      <p className="text-sm text-gray-700">{edu.description}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// Executive Plus Template (Premium)
export const ExecutivePlusTemplate: React.FC<{ resumeData: ResumeData }> = ({ resumeData }) => {
  const { personalInfo, summary, experience, education, skills } = resumeData;
  
  // Format date display
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
  };
  
  return (
    <div className="bg-white text-gray-800">
      {/* Elegant header with gold accents */}
      <div className="p-10 bg-gray-50 border-b-4 border-amber-400">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
            <div className="md:col-span-2">
              <h1 className="font-serif font-bold text-4xl text-gray-800 tracking-tight">{personalInfo.name}</h1>
              <p className="text-amber-700 text-xl mt-1 tracking-wide">{personalInfo.jobTitle}</p>
              
              <div className="text-sm text-gray-600 mt-4 space-y-1">
                <div className="flex items-center">
                  <i className="ri-map-pin-line text-amber-500 mr-2"></i>
                  <span>{personalInfo.city}, {personalInfo.state}</span>
                </div>
                <div className="flex items-center">
                  <i className="ri-mail-line text-amber-500 mr-2"></i>
                  <span>{personalInfo.email}</span>
                </div>
                <div className="flex items-center">
                  <i className="ri-phone-line text-amber-500 mr-2"></i>
                  <span>{personalInfo.phone}</span>
                </div>
                {personalInfo.linkedin && (
                  <div className="flex items-center">
                    <i className="ri-linkedin-box-line text-amber-500 mr-2"></i>
                    <span>{personalInfo.linkedin}</span>
                  </div>
                )}
              </div>
            </div>
            
            {personalInfo.photo && (
              <div className="flex justify-center md:justify-end">
                <div className="w-32 h-32 rounded-full overflow-hidden ring-4 ring-amber-400 shadow-lg">
                  <img 
                    src={personalInfo.photo}
                    alt={personalInfo.name} 
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      
      <div className="max-w-4xl mx-auto p-10">
        {/* Professional summary with quotation design */}
        <div className="mb-10 relative">
          <div className="text-8xl text-amber-200 absolute top-0 left-0 leading-none font-serif">"</div>
          <div className="relative z-10 pl-8 pt-6">
            <h2 className="font-serif font-bold text-2xl text-gray-800 mb-4">Executive Summary</h2>
            <p className="text-gray-700 leading-relaxed">
              {summary.content}
            </p>
            <div className="text-8xl text-amber-200 absolute bottom-0 right-0 leading-none font-serif rotate-180">"</div>
          </div>
        </div>
        
        {/* Core competencies in an elegant display */}
        {skills.length > 0 && (
          <div className="mb-10">
            <h2 className="font-serif font-bold text-2xl text-gray-800 mb-6 pb-2 border-b border-amber-200">
              Core Competencies
            </h2>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {skills.map((skill) => (
                <div key={skill.id} className="flex items-center p-3 border border-gray-100 rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="w-3 h-3 rounded-sm bg-amber-400 mr-3 transform rotate-45"></div>
                  <span className="text-gray-700">{skill.name}</span>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {/* Professional experience with elegant timeline */}
        {experience.length > 0 && (
          <div className="mb-10">
            <h2 className="font-serif font-bold text-2xl text-gray-800 mb-6 pb-2 border-b border-amber-200">
              Professional Experience
            </h2>
            
            <div className="space-y-10">
              {experience.map((job) => (
                <div key={job.id} className="relative">
                  {/* Company & title header in a box */}
                  <div className="flex justify-between items-center bg-gray-50 p-4 border-l-4 border-amber-400 shadow-sm mb-4">
                    <div>
                      <h3 className="font-semibold text-xl text-gray-800">{job.position}</h3>
                      <p className="text-amber-700">{job.company}, {job.location}</p>
                    </div>
                    <div className="text-right">
                      <div className="inline-block px-3 py-1 border border-amber-200 text-amber-800 text-sm rounded bg-amber-50">
                        {formatDate(job.startDate)} - {job.current ? 'Present' : formatDate(job.endDate)}
                      </div>
                    </div>
                  </div>
                  
                  {/* Key responsibilities and achievements */}
                  <div className="pl-6 border-l border-gray-200">
                    <h4 className="font-medium text-amber-700 mb-3">Key Responsibilities & Achievements:</h4>
                    <ul className="space-y-3">
                      {job.description.map((desc, i) => (
                        <li key={i} className="flex items-start text-gray-700">
                          <span className="inline-block w-2 h-2 bg-amber-500 rounded-full mt-1.5 mr-3 flex-shrink-0"></span>
                          <span>{desc}</span>
                        </li>
                      ))}
                    </ul>
                    
                    {/* Strategic impact section */}
                    {job.description[0] && (
                      <div className="mt-6 pt-4 border-t border-gray-100">
                        <h4 className="font-medium text-amber-700 mb-2">Strategic Impact:</h4>
                        <div className="bg-amber-50 p-3 border-l-2 border-amber-400 text-gray-700 italic">
                          Led initiatives resulting in {job.description[0].toLowerCase()}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {/* Education with elegant cards */}
        {education.length > 0 && (
          <div>
            <h2 className="font-serif font-bold text-2xl text-gray-800 mb-6 pb-2 border-b border-amber-200">
              Education & Credentials
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {education.map((edu) => (
                <div key={edu.id} className="bg-gray-50 rounded-lg p-5 border border-gray-100 hover:shadow-md transition-shadow relative overflow-hidden">
                  {/* Visual design element */}
                  <div className="absolute top-0 right-0 w-16 h-16 bg-amber-400 transform rotate-45 translate-x-8 -translate-y-8"></div>
                  
                  <h3 className="font-serif font-bold text-gray-800 text-lg">{edu.degree}</h3>
                  <p className="text-amber-700 font-medium">{edu.field}</p>
                  <p className="text-gray-600 mb-2">{edu.institution}, {edu.location}</p>
                  <p className="text-sm text-gray-500 mb-3">
                    {formatDate(edu.startDate)} - {formatDate(edu.endDate)}
                  </p>
                  {edu.description && <p className="text-gray-600 text-sm">{edu.description}</p>}
                </div>
              ))}
            </div>
            
            {/* Added executive endorsement section */}
            <div className="mt-10 pt-6 border-t border-amber-200">
              <div className="bg-gray-50 p-6 rounded-lg relative">
                <div className="text-6xl text-amber-200 absolute top-2 left-3 leading-none font-serif">"</div>
                <p className="italic text-gray-700 relative z-10 pl-8">
                  {personalInfo.name} demonstrates exceptional leadership abilities and strategic insight. 
                  A results-driven executive with a proven track record of success.
                </p>
                <div className="mt-4 flex items-center justify-end">
                  <div className="h-px bg-amber-200 w-16 mr-3"></div>
                  <span className="text-amber-700 font-medium">Executive Endorsement</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// Function to get template by ID
export const getTemplateById = (id: string): Template => {
  const template = templates.find(t => t.id === id);
  if (!template) {
    return templates[0]; // Return the essential template if not found
  }
  return template;
};