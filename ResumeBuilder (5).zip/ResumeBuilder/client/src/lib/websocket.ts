// WebSocket client utility for real-time collaboration
import { useEffect, useState, useRef, useCallback } from 'react';
import { useAuth } from '@/hooks/use-auth';

// Type definitions for WebSocket messages
export type ResumeUpdateMessage = {
  type: 'resume_update';
  resumeId: number;
  data: any;
  userId: number;
  username: string;
};

export type CursorUpdateMessage = {
  type: 'cursor_update';
  resumeId: number;
  userId: number;
  username: string;
  position: { section: string; field: string };
};

export type PresenceMessage = {
  type: 'presence';
  action: 'join' | 'leave';
  resumeId: number;
  userId: number;
  username: string;
  role: string;
};

export type CommentMessage = {
  type: 'comment';
  action: 'add' | 'resolve' | 'delete';
  resumeId: number;
  commentId?: number;
  comment?: any;
  userId: number;
  username: string;
};

export type WebSocketMessage = 
  | ResumeUpdateMessage 
  | CursorUpdateMessage 
  | PresenceMessage 
  | CommentMessage;

export type ActiveCollaborator = {
  userId: number;
  username: string;
  role: string;
  position?: { section: string; field: string };
};

// Hook for managing WebSocket connections for collaborative editing
export function useCollabWebSocket(resumeId: number | null) {
  const { user } = useAuth();
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [connected, setConnected] = useState(false);
  const [activeCollaborators, setActiveCollaborators] = useState<ActiveCollaborator[]>([]);
  const [connectionError, setConnectionError] = useState<string | null>(null);
  const reconnectTimeoutRef = useRef<number | null>(null);
  const reconnectAttemptsRef = useRef(0);
  const MAX_RECONNECT_ATTEMPTS = 5;
  
  // Function to send a message through the WebSocket
  const sendMessage = useCallback((message: WebSocketMessage) => {
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify(message));
      return true;
    }
    return false;
  }, [socket]);
  
  // Update resume data through WebSocket
  const updateResume = useCallback((data: any) => {
    if (!resumeId || !user) return false;
    
    return sendMessage({
      type: 'resume_update',
      resumeId,
      data,
      userId: user.id,
      username: user.username
    });
  }, [resumeId, user, sendMessage]);
  
  // Update cursor position through WebSocket
  const updateCursor = useCallback((position: { section: string; field: string }) => {
    if (!resumeId || !user) return false;
    
    return sendMessage({
      type: 'cursor_update',
      resumeId,
      userId: user.id,
      username: user.username,
      position
    });
  }, [resumeId, user, sendMessage]);
  
  // Connect to WebSocket server
  useEffect(() => {
    if (!resumeId || !user) return;
    
    // Clean up previous connection and timeout
    if (socket) {
      socket.close();
    }
    
    if (reconnectTimeoutRef.current) {
      window.clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }
    
    // Reset state when resumeId or user changes
    setConnected(false);
    setConnectionError(null);
    setActiveCollaborators([]);
    reconnectAttemptsRef.current = 0;
    
    // Create new WebSocket connection
    const connectWebSocket = () => {
      try {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${protocol}//${window.location.host}/ws`;
        
        console.log('Connecting to WebSocket:', wsUrl);
        const newSocket = new WebSocket(wsUrl);
        
        newSocket.onopen = () => {
          console.log('WebSocket connected');
          setConnected(true);
          setConnectionError(null);
          reconnectAttemptsRef.current = 0;
          
          // Send initial presence message
          if (user && resumeId) {
            newSocket.send(JSON.stringify({
              type: 'presence',
              action: 'join',
              resumeId,
              userId: user.id,
              username: user.username,
              role: 'editor' // Default role, will be updated from server
            }));
          }
        };
        
        newSocket.onmessage = (event) => {
          try {
            const message = JSON.parse(event.data) as WebSocketMessage;
            
            if (message.type === 'presence') {
              if (message.action === 'join') {
                setActiveCollaborators(prev => {
                  // Only add if not already in the list
                  const exists = prev.some(c => c.userId === message.userId);
                  if (exists) return prev;
                  
                  return [...prev, {
                    userId: message.userId,
                    username: message.username,
                    role: message.role
                  }];
                });
              } else if (message.action === 'leave') {
                setActiveCollaborators(prev => 
                  prev.filter(c => c.userId !== message.userId)
                );
              }
            } else if (message.type === 'cursor_update') {
              setActiveCollaborators(prev => {
                return prev.map(c => {
                  if (c.userId === message.userId) {
                    return { ...c, position: message.position };
                  }
                  return c;
                });
              });
            }
            
            // Additional message handling would go here
            // (resume_update, comment, etc.)
          } catch (err) {
            console.error('Error parsing WebSocket message:', err);
          }
        };
        
        newSocket.onclose = (event) => {
          console.log('WebSocket disconnected:', event.code, event.reason);
          setConnected(false);
          
          // Attempt to reconnect if not a normal closure and within max attempts
          if (event.code !== 1000 && event.code !== 1001 && 
              reconnectAttemptsRef.current < MAX_RECONNECT_ATTEMPTS) {
            
            const timeout = Math.min(1000 * 2 ** reconnectAttemptsRef.current, 30000);
            console.log(`Reconnecting in ${timeout}ms (attempt ${reconnectAttemptsRef.current + 1}/${MAX_RECONNECT_ATTEMPTS})`);
            
            reconnectTimeoutRef.current = window.setTimeout(() => {
              reconnectAttemptsRef.current += 1;
              connectWebSocket();
            }, timeout);
          } else if (reconnectAttemptsRef.current >= MAX_RECONNECT_ATTEMPTS) {
            setConnectionError('Maximum reconnection attempts reached. Please refresh the page.');
          }
        };
        
        newSocket.onerror = (error) => {
          console.error('WebSocket error:', error);
          setConnectionError('Connection error. Please check your network connection.');
        };
        
        setSocket(newSocket);
      } catch (err) {
        console.error('Failed to create WebSocket:', err);
        setConnectionError('Failed to establish connection. Please refresh the page.');
      }
    };
    
    connectWebSocket();
    
    // Clean up on unmount
    return () => {
      if (socket) {
        // Send leave message if connected
        if (socket.readyState === WebSocket.OPEN && user && resumeId) {
          socket.send(JSON.stringify({
            type: 'presence',
            action: 'leave',
            resumeId,
            userId: user.id,
            username: user.username,
            role: ''
          }));
        }
        
        socket.close();
      }
      
      if (reconnectTimeoutRef.current) {
        window.clearTimeout(reconnectTimeoutRef.current);
      }
    };
  }, [resumeId, user]);
  
  return {
    connected,
    connectionError,
    activeCollaborators,
    updateResume,
    updateCursor,
    sendMessage
  };
}