import { useState } from "react";
import { Helmet } from "react-helmet-async";
import { ArrowRight, Calendar, Clock, Search, Tag, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";

// Blog post type definition
interface BlogPost {
  id: number;
  title: string;
  slug: string;
  excerpt: string;
  category: string;
  tags: string[];
  author: string;
  date: string;
  readTime: string;
  imageUrl: string;
}

// Sample blog data
const blogPosts: BlogPost[] = [
  {
    id: 1,
    title: "10 Resume Mistakes That Could Cost You the Job",
    slug: "resume-mistakes",
    excerpt: "Discover the common resume mistakes that recruiters flag as immediate disqualifiers and learn how to avoid them to improve your chances of landing an interview.",
    category: "Resume Tips",
    tags: ["resume", "mistakes", "job search"],
    author: "Emma Johnson",
    date: "May 2, 2025",
    readTime: "6 min read",
    imageUrl: "https://images.unsplash.com/photo-1586281380349-632531db7ed4?q=80&w=500&auto=format&fit=crop"
  },
  {
    id: 2,
    title: "How to Optimize Your LinkedIn Profile to Complement Your Resume",
    slug: "linkedin-optimization",
    excerpt: "Learn how to create a consistent personal brand across your resume and LinkedIn profile, and discover strategies to leverage LinkedIn for networking and job opportunities.",
    category: "LinkedIn",
    tags: ["linkedin", "personal branding", "networking"],
    author: "Michael Chen",
    date: "April 28, 2025",
    readTime: "8 min read",
    imageUrl: "https://images.unsplash.com/photo-1611944212129-29977ae1398c?q=80&w=500&auto=format&fit=crop"
  },
  {
    id: 3,
    title: "The Art of Crafting a Compelling Cover Letter",
    slug: "compelling-cover-letter",
    excerpt: "Master the elements of an effective cover letter that complements your resume and resonates with hiring managers across different industries.",
    category: "Cover Letters",
    tags: ["cover letter", "job application", "writing"],
    author: "Sarah Williams",
    date: "April 22, 2025",
    readTime: "5 min read",
    imageUrl: "https://images.unsplash.com/photo-1586282391129-76a6df230234?q=80&w=500&auto=format&fit=crop"
  },
  {
    id: 4,
    title: "How to Prepare for Behavioral Interview Questions",
    slug: "behavioral-interview-prep",
    excerpt: "Prepare for your next interview with strategies for answering behavioral questions using the STAR method and practical examples for common scenarios.",
    category: "Interviews",
    tags: ["interview", "preparation", "STAR method"],
    author: "David Rodriguez",
    date: "April 15, 2025",
    readTime: "7 min read",
    imageUrl: "https://images.unsplash.com/photo-1507537297725-24a1c029d3ca?q=80&w=500&auto=format&fit=crop"
  },
  {
    id: 5,
    title: "Industry-Specific Resume Guides: Tech Edition",
    slug: "tech-resume-guide",
    excerpt: "Tailor your resume for the tech industry with insights on highlighting technical skills, showcasing projects, and formatting for both human recruiters and ATS systems.",
    category: "Industry Guides",
    tags: ["tech", "IT", "software development"],
    author: "Priya Patel",
    date: "April 10, 2025",
    readTime: "9 min read",
    imageUrl: "https://images.unsplash.com/photo-1504639725590-34d0984388bd?q=80&w=500&auto=format&fit=crop"
  },
  {
    id: 6,
    title: "Resume Keywords: How to Pass the ATS Screening",
    slug: "ats-resume-keywords",
    excerpt: "Learn how to strategically incorporate industry-specific keywords in your resume to ensure it passes through Applicant Tracking Systems and reaches human recruiters.",
    category: "ATS Optimization",
    tags: ["ATS", "keywords", "screening"],
    author: "James Wilson",
    date: "April 5, 2025",
    readTime: "6 min read",
    imageUrl: "https://images.unsplash.com/photo-1512486130939-2c4f79935e4f?q=80&w=500&auto=format&fit=crop"
  }
];

// All available categories and tags for filtering
const categoriesSet = new Set(blogPosts.map(post => post.category));
const allCategories = Array.from(categoriesSet);

const tagsSet = new Set(blogPosts.flatMap(post => post.tags));
const allTags = Array.from(tagsSet);

export default function Blog() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);

  // Filter posts based on search, category, and tags
  const filteredPosts = blogPosts.filter(post => {
    // Check search term
    const matchesSearch = 
      searchTerm === "" || 
      post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Check category
    const matchesCategory = 
      selectedCategory === null || 
      post.category === selectedCategory;
    
    // Check tags
    const matchesTags = 
      selectedTags.length === 0 || 
      selectedTags.some(tag => post.tags.includes(tag));
    
    return matchesSearch && matchesCategory && matchesTags;
  });

  // Toggle tag selection
  const toggleTag = (tag: string) => {
    if (selectedTags.includes(tag)) {
      setSelectedTags(selectedTags.filter(t => t !== tag));
    } else {
      setSelectedTags([...selectedTags, tag]);
    }
  };

  // Clear all filters
  const clearFilters = () => {
    setSearchTerm("");
    setSelectedCategory(null);
    setSelectedTags([]);
  };

  return (
    <>
      <Helmet>
        <title>Career Insights Blog | ResumeX</title>
        <meta name="description" content="Discover expert advice on resume writing, job searching, interview preparation, and career development from ResumeX's career experts." />
        <meta name="keywords" content="career blog, resume tips, job search advice, interview preparation, career development, professional growth" />
      </Helmet>
      
      <div className="container mx-auto px-4 py-12 max-w-6xl">
        {/* Hero section */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-3">Career Insights Blog</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Expert advice on resume writing, job searching, interview preparation, and career development
          </p>
        </div>
        
        {/* Search and filters */}
        <div className="bg-accent/30 p-6 rounded-lg mb-10">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                type="text"
                placeholder="Search articles..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <Button 
              variant="outline" 
              onClick={clearFilters}
              disabled={!searchTerm && !selectedCategory && selectedTags.length === 0}
            >
              Clear Filters
            </Button>
          </div>
          
          {/* Categories */}
          <div className="mb-4">
            <h3 className="text-sm font-medium mb-2">Categories:</h3>
            <div className="flex flex-wrap gap-2">
              {allCategories.map(category => (
                <Badge
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  className="cursor-pointer"
                  onClick={() => setSelectedCategory(selectedCategory === category ? null : category)}
                >
                  {category}
                </Badge>
              ))}
            </div>
          </div>
          
          {/* Tags */}
          <div>
            <h3 className="text-sm font-medium mb-2">Popular Tags:</h3>
            <div className="flex flex-wrap gap-2">
              {allTags.map(tag => (
                <Badge
                  key={tag}
                  variant={selectedTags.includes(tag) ? "secondary" : "outline"}
                  className="cursor-pointer"
                  onClick={() => toggleTag(tag)}
                >
                  #{tag}
                </Badge>
              ))}
            </div>
          </div>
        </div>
        
        {/* Blog posts grid */}
        {filteredPosts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPosts.map((post) => (
              <article key={post.id} className="flex flex-col border border-border rounded-lg overflow-hidden hover:shadow-md transition-shadow bg-card">
                <div className="h-48 overflow-hidden relative">
                  <img 
                    src={post.imageUrl} 
                    alt={post.title} 
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                  />
                  <Badge className="absolute top-3 right-3" variant="secondary">
                    {post.category}
                  </Badge>
                </div>
                
                <div className="p-5 flex-1 flex flex-col">
                  <div className="flex items-center text-sm text-muted-foreground mb-3 gap-4">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-3.5 w-3.5" />
                      <span>{post.date}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="h-3.5 w-3.5" />
                      <span>{post.readTime}</span>
                    </div>
                  </div>
                  
                  <h2 className="text-xl font-bold mb-2 leading-tight">
                    <Link href={`/blog/${post.slug}`} className="hover:text-primary transition-colors">
                      {post.title}
                    </Link>
                  </h2>
                  
                  <p className="text-muted-foreground mb-4 text-sm flex-1">
                    {post.excerpt}
                  </p>
                  
                  <div className="flex items-center justify-between mt-auto">
                    <div className="flex items-center gap-2">
                      <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center">
                        <User className="h-4 w-4 text-primary" />
                      </div>
                      <span className="text-sm font-medium">{post.author}</span>
                    </div>
                    
                    <Link href={`/blog/${post.slug}`} className="text-primary hover:text-primary/80 font-medium text-sm flex items-center gap-1 group">
                      Read More
                      <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-0.5 transition-transform" />
                    </Link>
                  </div>
                </div>
              </article>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <h3 className="text-xl font-medium mb-2">No articles found</h3>
            <p className="text-muted-foreground">Try adjusting your search criteria or filters</p>
          </div>
        )}
      </div>
    </>
  );
}