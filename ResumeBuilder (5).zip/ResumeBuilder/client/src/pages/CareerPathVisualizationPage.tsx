import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { Helmet } from 'react-helmet';
import { Redirect } from 'wouter';
import { 
  BriefcaseIcon, 
  ArrowRightIcon, 
  TrendingUpIcon,
  DownloadIcon,
  ShareIcon,
  InfoIcon 
} from 'lucide-react';

// UI Components
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Card, 
  CardHeader, 
  CardTitle, 
  CardDescription, 
  CardContent, 
  CardFooter 
} from '@/components/ui/card';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import CareerPathVisualization, { CareerPath } from '@/components/CareerPathVisualization';

// Example data for the career path visualizations
// In a real app, this would come from an API or service
const SOFTWARE_DEV_PATHS: CareerPath[] = [
  {
    id: 'frontend',
    name: 'Frontend Development',
    description: 'A career path focused on building user interfaces and web applications with a focus on visual design and user experience.',
    nodes: [
      {
        id: 'frontend-1',
        title: 'Junior Frontend Developer',
        level: 1,
        salary: '$60,000 - $80,000',
        skills: ['HTML', 'CSS', 'JavaScript', 'React Basics'],
        description: 'Entry-level position focused on implementing UI components and basic interactivity following established patterns and designs.',
        timeframe: '0-2 years',
        isCurrentRole: true
      },
      {
        id: 'frontend-2',
        title: 'Frontend Developer',
        level: 2,
        salary: '$80,000 - $110,000',
        skills: ['React', 'TypeScript', 'CSS-in-JS', 'State Management', 'REST APIs'],
        description: 'Mid-level position building complex UI components, implementing application state management, and integrating with backend services.',
        timeframe: '2-4 years'
      },
      {
        id: 'frontend-3',
        title: 'Senior Frontend Developer',
        level: 3,
        salary: '$120,000 - $150,000',
        skills: ['Advanced React', 'Performance Optimization', 'Architecture', 'Next.js', 'Testing'],
        description: 'Senior role focused on application architecture, performance optimization, and establishing best practices for the frontend team.',
        timeframe: '4-7 years'
      },
      {
        id: 'frontend-4',
        title: 'Frontend Architect',
        level: 4,
        salary: '$150,000 - $180,000',
        skills: ['System Design', 'Micro-frontends', 'Build Systems', 'Technical Leadership'],
        description: 'Expert role designing frontend architecture for complex applications, establishing standards, and providing technical guidance to the team.',
        timeframe: '7-10 years'
      },
      {
        id: 'frontend-5',
        title: 'Director of Frontend Engineering',
        level: 5,
        salary: '$180,000 - $220,000+',
        skills: ['Team Leadership', 'Technical Strategy', 'Engineering Processes', 'Hiring'],
        description: 'Leadership role managing frontend teams, setting technical direction, and collaborating with other departments to deliver user-facing systems.',
        timeframe: '10+ years'
      }
    ]
  },
  {
    id: 'backend',
    name: 'Backend Development',
    description: 'A career path focused on building server-side applications, databases, and infrastructure to power digital products.',
    nodes: [
      {
        id: 'backend-1',
        title: 'Junior Backend Developer',
        level: 1,
        salary: '$65,000 - $85,000',
        skills: ['Node.js/Java/Python', 'SQL Basics', 'RESTful APIs', 'Git'],
        description: 'Entry-level position implementing backend features, writing database queries, and building simple API endpoints.',
        timeframe: '0-2 years'
      },
      {
        id: 'backend-2',
        title: 'Backend Developer',
        level: 2,
        salary: '$85,000 - $115,000',
        skills: ['Advanced APIs', 'Database Design', 'Caching', 'Authentication'],
        description: 'Mid-level position building complex API services, designing database schemas, and implementing performance optimizations.',
        timeframe: '2-4 years'
      },
      {
        id: 'backend-3',
        title: 'Senior Backend Developer',
        level: 3,
        salary: '$125,000 - $160,000',
        skills: ['System Architecture', 'Microservices', 'Security', 'Performance Tuning'],
        description: 'Senior role designing backend systems, optimizing for scale, and establishing technical standards for the backend team.',
        timeframe: '4-7 years'
      },
      {
        id: 'backend-4',
        title: 'Backend Architect',
        level: 4,
        salary: '$160,000 - $190,000',
        skills: ['Distributed Systems', 'Cloud Architecture', 'System Scaling', 'Technical Leadership'],
        description: 'Expert role designing large-scale backend systems, establishing architecture patterns, and providing technical guidance to the team.',
        timeframe: '7-10 years'
      },
      {
        id: 'backend-5',
        title: 'Director of Backend Engineering',
        level: 5,
        salary: '$190,000 - $240,000+',
        skills: ['Team Leadership', 'Technical Strategy', 'Engineering Processes', 'System Design'],
        description: 'Leadership role managing backend engineering teams, setting technical direction, and collaborating with other departments on product strategy.',
        timeframe: '10+ years'
      }
    ]
  },
  {
    id: 'fullstack',
    name: 'Full-Stack Development',
    description: 'A versatile career path spanning both frontend and backend technologies, offering broad expertise across the entire application stack.',
    nodes: [
      {
        id: 'fullstack-1',
        title: 'Junior Full-Stack Developer',
        level: 1,
        salary: '$70,000 - $90,000',
        skills: ['HTML/CSS', 'JavaScript', 'React Basics', 'Node.js', 'SQL Basics'],
        description: 'Entry-level position working on both frontend and backend aspects of applications, with guidance from senior team members.',
        timeframe: '0-2 years'
      },
      {
        id: 'fullstack-2',
        title: 'Full-Stack Developer',
        level: 2,
        salary: '$90,000 - $120,000',
        skills: ['React', 'Node.js/Python/Java', 'SQL/NoSQL', 'REST APIs', 'Git'],
        description: 'Mid-level position building complete features spanning frontend and backend, including UI components, API services, and database work.',
        timeframe: '2-4 years'
      },
      {
        id: 'fullstack-3',
        title: 'Senior Full-Stack Developer',
        level: 3,
        salary: '$130,000 - $170,000',
        skills: ['Advanced Frontend', 'Advanced Backend', 'DevOps', 'System Design', 'Testing'],
        description: 'Senior role designing and implementing end-to-end features, making architectural decisions, and mentoring junior developers.',
        timeframe: '4-7 years'
      },
      {
        id: 'fullstack-4',
        title: 'Technical Lead / Full-Stack Architect',
        level: 4,
        salary: '$170,000 - $200,000',
        skills: ['Architecture Design', 'Team Leadership', 'Performance Optimization', 'Technical Strategy'],
        description: 'Lead role designing system architecture, establishing best practices, and providing technical leadership to development teams.',
        timeframe: '7-10 years'
      },
      {
        id: 'fullstack-5',
        title: 'Director of Engineering',
        level: 5,
        salary: '$200,000 - $250,000+',
        skills: ['Engineering Management', 'Technical Strategy', 'Cross-functional Leadership', 'Product Strategy'],
        description: 'Leadership role managing engineering teams, setting technical direction, and working closely with product and business stakeholders.',
        timeframe: '10+ years'
      }
    ]
  }
];

const DATA_SCIENCE_PATHS: CareerPath[] = [
  {
    id: 'data-scientist',
    name: 'Data Science',
    description: 'A career path focused on extracting insights and value from data through statistical analysis, machine learning, and visualization.',
    nodes: [
      {
        id: 'ds-1',
        title: 'Junior Data Scientist',
        level: 1,
        salary: '$70,000 - $90,000',
        skills: ['Python', 'SQL', 'Statistics', 'Data Visualization', 'Pandas'],
        description: 'Entry-level position working on data analysis, creating visualizations, and assisting with machine learning projects under guidance.',
        timeframe: '0-2 years',
        isCurrentRole: true
      },
      {
        id: 'ds-2',
        title: 'Data Scientist',
        level: 2,
        salary: '$90,000 - $120,000',
        skills: ['Machine Learning', 'Feature Engineering', 'Data Pipelines', 'Python', 'SQL'],
        description: 'Mid-level position building predictive models, analyzing complex datasets, and communicating findings to stakeholders.',
        timeframe: '2-4 years'
      },
      {
        id: 'ds-3',
        title: 'Senior Data Scientist',
        level: 3,
        salary: '$120,000 - $160,000',
        skills: ['Advanced ML', 'Deep Learning', 'Statistical Modeling', 'Research', 'MLOps'],
        description: 'Senior role designing complex machine learning solutions, leading data science projects, and mentoring junior team members.',
        timeframe: '4-7 years'
      },
      {
        id: 'ds-4',
        title: 'Lead Data Scientist',
        level: 4,
        salary: '$160,000 - $200,000',
        skills: ['ML Systems Design', 'Team Leadership', 'Research Direction', 'Business Strategy'],
        description: 'Lead role directing data science initiatives, designing machine learning systems, and translating business needs into technical solutions.',
        timeframe: '7-10 years'
      },
      {
        id: 'ds-5',
        title: 'Director of Data Science',
        level: 5,
        salary: '$200,000 - $250,000+',
        skills: ['Team Management', 'AI Strategy', 'Stakeholder Management', 'Product Strategy'],
        description: 'Leadership role managing data science teams, setting strategic direction for AI/ML initiatives, and working with executive stakeholders.',
        timeframe: '10+ years'
      }
    ]
  },
  {
    id: 'ml-engineer',
    name: 'Machine Learning Engineering',
    description: 'A specialized path focused on building and deploying machine learning systems at scale, bridging data science and software engineering.',
    nodes: [
      {
        id: 'mle-1',
        title: 'Junior ML Engineer',
        level: 1,
        salary: '$75,000 - $95,000',
        skills: ['Python', 'ML Frameworks', 'Basic DevOps', 'Data Processing'],
        description: 'Entry-level position implementing machine learning models, building data pipelines, and assisting with model deployment.',
        timeframe: '0-2 years'
      },
      {
        id: 'mle-2',
        title: 'ML Engineer',
        level: 2,
        salary: '$95,000 - $130,000',
        skills: ['Model Deployment', 'Feature Engineering', 'MLOps', 'Distributed Computing'],
        description: 'Mid-level position building robust ML systems, designing data pipelines, and implementing model serving infrastructure.',
        timeframe: '2-4 years'
      },
      {
        id: 'mle-3',
        title: 'Senior ML Engineer',
        level: 3,
        salary: '$130,000 - $170,000',
        skills: ['ML System Design', 'Advanced MLOps', 'Performance Optimization', 'Distributed Systems'],
        description: 'Senior role designing scalable ML infrastructure, optimizing model performance, and establishing ML engineering best practices.',
        timeframe: '4-7 years'
      },
      {
        id: 'mle-4',
        title: 'ML Platform Architect',
        level: 4,
        salary: '$170,000 - $210,000',
        skills: ['ML Platform Design', 'System Architecture', 'Team Leadership', 'Technical Strategy'],
        description: 'Architect role designing enterprise ML platforms, creating scalable infrastructure, and guiding technical implementation of ML systems.',
        timeframe: '7-10 years'
      },
      {
        id: 'mle-5',
        title: 'Director of ML Engineering',
        level: 5,
        salary: '$210,000 - $260,000+',
        skills: ['Engineering Leadership', 'ML Strategy', 'Platform Vision', 'Cross-functional Collaboration'],
        description: 'Leadership role managing ML engineering teams, setting platform direction, and working closely with data science and product teams.',
        timeframe: '10+ years'
      }
    ]
  }
];

const UX_DESIGN_PATHS: CareerPath[] = [
  {
    id: 'ux-design',
    name: 'UX Design',
    description: 'A career path focused on designing digital products with a focus on user experience, interface design, and usability.',
    nodes: [
      {
        id: 'uxd-1',
        title: 'Junior UX Designer',
        level: 1,
        salary: '$60,000 - $80,000',
        skills: ['UI Design', 'Wireframing', 'Prototyping', 'User Research Basics'],
        description: 'Entry-level position creating wireframes, UI elements, and prototypes under the guidance of senior designers.',
        timeframe: '0-2 years'
      },
      {
        id: 'uxd-2',
        title: 'UX Designer',
        level: 2,
        salary: '$80,000 - $110,000',
        skills: ['Interaction Design', 'User Testing', 'Information Architecture', 'Visual Design'],
        description: 'Mid-level position designing user flows, conducting usability testing, and creating comprehensive design solutions for products.',
        timeframe: '2-4 years'
      },
      {
        id: 'uxd-3',
        title: 'Senior UX Designer',
        level: 3,
        salary: '$110,000 - $140,000',
        skills: ['Design Systems', 'Advanced Research', 'Design Strategy', 'Mentorship'],
        description: 'Senior role leading design projects, establishing design systems, and making strategic UX decisions that align with business goals.',
        timeframe: '4-7 years'
      },
      {
        id: 'uxd-4',
        title: 'UX Lead / Design Manager',
        level: 4,
        salary: '$140,000 - $180,000',
        skills: ['Team Leadership', 'Design Direction', 'Cross-functional Collaboration', 'UX Strategy'],
        description: 'Leadership role managing design teams, establishing design direction, and advocating for user experience across the organization.',
        timeframe: '7-10 years'
      },
      {
        id: 'uxd-5',
        title: 'Director of Design',
        level: 5,
        salary: '$180,000 - $230,000+',
        skills: ['Design Leadership', 'Product Strategy', 'Organizational Influence', 'Vision Setting'],
        description: 'Executive design role setting the vision for product design, building design culture, and driving UX strategy at the organizational level.',
        timeframe: '10+ years'
      }
    ]
  }
];

// Organize career paths by industry
const CAREER_PATHS_BY_INDUSTRY = [
  {
    industry: 'Software Development',
    paths: SOFTWARE_DEV_PATHS
  },
  {
    industry: 'Data Science & AI',
    paths: DATA_SCIENCE_PATHS
  },
  {
    industry: 'Design',
    paths: UX_DESIGN_PATHS
  }
];

export default function CareerPathVisualizationPage() {
  const { user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const [selectedIndustry, setSelectedIndustry] = useState('Software Development');
  const [isLoading, setIsLoading] = useState(false);
  
  // Get paths for selected industry
  const industryData = CAREER_PATHS_BY_INDUSTRY.find(i => i.industry === selectedIndustry);
  const paths = industryData ? industryData.paths : [];
  
  // Initialize the page data
  useEffect(() => {
    const initPageData = async () => {
      if (!user) return;
      
      try {
        setIsLoading(true);
        // Make a simple API call to validate backend connection
        try {
          const response = await fetch('/api/ai/career-paths', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              currentRole: 'Software Developer',
              yearsOfExperience: 3,
              skills: ['JavaScript', 'React', 'Node.js'],
              interests: ['Web Development', 'UI Design'],
              educationLevel: "Bachelor's Degree",
              industry: selectedIndustry
            }),
          });
          
          if (response.ok) {
            // We don't need to use the response data since we're using static data in the component
            await response.json();
          }
        } catch (apiError) {
          console.warn('API call failed, using static data instead:', apiError);
          // Continue with static data even if the API call fails
        }
      } catch (error) {
        console.error('Error initializing career path data:', error);
        toast({
          title: 'Using static career path data',
          description: "We're showing example career paths while we load your personalized recommendations.",
          variant: 'default',
        });
      } finally {
        // Always finish loading regardless of API success/failure
        setIsLoading(false);
      }
    };
    
    initPageData();
  }, [user, selectedIndustry, toast]);
  
  // Redirect if not authenticated
  if (!authLoading && !user) {
    return <Redirect to="/auth" />;
  }
  
  // Show loading state
  if (isLoading) {
    return (
      <div className="container max-w-7xl py-10">
        <div className="flex flex-col gap-6">
          <div className="flex flex-col gap-2">
            <h1 className="text-3xl font-bold tracking-tight">Career Path Visualization</h1>
            <p className="text-muted-foreground">
              Loading your personalized career paths...
            </p>
          </div>
          <div className="flex justify-center py-20">
            <div className="animate-spin w-12 h-12 border-4 border-primary border-t-transparent rounded-full" />
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container max-w-7xl py-10">
      <Helmet>
        <title>Career Path Visualization | ResumeX</title>
        <meta name="description" content="Explore interactive career paths, growth trajectories, and salary progressions across different industries and roles." />
      </Helmet>
      
      <div className="flex flex-col gap-6">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-bold tracking-tight">Career Path Visualization</h1>
          <p className="text-muted-foreground">
            Explore interactive career trajectories, progression paths, and salary trends across industries.
          </p>
        </div>
        
        <Separator />
        
        <div className="flex flex-col md:flex-row justify-between gap-4">
          <div className="flex flex-wrap items-center gap-4">
            <div className="w-64">
              <Select
                value={selectedIndustry}
                onValueChange={setSelectedIndustry}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select an industry" />
                </SelectTrigger>
                <SelectContent>
                  {CAREER_PATHS_BY_INDUSTRY.map(industry => (
                    <SelectItem key={industry.industry} value={industry.industry}>
                      {industry.industry}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center gap-1.5">
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="outline" size="icon" className="h-8 w-8">
                      <InfoIcon size={16} />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="max-w-xs">
                      These career paths are based on industry data and show typical progression. Your actual path may vary based on your skills, location, and company.
                    </p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="gap-1.5">
              <ShareIcon size={16} />
              <span>Share</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <DownloadIcon size={16} />
              <span>Save as PDF</span>
            </Button>
          </div>
        </div>
        
        <Card>
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2">
              <BriefcaseIcon className="h-5 w-5 text-primary" />
              Interactive Career Path Visualization
            </CardTitle>
            <CardDescription>
              See how your career could evolve over time. Use the controls to navigate through different career stages.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="pt-2">
              <CareerPathVisualization paths={paths} />
            </div>
          </CardContent>
        </Card>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUpIcon className="h-5 w-5 text-primary" />
                Growth Potential
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Career growth in {selectedIndustry} remains strong, with a 15-20% salary increase typical between each career level. Technical leadership roles command the highest premiums.
              </p>
              <ul className="mt-4 space-y-3">
                <li className="flex items-start gap-2 text-sm">
                  <ArrowRightIcon className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                  <span>Learning specialized skills can accelerate progression by 1-2 years</span>
                </li>
                <li className="flex items-start gap-2 text-sm">
                  <ArrowRightIcon className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                  <span>Advancement typically requires both technical depth and leadership ability</span>
                </li>
                <li className="flex items-start gap-2 text-sm">
                  <ArrowRightIcon className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                  <span>Shifting between companies often accelerates salary growth</span>
                </li>
              </ul>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><path d="M10 11h.01"></path><path d="M14 6h.01"></path><path d="M18 6h.01"></path><path d="M6.5 13.5h.01"></path><path d="M22 5c0 9-4 12-4 12H6s-4-3-4-12c0-2.8 2.2-5 5-5h10c2.8 0 5 2.2 5 5Z"></path><path d="m18 18-3 3-3-3"></path></svg>
                Key Success Factors
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Based on our analysis of successful career trajectories in {selectedIndustry}, these factors most strongly correlate with rapid advancement:
              </p>
              <ul className="mt-4 space-y-3">
                <li className="flex items-start gap-2 text-sm">
                  <ArrowRightIcon className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                  <span>Consistent skill development and certification</span>
                </li>
                <li className="flex items-start gap-2 text-sm">
                  <ArrowRightIcon className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                  <span>Proactive contribution to complex, cross-functional projects</span>
                </li>
                <li className="flex items-start gap-2 text-sm">
                  <ArrowRightIcon className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                  <span>Building a professional network through communities and events</span>
                </li>
                <li className="flex items-start gap-2 text-sm">
                  <ArrowRightIcon className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                  <span>Mentorship from industry veterans</span>
                </li>
              </ul>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path><path d="M14.05 2a9 9 0 0 1 8 7.94"></path><path d="M14.05 6A5 5 0 0 1 18 10"></path></svg>
                Connect With Mentors
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Accelerate your career growth by connecting with experienced professionals in {selectedIndustry} who can provide guidance and insights.
              </p>
              <div className="mt-4 space-y-4">
                <Button className="w-full">Find a Mentor</Button>
                <p className="text-sm text-center text-muted-foreground">
                  <span className="font-medium">250+ mentors</span> available in this industry
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="bg-muted/30 p-6 rounded-lg border mt-4">
          <h2 className="text-xl font-semibold mb-4">Personalize Your Career Path</h2>
          <p className="mb-6">
            Get a customized career growth plan based on your specific skills, experience, and goals.
          </p>
          <div className="flex flex-wrap gap-4">
            <Button className="gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" x2="16" y1="2" y2="6"></line><line x1="8" x2="8" y1="2" y2="6"></line><line x1="3" x2="21" y1="10" y2="10"></line><path d="m9 16 2 2 4-4"></path></svg>
              Schedule Career Strategy Session
            </Button>
            <Button variant="outline" className="gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m9.5 9.5-3 3v-3l3 3"></path><path d="M16 7h.01"></path><rect x="2" y="3" width="20" height="14" rx="2"></rect><path d="M22 5v10a2 2 0 0 1-2 2H4"></path><path d="M22 10H2"></path></svg>
              View Recommended Training
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}