import { useState } from 'react';
import { Link } from 'wouter';
import { useUserResumes, useDeleteResume } from '@/hooks/use-load-resume';
import { useAuth } from '@/hooks/use-auth';
import { Button } from '@/components/ui/button';
import { Helmet } from 'react-helmet';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { queryClient } from '@/lib/queryClient';
import { AlertTriangle, Loader2, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function ResumeList() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [resumeToDelete, setResumeToDelete] = useState<number | null>(null);
  
  // Fetch user's resumes
  const { data: resumes, isLoading, error, refetch } = useUserResumes(user?.id ?? null);
  
  // Delete resume mutation
  const deleteResumeMutation = useDeleteResume(user?.id ?? null);
  
  // Handle delete resume
  const handleDeleteResume = () => {
    if (resumeToDelete) {
      deleteResumeMutation.mutate(resumeToDelete, {
        onSuccess: () => {
          toast({
            title: "Resume deleted",
            description: "Your resume has been successfully deleted.",
          });
          setResumeToDelete(null);
        },
        onError: (error) => {
          toast({
            title: "Failed to delete resume",
            description: "An error occurred while deleting your resume. Please try again.",
            variant: "destructive",
          });
          setResumeToDelete(null);
        }
      });
    }
  };
  
  return (
    <>
      <Helmet>
        <title>My Resumes | ResumeX</title>
        <meta name="description" content="View and manage your saved resumes." />
      </Helmet>
      
      <div className="min-h-screen bg-background">
        {/* Page Header */}
        <div className="p-6 bg-muted/30 border-b">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-2xl font-bold">My Resumes</h1>
            <p className="text-muted-foreground mt-2">
              View, edit, and manage your saved resumes
            </p>
          </div>
        </div>
        
        {/* Resume List */}
        <div className="max-w-7xl mx-auto p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold">Saved Resumes</h2>
            <Link href="/builder">
              <Button className="bg-primary hover:bg-primary/90">
                Create New Resume
              </Button>
            </Link>
          </div>
          
          {isLoading ? (
            <div className="text-center py-10">
              <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto" />
              <p className="mt-4 text-muted-foreground">Loading your resumes...</p>
            </div>
          ) : error ? (
            <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-6 text-center">
              <AlertTriangle className="h-10 w-10 text-destructive mx-auto mb-2" />
              <h3 className="text-destructive font-semibold text-lg">Error Loading Resumes</h3>
              <p className="text-muted-foreground mt-2">
                There was a problem loading your resumes. Please try again later.
              </p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => refetch()}
              >
                Retry
              </Button>
            </div>
          ) : resumes && resumes.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {resumes.map(resume => (
                <Card key={resume.id} className="hover:shadow-md transition-shadow border border-border">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-lg">{resume.title}</CardTitle>
                      {resume.isDefault && (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-800/30 dark:text-green-400">
                          Default
                        </span>
                      )}
                    </div>
                    <CardDescription>
                      Last updated: {new Date(resume.updatedAt).toLocaleDateString()}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-sm text-muted-foreground space-y-1">
                      <p className="flex items-center">
                        <span className="font-medium mr-2">Template:</span> 
                        {resume.templateId}
                      </p>
                      <p className="flex items-center">
                        <span className="font-medium mr-2">Sections:</span> 
                        {resume.data && typeof resume.data === 'object' ? Object.keys(resume.data).length : 0}
                      </p>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Link href={`/builder?id=${resume.id}`}>
                      <Button variant="outline">Edit</Button>
                    </Link>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button 
                          variant="ghost" 
                          className="text-destructive hover:text-destructive/90 hover:bg-destructive/10"
                          onClick={() => setResumeToDelete(resume.id)}
                        >
                          <Trash2 className="w-4 h-4 mr-1" />
                          Delete
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                          <AlertDialogDescription>
                            This action cannot be undone. This will permanently delete your
                            resume and all of its contents.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel onClick={() => setResumeToDelete(null)}>Cancel</AlertDialogCancel>
                          <AlertDialogAction 
                            onClick={handleDeleteResume}
                            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            disabled={deleteResumeMutation.isPending}
                          >
                            {deleteResumeMutation.isPending ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Deleting...
                              </>
                            ) : (
                              "Delete Resume"
                            )}
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : (
            <div className="bg-muted/40 border border-border rounded-lg p-10 text-center">
              <h3 className="text-xl font-semibold mb-2">No Resumes Found</h3>
              <p className="text-muted-foreground mb-6">
                You haven't created any resumes yet. Get started by creating your first resume.
              </p>
              <Link href="/builder">
                <Button className="bg-primary hover:bg-primary/90">
                  Create Your First Resume
                </Button>
              </Link>
            </div>
          )}
        </div>
      </div>
    </>
  );
}