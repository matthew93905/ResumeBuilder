import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { getAffiliateLink, trackAffiliateClick } from "@/lib/affiliateUtils";
import { Helmet } from "react-helmet";
import { Loader2, ArrowRight, ChevronRight, Award, Lightbulb, Clock, Briefcase, DollarSign, GraduationCap, Zap, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useLocation } from "wouter";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

// Define types for our career path recommendation API response
type CareerPathOption = {
  title: string;
  description: string;
  requiredSkills: string[];
  recommendedSkills: string[];
  salary: string;
  growthPotential: string;
  timeframe: string;
  recommendedEducation?: string[];
};

type CareerPathResponse = {
  currentAssessment: string;
  recommendedPaths: CareerPathOption[];
  generalAdvice: string;
};

export default function CareerExplorer() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  
  // Form state
  const [currentRole, setCurrentRole] = useState("");
  const [yearsOfExperience, setYearsOfExperience] = useState("");
  const [skillsInput, setSkillsInput] = useState("");
  const [interestsInput, setInterestsInput] = useState("");
  const [educationLevel, setEducationLevel] = useState("");
  const [industry, setIndustry] = useState("");
  const [location, setLocation] = useState("");
  
  // Results state
  const [isLoading, setIsLoading] = useState(false);
  const [recommendations, setRecommendations] = useState<CareerPathResponse | null>(null);
  const [selectedPathIndex, setSelectedPathIndex] = useState(0);

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const skills = skillsInput.split(',').map(skill => skill.trim()).filter(Boolean);
    const interests = interestsInput.split(',').map(interest => interest.trim()).filter(Boolean);
    
    // Validate form
    if (!currentRole) {
      toast({
        title: "Current role is required",
        variant: "destructive",
      });
      return;
    }
    
    if (!yearsOfExperience || isNaN(Number(yearsOfExperience))) {
      toast({
        title: "Valid years of experience is required",
        variant: "destructive",
      });
      return;
    }
    
    if (skills.length === 0) {
      toast({
        title: "At least one skill is required",
        variant: "destructive",
      });
      return;
    }
    
    if (interests.length === 0) {
      toast({
        title: "At least one interest is required",
        variant: "destructive",
      });
      return;
    }
    
    if (!educationLevel) {
      toast({
        title: "Education level is required",
        variant: "destructive",
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      const response = await apiRequest("POST", "/api/ai/career-paths", {
        currentRole,
        yearsOfExperience: Number(yearsOfExperience),
        skills,
        interests,
        educationLevel,
        industry: industry || undefined,
        location: location || undefined,
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || "Failed to get career recommendations");
      }
      
      setRecommendations(data);
      // Reset to first path when we get new recommendations
      setSelectedPathIndex(0);
    } catch (error) {
      toast({
        title: "Error getting career recommendations",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  // Helper to render skill badges
  const renderSkills = (skills: string[] | undefined, className = "") => {
    if (!skills || !Array.isArray(skills)) return null;
    return skills.map((skill, i) => (
      <Badge key={i} variant="secondary" className={`mr-2 mb-2 ${className}`}>
        {skill}
      </Badge>
    ));
  };
  
  return (
    <>
      <Helmet>
        <title>Career Explorer | ResumeX</title>
      </Helmet>
      
      <div className="container py-8 mx-auto">
        <div className="flex flex-col gap-2 pb-6">
          <h1 className="text-3xl font-bold tracking-tight">Career Explorer</h1>
          <p className="text-muted-foreground">
            Discover potential career paths based on your skills, experience, and interests.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Form Section */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle className="text-xl">Tell us about yourself</CardTitle>
              <CardDescription>
                We'll use AI to recommend personalized career paths that match your profile.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-3">
                  <label className="text-sm font-medium">
                    Current Job Role
                    <span className="text-destructive">*</span>
                  </label>
                  <Input
                    placeholder="e.g. Frontend Developer"
                    value={currentRole}
                    onChange={(e) => setCurrentRole(e.target.value)}
                    required
                  />
                </div>
                
                <div className="space-y-3">
                  <label className="text-sm font-medium">
                    Years of Experience
                    <span className="text-destructive">*</span>
                  </label>
                  <Input
                    type="number"
                    min="0"
                    placeholder="e.g. 3"
                    value={yearsOfExperience}
                    onChange={(e) => setYearsOfExperience(e.target.value)}
                    required
                  />
                </div>
                
                <div className="space-y-3">
                  <label className="text-sm font-medium">
                    Your Skills
                    <span className="text-destructive">*</span>
                    <span className="block text-xs text-muted-foreground mt-1">
                      Separate with commas
                    </span>
                  </label>
                  <Textarea
                    placeholder="e.g. React, JavaScript, UI Design"
                    value={skillsInput}
                    onChange={(e) => setSkillsInput(e.target.value)}
                    required
                  />
                </div>
                
                <div className="space-y-3">
                  <label className="text-sm font-medium">
                    Your Interests
                    <span className="text-destructive">*</span>
                    <span className="block text-xs text-muted-foreground mt-1">
                      Separate with commas
                    </span>
                  </label>
                  <Textarea
                    placeholder="e.g. Data Analysis, Team Leadership"
                    value={interestsInput}
                    onChange={(e) => setInterestsInput(e.target.value)}
                    required
                  />
                </div>
                
                <div className="space-y-3">
                  <label className="text-sm font-medium">
                    Education Level
                    <span className="text-destructive">*</span>
                  </label>
                  <Input
                    placeholder="e.g. Bachelor's Degree"
                    value={educationLevel}
                    onChange={(e) => setEducationLevel(e.target.value)}
                    required
                  />
                </div>
                
                <div className="space-y-3">
                  <label className="text-sm font-medium">
                    Industry (Optional)
                  </label>
                  <Input
                    placeholder="e.g. Healthcare, Finance"
                    value={industry}
                    onChange={(e) => setIndustry(e.target.value)}
                  />
                </div>

                <div className="space-y-3">
                  <label className="text-sm font-medium">
                    Your Location (Optional)
                    <span className="block text-xs text-muted-foreground mt-1">
                      For educational institution recommendations
                    </span>
                  </label>
                  <Input
                    placeholder="e.g. New York, NY"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                  />
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-secondary to-primary text-white"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> 
                      Analyzing Your Profile
                    </>
                  ) : (
                    <>
                      Get Career Recommendations <ArrowRight className="ml-2 h-4 w-4" />
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
          
          {/* Results Section */}
          <div className="lg:col-span-2">
            {isLoading ? (
              <div className="h-full flex flex-col items-center justify-center p-8">
                <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-2">Analyzing Your Career Profile</h3>
                <p className="text-muted-foreground text-center max-w-md">
                  Our AI is considering your skills, experience, and interests to find the best career paths for you.
                </p>
              </div>
            ) : recommendations ? (
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-xl">Your Career Assessment</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>{recommendations.currentAssessment}</p>
                  </CardContent>
                </Card>
                
                <h3 className="text-xl font-semibold mt-8">Recommended Career Paths</h3>
                
                <Tabs 
                  defaultValue="0" 
                  value={selectedPathIndex.toString()}
                  onValueChange={(value) => setSelectedPathIndex(parseInt(value))}
                  className="w-full"
                >
                  <TabsList className="grid grid-cols-3 mb-6">
                    {recommendations.recommendedPaths && recommendations.recommendedPaths.length > 0 ? 
                      recommendations.recommendedPaths.slice(0, 3).map((path, index) => (
                        <TabsTrigger key={index} value={index.toString()} className="text-sm">
                          {path.title}
                        </TabsTrigger>
                      )) : 
                      <TabsTrigger value="0" className="text-sm">No paths found</TabsTrigger>
                    }
                  </TabsList>
                  
                  {recommendations.recommendedPaths && recommendations.recommendedPaths.length > 0 && 
                    recommendations.recommendedPaths.map((path, index) => (
                    <TabsContent key={index} value={index.toString()}>
                      <Card>
                        <CardHeader className="pb-3">
                          <div className="flex items-center justify-between">
                            <CardTitle className="text-2xl font-bold text-primary">
                              {path.title}
                            </CardTitle>
                            <DollarSign className="h-5 w-5 text-green-500" />
                          </div>
                          
                          <div className="flex items-center text-muted-foreground text-sm mt-1">
                            <Briefcase className="h-4 w-4 mr-1" />
                            <span>Salary: {path.salary}</span>
                          </div>
                        </CardHeader>
                        
                        <CardContent className="space-y-4">
                          <p className="text-gray-600 dark:text-gray-300">{path.description}</p>
                          
                          <div className="mt-6">
                            <div className="flex items-center mb-2">
                              <Award className="h-5 w-5 text-amber-500 mr-2" />
                              <h4 className="font-semibold">Required Skills</h4>
                            </div>
                            <div className="flex flex-wrap mt-2">
                              {renderSkills(path.requiredSkills)}
                            </div>
                          </div>
                          
                          <div className="mt-4">
                            <div className="flex items-center mb-2">
                              <Zap className="h-5 w-5 text-blue-500 mr-2" />
                              <h4 className="font-semibold">Skills to Develop</h4>
                            </div>
                            <div className="flex flex-wrap mt-2">
                              {renderSkills(path.recommendedSkills)}
                            </div>
                          </div>
                          
                          <Separator className="my-4" />
                          
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <div className="flex items-center mb-2">
                                <Clock className="h-5 w-5 text-indigo-500 mr-2" />
                                <h4 className="font-semibold">Timeframe</h4>
                              </div>
                              <p className="text-sm">{path.timeframe}</p>
                            </div>
                            
                            <div>
                              <div className="flex items-center mb-2">
                                <GraduationCap className="h-5 w-5 text-purple-500 mr-2" />
                                <h4 className="font-semibold">Growth Potential</h4>
                              </div>
                              <p className="text-sm">{path.growthPotential}</p>
                            </div>
                          </div>
                          
                          {path.recommendedEducation && path.recommendedEducation.length > 0 && (
                            <div className="mt-4">
                              <div className="flex items-center mb-2">
                                <GraduationCap className="h-5 w-5 text-emerald-500 mr-2" />
                                <h4 className="font-semibold">Recommended Educational Paths</h4>
                              </div>
                              <ul className="list-disc pl-5 space-y-2">
                                <TooltipProvider>
                                  {path.recommendedEducation.map((institution, i) => {
                                    const { url, isAffiliate } = getAffiliateLink(institution);
                                    return (
                                      <li key={i} className="text-sm flex items-center gap-2 group">
                                        <a 
                                          href={url} 
                                          target="_blank" 
                                          rel="noopener noreferrer"
                                          className="text-primary hover:underline flex items-center"
                                          onClick={() => {
                                            trackAffiliateClick(institution, isAffiliate);
                                            // Show toast for premium users about earning credits
                                            if (user?.isPremium && isAffiliate) {
                                              toast({
                                                title: "Affiliate Reward",
                                                description: "You've earned credits for this referral as a premium member!",
                                                duration: 3000,
                                              });
                                            }
                                          }}
                                        >
                                          {institution}
                                          <ExternalLink className="h-3 w-3 ml-1 opacity-70" />
                                        </a>
                                        
                                        {isAffiliate && (
                                          <Tooltip>
                                            <TooltipTrigger asChild>
                                              <Badge 
                                                variant="outline" 
                                                className="ml-2 py-0 h-5 text-xs border-green-500/30 text-green-500 hover:bg-green-500/10 cursor-help"
                                              >
                                                Partner
                                              </Badge>
                                            </TooltipTrigger>
                                            <TooltipContent>
                                              <p className="text-xs max-w-[200px]">
                                                {user?.isPremium ? 
                                                  "As a premium member, you'll earn credits for using this partner link!" :
                                                  "Upgrade to premium to earn credits when using partner links!"}
                                              </p>
                                            </TooltipContent>
                                          </Tooltip>
                                        )}
                                      </li>
                                    );
                                  })}
                                </TooltipProvider>
                              </ul>
                            </div>
                          )}
                        </CardContent>
                        
                        <CardFooter className="flex justify-between pt-2">
                          <Button 
                            variant="outline" 
                            onClick={() => {
                              if (recommendations.recommendedPaths && index < recommendations.recommendedPaths.length - 1) {
                                setSelectedPathIndex(index + 1);
                              }
                            }}
                            disabled={!recommendations.recommendedPaths || index >= recommendations.recommendedPaths.length - 1}
                          >
                            Next Path <ChevronRight className="ml-1 h-4 w-4" />
                          </Button>
                          
                          <Button 
                            onClick={() => navigate('/builder')}
                            className="bg-gradient-to-r from-secondary to-primary text-white"
                          >
                            Create Resume for this Role
                          </Button>
                        </CardFooter>
                      </Card>
                    </TabsContent>
                  ))}
                </Tabs>
                
                <Card className="mt-8">
                  <CardHeader className="pb-3">
                    <div className="flex items-center">
                      <Lightbulb className="h-5 w-5 text-yellow-500 mr-2" />
                      <CardTitle className="text-xl">General Career Advice</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p>{recommendations.generalAdvice}</p>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center p-8 bg-accent/30 rounded-lg">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <Briefcase className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Discover Your Career Path</h3>
                <p className="text-muted-foreground text-center max-w-md mb-6">
                  Our AI-powered career explorer will analyze your profile and suggest potential career paths based on your skills and interests.
                </p>
                <Button 
                  onClick={() => document.querySelector('form')?.scrollIntoView({ behavior: 'smooth' })}
                  variant="outline"
                  className="gap-2"
                >
                  Get Started <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}