import HeroSection from "@/components/HeroSection";
import MediaFeatures from "@/components/MediaFeatures";
import FeaturesSection from "@/components/FeaturesSection";
import TemplatesSection from "@/components/TemplatesSection";
import PricingSection from "@/components/PricingSection";
import Testimonials from "@/components/Testimonials";
import CallToAction from "@/components/CallToAction";
import HomePageSEO from "@/components/HomePageSEO";
import CanonicalUrl from "@/components/CanonicalUrl";

export default function Home() {
  return (
    <>
      <HomePageSEO />
      <CanonicalUrl />
      
      <HeroSection />
      <MediaFeatures />
      <FeaturesSection />
      <TemplatesSection />
      <Testimonials />
      <PricingSection />
      <CallToAction />
    </>
  );
}
