import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { loadStripe } from "@stripe/stripe-js";
import {
  Elements,
  PaymentElement,
  useStripe,
  useElements
} from "@stripe/react-stripe-js";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Loader2, Check, CreditCard } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PayPalButton from "@/components/PayPalButton";
import GooglePayButton from "@/components/GooglePayButton";

// Load Stripe outside of component to avoid recreating on renders
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

interface PlanOption {
  id: string;
  name: string;
  priceId: string;
  price: number;
  interval: 'month' | 'year';
  features: string[];
}

// Plans available for subscription
const plans: PlanOption[] = [
  {
    id: 'monthly',
    name: 'Monthly Premium',
    priceId: 'price_monthly', // Replace with actual Stripe price ID
    price: 9.99,
    interval: 'month',
    features: [
      'Access to all premium templates',
      'Unlimited resume exports',
      'Cloud storage for all resumes',
      'Priority support'
    ]
  },
  {
    id: 'yearly',
    name: 'Yearly Premium',
    priceId: 'price_yearly', // Replace with actual Stripe price ID
    price: 99.99,
    interval: 'year',
    features: [
      'All monthly features',
      '2 months free compared to monthly plan',
      'Early access to new templates',
      'Resume analytics'
    ]
  }
];

// Subscription form component that uses Stripe Elements
function SubscriptionForm({ plan }: { plan: PlanOption }) {
  const stripe = useStripe();
  const elements = useElements();
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [location, navigate] = useLocation();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);
    setErrorMessage(null);

    // Confirm payment with Stripe
    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: window.location.origin + "/subscription-success",
      },
    });

    if (error) {
      setErrorMessage(error.message || "An error occurred during payment.");
      toast({
        title: "Payment Failed",
        description: error.message || "An error occurred during payment.",
        variant: "destructive"
      });
      setIsProcessing(false);
    }
    // Payment is handled by redirect, so we don't need to handle success here
  };

  return (
    <div className="max-w-md w-full mx-auto bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-border">
      <div className="mb-6 text-center">
        <h2 className="text-xl font-bold mb-2">{plan.name}</h2>
        <div className="text-primary text-2xl font-bold mb-1">
          ${plan.price.toFixed(2)}
          <span className="text-muted-foreground text-sm font-normal">/{plan.interval}</span>
        </div>
        <p className="text-muted-foreground">Unlock premium features for your resume</p>
      </div>
      
      <div className="mb-6">
        <ul className="space-y-2">
          {plan.features.map((feature, index) => (
            <li key={index} className="flex items-start">
              <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
              <span>{feature}</span>
            </li>
          ))}
        </ul>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <PaymentElement />
        
        {errorMessage && <div className="text-red-500 text-sm">{errorMessage}</div>}
        
        <Button 
          type="submit" 
          disabled={!stripe || isProcessing}
          className="w-full bg-gradient-to-r from-secondary to-primary"
        >
          {isProcessing ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Processing...
            </>
          ) : (
            `Subscribe for $${plan.price.toFixed(2)}/${plan.interval}`
          )}
        </Button>
        <p className="text-xs text-center text-muted-foreground">
          You'll be charged ${plan.price.toFixed(2)} every {plan.interval}. You can cancel anytime.
        </p>
      </form>
    </div>
  );
}

// Plan selection component
function PlanSelection({ plans, selectedPlan, onSelectPlan }: { 
  plans: PlanOption[]; 
  selectedPlan: PlanOption | null; 
  onSelectPlan: (plan: PlanOption) => void;
}) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
      {plans.map((plan) => (
        <div 
          key={plan.id}
          className={`cursor-pointer rounded-xl p-6 border-2 transition-all hover:shadow-md ${
            selectedPlan?.id === plan.id ? 'border-primary bg-accent/30' : 'border-border bg-white dark:bg-gray-800'
          }`}
          onClick={() => onSelectPlan(plan)}
        >
          <div className="text-center mb-4">
            <h3 className="text-lg font-bold mb-1">{plan.name}</h3>
            <div className="text-primary text-2xl font-bold">
              ${plan.price.toFixed(2)}
              <span className="text-muted-foreground text-sm font-normal">/{plan.interval}</span>
            </div>
          </div>
          
          <ul className="space-y-2">
            {plan.features.map((feature, index) => (
              <li key={index} className="flex items-start">
                <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                <span>{feature}</span>
              </li>
            ))}
          </ul>
          
          <Button 
            className={`w-full mt-4 ${
              selectedPlan?.id === plan.id 
                ? 'bg-gradient-to-r from-secondary to-primary' 
                : 'bg-accent text-primary'
            }`}
            variant={selectedPlan?.id === plan.id ? 'default' : 'outline'}
            onClick={() => onSelectPlan(plan)}
          >
            {selectedPlan?.id === plan.id ? 'Selected' : 'Select Plan'}
          </Button>
        </div>
      ))}
    </div>
  );
}

// Main Subscribe page that sets up Stripe Elements
export default function Subscribe() {
  const [clientSecret, setClientSecret] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<PlanOption | null>(null);
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const { toast } = useToast();
  
  const handleSelectPlan = (plan: PlanOption) => {
    setSelectedPlan(plan);
  };
  
  const handleContinue = async () => {
    if (!selectedPlan) {
      toast({
        title: "Please select a plan",
        description: "Choose a subscription plan to continue",
        variant: "destructive"
      });
      return;
    }
    
    setIsLoading(true);
    setShowPaymentForm(true);
    
    try {
      // In a real app, you would pass the actual priceId from Stripe
      // For demo, we just simulate creating a subscription
      const response = await apiRequest("POST", "/api/create-payment-intent", {
        amount: selectedPlan.price
      });
      
      if (!response.ok) {
        throw new Error("Failed to create payment intent");
      }
      
      const data = await response.json();
      setClientSecret(data.clientSecret);
    } catch (error) {
      console.error("Error creating payment intent:", error);
      toast({
        title: "Error",
        description: "Failed to initialize subscription. Please try again.",
        variant: "destructive"
      });
      setShowPaymentForm(false);
    } finally {
      setIsLoading(false);
    }
  };
  
  // Show plan selection first
  if (!showPaymentForm) {
    return (
      <div className="min-h-screen flex flex-col p-4 bg-accent/20">
        <div className="w-full max-w-5xl mx-auto">
          <div className="text-center mb-10 pt-10">
            <h1 className="text-3xl font-bold mb-2">Choose Your Premium Plan</h1>
            <p className="text-muted-foreground">Unlock all premium features and templates</p>
          </div>
          
          <PlanSelection 
            plans={plans} 
            selectedPlan={selectedPlan} 
            onSelectPlan={handleSelectPlan} 
          />
          
          <div className="text-center mt-8">
            <Button 
              onClick={handleContinue}
              disabled={!selectedPlan || isLoading}
              className="bg-gradient-to-r from-secondary to-primary px-8"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                'Continue to Payment'
              )}
            </Button>
          </div>
          
          <div className="text-center mt-8 text-sm text-muted-foreground">
            <p>Your payment is processed securely through your chosen payment method.</p>
            <p>Multiple payment options available: Credit Card, PayPal, and Google Pay.</p>
            <p>You can cancel your subscription at any time.</p>
          </div>
        </div>
      </div>
    );
  }
  
  // Show loading state while payment intent is being created
  if (isLoading || !clientSecret) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4">
        <div className="flex flex-col items-center space-y-4">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
          <p className="text-lg text-muted-foreground">Preparing checkout...</p>
        </div>
      </div>
    );
  }
  
  // Render Stripe Elements when client secret is available
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-accent/20">
      <div className="w-full max-w-4xl">
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold mb-2">Complete Your Subscription</h1>
          <p className="text-muted-foreground">Enter your payment details below</p>
        </div>
        
        {selectedPlan && (
          <div className="max-w-md w-full mx-auto bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-border">
            <div className="mb-6 text-center">
              <h2 className="text-xl font-bold mb-2">{selectedPlan.name}</h2>
              <div className="text-primary text-2xl font-bold mb-1">
                ${selectedPlan.price.toFixed(2)}
                <span className="text-muted-foreground text-sm font-normal">/{selectedPlan.interval}</span>
              </div>
              <p className="text-muted-foreground">Unlock premium features for your resume</p>
            </div>
            
            <div className="mb-6">
              <ul className="space-y-2">
                {selectedPlan.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            <Tabs defaultValue="card" className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-4">
                <TabsTrigger value="card" className="flex items-center gap-2">
                  <CreditCard className="h-4 w-4" />
                  <span>Card</span>
                </TabsTrigger>
                <TabsTrigger value="paypal">
                  <span>PayPal</span>
                </TabsTrigger>
                <TabsTrigger value="googlepay">
                  <span>Google Pay</span>
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="card" className="space-y-4">
                <div className="bg-white dark:bg-gray-800 rounded-md p-4 border border-gray-200 dark:border-gray-700 shadow-sm">
                  <div className="mb-4 text-center">
                    <h3 className="font-medium mb-2">Subscribe with Credit Card</h3>
                    <p className="text-sm text-muted-foreground">Secure subscription payment with credit or debit card</p>
                  </div>
                  <Elements stripe={stripePromise} options={{ clientSecret }}>
                    <form onSubmit={(e) => {
                      e.preventDefault();
                      const stripeForm = document.querySelector('form[data-stripe-form]');
                      if (stripeForm) {
                        (stripeForm as HTMLFormElement).requestSubmit();
                      }
                    }}>
                      <div className="mb-6">
                        <PaymentElement />
                      </div>
                      <Button 
                        type="submit" 
                        className="w-full bg-gradient-to-r from-secondary to-primary"
                      >
                        Subscribe for ${selectedPlan.price.toFixed(2)}/{selectedPlan.interval}
                      </Button>
                      <p className="text-xs text-center text-muted-foreground mt-4">
                        You'll be charged ${selectedPlan.price.toFixed(2)} every {selectedPlan.interval}. You can cancel anytime.
                      </p>
                    </form>
                  </Elements>
                </div>
              </TabsContent>
              
              <TabsContent value="paypal" className="space-y-4">
                <div className="bg-white dark:bg-gray-800 rounded-md p-4 border border-gray-200 dark:border-gray-700 shadow-sm">
                  <div className="mb-4 text-center">
                    <h3 className="font-medium mb-2">Subscribe with PayPal</h3>
                    <p className="text-sm text-muted-foreground">Fast, secure subscription payment with PayPal</p>
                  </div>
                  <PayPalButton 
                    amount={selectedPlan.price.toString()} 
                    currency="USD" 
                    intent="CAPTURE"
                    onSuccess={() => {
                      toast({
                        title: "Subscription Successful",
                        description: "Thank you for subscribing!",
                      });
                      window.location.href = "/subscription-success";
                    }}
                  />
                  <p className="text-xs text-center text-muted-foreground mt-4">
                    You'll be charged ${selectedPlan.price.toFixed(2)} every {selectedPlan.interval}. You can cancel anytime.
                  </p>
                </div>
              </TabsContent>
              
              <TabsContent value="googlepay" className="space-y-4">
                <div className="bg-white dark:bg-gray-800 rounded-md p-4 border border-gray-200 dark:border-gray-700 shadow-sm">
                  <div className="mb-4 text-center">
                    <h3 className="font-medium mb-2">Subscribe with Google Pay</h3>
                    <p className="text-sm text-muted-foreground">Fast, secure subscription payment with Google Pay</p>
                  </div>
                  <GooglePayButton 
                    amount={selectedPlan.price.toString()}
                    onSuccess={() => {
                      toast({
                        title: "Subscription Successful",
                        description: "Thank you for subscribing!",
                      });
                      window.location.href = "/subscription-success";
                    }}
                  />
                  <p className="text-xs text-center text-muted-foreground mt-4">
                    You'll be charged ${selectedPlan.price.toFixed(2)} every {selectedPlan.interval}. You can cancel anytime.
                  </p>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        )}
        
        <div className="text-center mt-8">
          <Button 
            variant="ghost" 
            onClick={() => setShowPaymentForm(false)}
          >
            Back to Plan Selection
          </Button>
        </div>
      </div>
    </div>
  );
}