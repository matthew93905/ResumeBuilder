import { useState } from "react";
import { Helmet } from "react-helmet-async";
import { useAuth } from "@/hooks/use-auth";
import { 
  AlignLeft,
  CheckSquare,
  Download,
  FileText,
  Layout,
  RotateCcw,
  Save
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

// Template types
type CoverLetterTemplate = {
  id: string;
  name: string;
  description: string;
  isPremium: boolean;
  example: string;
};

// Sample templates
const templates: CoverLetterTemplate[] = [
  {
    id: "standard",
    name: "Standard Professional",
    description: "A traditional cover letter format suitable for most industries",
    isPremium: false,
    example: `Dear [Hiring Manager's Name],

I am writing to express my interest in the [Position] role at [Company Name]. With [X years] of experience in [relevant field/skill], I am confident in my ability to contribute effectively to your team.

In my previous role at [Previous Company], I [accomplished something significant, preferably with metrics]. Additionally, I [another achievement or responsibility relevant to the new role]. These experiences have equipped me with [relevant skills] that align perfectly with what you're seeking.

[Company Name] stands out to me because of [specific reason you're interested in the company - research required]. I am particularly excited about [specific project, company value, or aspect of the role] and am eager to contribute my expertise to further your mission.

Thank you for considering my application. I look forward to the opportunity to discuss how my background and skills would benefit [Company Name].

Sincerely,
[Your Name]`
  },
  {
    id: "modern",
    name: "Modern & Bold",
    description: "A contemporary approach with a stronger opening and closing",
    isPremium: false,
    example: `Dear [Hiring Manager's Name],

When I discovered the [Position] opening at [Company Name], I knew it was the perfect opportunity to combine my passion for [industry/field] with my expertise in [key skill area].

Throughout my career at [Previous Company], I've developed a strong track record of [key achievement with metrics]. My approach to [relevant skill] has consistently resulted in [positive outcome], which I believe would bring immediate value to your team.

What excites me most about [Company Name] is [specific aspect of company culture, project, or innovation]. Your commitment to [company value or mission] aligns perfectly with my professional values, and I'm eager to contribute to this vision.

I would welcome the opportunity to discuss how my background in [relevant experience] can help [Company Name] achieve its goals. Thank you for your consideration.

Ready to make an impact,
[Your Name]`
  },
  {
    id: "creative",
    name: "Creative & Narrative",
    description: "A storytelling approach that showcases personality",
    isPremium: true,
    example: `Dear [Hiring Manager's Name],

My journey with [relevant skill/industry] began when [brief personal story that connects to the role]. This experience sparked a passion that has defined my career and led me directly to the [Position] opportunity at [Company Name].

My professional narrative includes [key achievement] at [Previous Company], where I [specific contribution with measurable results]. Each role has added a new chapter to my story, equipping me with [relevant skills and experiences] that I'm excited to bring to your team.

[Company Name]'s recent [mention specific project, product, or achievement] particularly resonates with me because [personal connection]. I can clearly envision how my background in [relevant experience] would complement your team's innovative approach to [industry challenge or opportunity].

I'd love to continue this conversation and explore how our stories might converge. Thank you for considering my application.

Creatively yours,
[Your Name]`
  },
  {
    id: "executive",
    name: "Executive & Leadership",
    description: "Emphasizes strategic thinking and leadership capabilities",
    isPremium: true,
    example: `Dear [Hiring Manager's Name],

As a seasoned leader with a proven track record of [key leadership achievement], I am writing to express my interest in the [Position] role at [Company Name].

Throughout my career, I have consistently delivered [specific results, preferably with metrics] by focusing on [key leadership strength]. At [Previous Company], I led initiatives that resulted in [significant achievement], demonstrating my ability to [relevant skill for the new role].

My approach to leadership centers on [leadership philosophy], which aligns with [Company Name]'s reputation for [company strength or value]. I am particularly impressed by your organization's recent [mention specific company achievement or initiative], and I am confident that my strategic vision and execution capabilities would contribute significantly to your continued success.

I welcome the opportunity to discuss how my leadership experience and industry insights can support [Company Name]'s objectives. Thank you for your consideration.

Regards,
[Your Name]`
  }
];

export default function CoverLetterBuilder() {
  const { user } = useAuth();
  const isPremium = user?.isPremium || false;
  
  const [activeTemplate, setActiveTemplate] = useState<CoverLetterTemplate>(templates[0]);
  const [showPremiumDialog, setShowPremiumDialog] = useState(false);
  
  // Cover letter content state
  const [coverLetterData, setCoverLetterData] = useState({
    recipientName: "Hiring Manager",
    companyName: "Company Name",
    positionTitle: "Position Title",
    department: "",
    letterContent: templates[0].example,
    yourName: user?.fullName || user?.username || "Your Name",
    yourEmail: user?.email || "your.email@example.com",
    yourPhone: "555-555-5555",
    date: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }),
    includeSalutation: true,
    includeSignature: true,
    includeHeader: true
  });
  
  // Handle template selection
  const handleTemplateSelect = (templateId: string) => {
    const selected = templates.find(t => t.id === templateId);
    
    if (selected) {
      if (selected.isPremium && !isPremium) {
        setShowPremiumDialog(true);
        return;
      }
      
      setActiveTemplate(selected);
      setCoverLetterData(prev => ({
        ...prev,
        letterContent: selected.example
      }));
    }
  };
  
  // Handle form input changes
  const handleInputChange = (field: string, value: string | boolean) => {
    setCoverLetterData(prev => ({
      ...prev,
      [field]: value
    }));
  };
  
  // Reset to template default
  const resetToTemplate = () => {
    setCoverLetterData(prev => ({
      ...prev,
      letterContent: activeTemplate.example
    }));
  };
  
  // Generate final cover letter with replacements
  const generateFinalLetter = () => {
    let content = coverLetterData.letterContent;
    
    // Replace placeholders with actual values
    content = content.replace(/\[Hiring Manager's Name\]/g, coverLetterData.recipientName);
    content = content.replace(/\[Company Name\]/g, coverLetterData.companyName);
    content = content.replace(/\[Position\]/g, coverLetterData.positionTitle);
    content = content.replace(/\[Your Name\]/g, coverLetterData.yourName);
    
    // Construct the full letter with optional elements
    let fullLetter = "";
    
    if (coverLetterData.includeHeader) {
      fullLetter += `${coverLetterData.yourName}\n`;
      fullLetter += `${coverLetterData.yourEmail}\n`;
      if (coverLetterData.yourPhone) fullLetter += `${coverLetterData.yourPhone}\n`;
      fullLetter += `${coverLetterData.date}\n\n`;
    }
    
    if (coverLetterData.includeSalutation) {
      fullLetter += `Dear ${coverLetterData.recipientName},\n\n`;
    }
    
    fullLetter += content;
    
    if (!content.trim().endsWith(coverLetterData.yourName)) {
      if (coverLetterData.includeSignature) {
        fullLetter += `\n\nSincerely,\n${coverLetterData.yourName}`;
      }
    }
    
    return fullLetter;
  };
  
  return (
    <>
      <Helmet>
        <title>Cover Letter Builder | ResumeX</title>
        <meta name="description" content="Create professional cover letters that complement your resume. Choose from templates, customize your content, and download as PDF." />
        <meta name="keywords" content="cover letter, cover letter builder, job application, professional cover letter, letter templates" />
      </Helmet>
      
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold mb-3">Cover Letter Builder</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Create professional cover letters that complement your resume and make a strong impression
          </p>
        </div>
        
        <Tabs defaultValue="edit">
          <div className="flex justify-center mb-6">
            <TabsList>
              <TabsTrigger value="edit" className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                <span>Edit</span>
              </TabsTrigger>
              <TabsTrigger value="preview" className="flex items-center gap-2">
                <Layout className="h-4 w-4" />
                <span>Preview</span>
              </TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="edit" className="mt-0">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Left sidebar with templates */}
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Templates</CardTitle>
                    <CardDescription>Choose a template for your cover letter</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {templates.map(template => (
                      <div 
                        key={template.id}
                        className={`p-4 border rounded-lg cursor-pointer transition-all ${
                          activeTemplate.id === template.id ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50'
                        } ${template.isPremium && !isPremium ? 'opacity-70' : ''}`}
                        onClick={() => handleTemplateSelect(template.id)}
                      >
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="font-medium">{template.name}</h3>
                            <p className="text-sm text-muted-foreground">{template.description}</p>
                          </div>
                          {template.isPremium && (
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-300">
                              Premium
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Format Options</CardTitle>
                    <CardDescription>Customize your cover letter format</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="includeSalutation" className="cursor-pointer">Include Salutation</Label>
                      <Switch 
                        id="includeSalutation" 
                        checked={coverLetterData.includeSalutation}
                        onCheckedChange={(checked) => handleInputChange("includeSalutation", checked)}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="includeSignature" className="cursor-pointer">Include Signature</Label>
                      <Switch 
                        id="includeSignature" 
                        checked={coverLetterData.includeSignature}
                        onCheckedChange={(checked) => handleInputChange("includeSignature", checked)}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="includeHeader" className="cursor-pointer">Include Contact Header</Label>
                      <Switch 
                        id="includeHeader" 
                        checked={coverLetterData.includeHeader}
                        onCheckedChange={(checked) => handleInputChange("includeHeader", checked)}
                      />
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button 
                      variant="outline" 
                      className="w-full flex items-center gap-2"
                      onClick={resetToTemplate}
                    >
                      <RotateCcw className="h-4 w-4" />
                      Reset to Template
                    </Button>
                  </CardFooter>
                </Card>
              </div>
              
              {/* Main content editor */}
              <div className="lg:col-span-2 space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Letter Details</CardTitle>
                    <CardDescription>Enter the basic information for your cover letter</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="recipientName">Recipient Name</Label>
                        <Input 
                          id="recipientName"
                          value={coverLetterData.recipientName}
                          onChange={(e) => handleInputChange("recipientName", e.target.value)}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="companyName">Company Name</Label>
                        <Input 
                          id="companyName"
                          value={coverLetterData.companyName}
                          onChange={(e) => handleInputChange("companyName", e.target.value)}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="positionTitle">Position Title</Label>
                        <Input 
                          id="positionTitle"
                          value={coverLetterData.positionTitle}
                          onChange={(e) => handleInputChange("positionTitle", e.target.value)}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="department">Department (Optional)</Label>
                        <Input 
                          id="department"
                          value={coverLetterData.department}
                          onChange={(e) => handleInputChange("department", e.target.value)}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="yourName">Your Name</Label>
                        <Input 
                          id="yourName"
                          value={coverLetterData.yourName}
                          onChange={(e) => handleInputChange("yourName", e.target.value)}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="yourEmail">Your Email</Label>
                        <Input 
                          id="yourEmail"
                          type="email"
                          value={coverLetterData.yourEmail}
                          onChange={(e) => handleInputChange("yourEmail", e.target.value)}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="yourPhone">Your Phone</Label>
                        <Input 
                          id="yourPhone"
                          value={coverLetterData.yourPhone}
                          onChange={(e) => handleInputChange("yourPhone", e.target.value)}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="date">Date</Label>
                        <Input 
                          id="date"
                          value={coverLetterData.date}
                          onChange={(e) => handleInputChange("date", e.target.value)}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Letter Content</CardTitle>
                    <CardDescription>Edit your cover letter content</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Textarea 
                      className="min-h-[400px] font-mono text-sm"
                      value={coverLetterData.letterContent}
                      onChange={(e) => handleInputChange("letterContent", e.target.value)}
                    />
                  </CardContent>
                  <CardFooter className="flex flex-col sm:flex-row gap-4 sm:justify-between">
                    <Button variant="outline" className="w-full sm:w-auto flex items-center gap-2">
                      <AlignLeft className="h-4 w-4" />
                      AI Enhance
                      <span className="inline-flex items-center ml-1.5 py-0.5 px-1.5 rounded-full text-xs font-medium bg-primary/20 text-primary">
                        Premium
                      </span>
                    </Button>
                    
                    <div className="flex gap-2 w-full sm:w-auto">
                      <Button variant="secondary" className="flex-1 sm:flex-initial flex items-center gap-2">
                        <Save className="h-4 w-4" />
                        Save
                      </Button>
                      <Button className="flex-1 sm:flex-initial flex items-center gap-2">
                        <Download className="h-4 w-4" />
                        Export
                      </Button>
                    </div>
                  </CardFooter>
                </Card>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="preview" className="mt-0">
            <div className="bg-white border rounded-lg shadow-sm p-8 max-w-3xl mx-auto">
              <pre className="whitespace-pre-wrap font-sans text-base leading-relaxed">
                {generateFinalLetter()}
              </pre>
            </div>
            
            <div className="flex justify-center mt-6 gap-4">
              <Button variant="outline" className="flex items-center gap-2">
                <CheckSquare className="h-4 w-4" />
                Save Draft
              </Button>
              <Button className="flex items-center gap-2">
                <Download className="h-4 w-4" />
                Download PDF
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>
      
      {/* Premium feature dialog */}
      <Dialog open={showPremiumDialog} onOpenChange={setShowPremiumDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Premium Template</DialogTitle>
            <DialogDescription>
              This template is available exclusively for premium users.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <p className="mb-4">Upgrade to ResumeX Premium to unlock:</p>
            <ul className="space-y-2">
              <li className="flex items-start gap-2">
                <CheckSquare className="h-4 w-4 text-primary mt-1" />
                <span>All premium cover letter templates</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckSquare className="h-4 w-4 text-primary mt-1" />
                <span>AI-powered content enhancement</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckSquare className="h-4 w-4 text-primary mt-1" />
                <span>Unlimited cover letter exports</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckSquare className="h-4 w-4 text-primary mt-1" />
                <span>Premium resume templates</span>
              </li>
            </ul>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPremiumDialog(false)}>
              Maybe Later
            </Button>
            <Button>
              Upgrade to Premium
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}