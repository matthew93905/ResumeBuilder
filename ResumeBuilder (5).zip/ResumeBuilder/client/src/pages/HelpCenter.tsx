import { useState, useEffect, useMemo } from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import CanonicalUrl from "@/components/CanonicalUrl";
import FAQPageSchema from "@/components/FAQPageSchema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Search,
  FileText, 
  CreditCard, 
  Settings, 
  Users, 
  Download, 
  Shield, 
  Mail
} from "lucide-react";

// FAQ data organized by categories
const faqData = {
  "pricing": [
    {
      id: "pricing-1",
      question: "What plans does ResumeX offer?",
      answer: "ResumeX offers a free basic plan and a premium subscription at $14.99/month or $149/year that unlocks all premium templates, AI features, and unlimited exports."
    },
    {
      id: "pricing-2",
      question: "Can I cancel my premium subscription?",
      answer: "Yes, you can cancel your premium subscription at any time from your account settings. You'll continue to have access to premium features until the end of your billing period."
    },
    {
      id: "pricing-3",
      question: "Do you offer refunds?",
      answer: "We offer a 7-day money-back guarantee on new premium subscriptions. Please contact our support team at support@resumex.com for assistance."
    }
  ],
  "templates": [
    {
      id: "templates-1",
      question: "What resume templates are available?",
      answer: "We offer a variety of templates, including Essential, Executive, Creative, Minimalist, Modern, Visual Impact, Infographic, and Executive Plus. Some templates are available for free, while others are exclusive to premium users."
    },
    {
      id: "templates-2",
      question: "Can I customize the templates?",
      answer: "Yes, all our templates are fully customizable. You can change colors, fonts, layouts, and sections to match your preferences and needs."
    },
    {
      id: "templates-3",
      question: "Are the templates ATS-friendly?",
      answer: "Yes, all our resume templates are designed to be ATS (Applicant Tracking System) friendly. Premium users get access to an ATS compatibility checker to ensure their resume passes automated screening systems."
    }
  ],
  "account": [
    {
      id: "account-1",
      question: "How do I change my password?",
      answer: "You can change your password by going to your account settings after logging in. Look for the 'Security' section to update your password."
    },
    {
      id: "account-2",
      question: "Can I have multiple resumes in my account?",
      answer: "Yes, you can create and manage multiple resumes in your account. This allows you to tailor different resumes for different job applications."
    },
    {
      id: "account-3",
      question: "How do I delete my account?",
      answer: "To delete your account, go to your account settings and look for the 'Account' section. There you'll find an option to delete your account. Please note this action is irreversible."
    }
  ],
  "exporting": [
    {
      id: "exporting-1",
      question: "What file formats can I export my resume in?",
      answer: "You can export your resume as a PDF file. Premium users get access to additional export options like editable Word documents and plain text versions for ATS compatibility."
    },
    {
      id: "exporting-2",
      question: "How do I share my resume with potential employers?",
      answer: "You can share your resume by downloading it as a PDF and attaching it to job applications, or by using our shareable link feature that allows you to send a direct link to your online resume."
    },
    {
      id: "exporting-3",
      question: "Is there a limit to how many times I can download my resume?",
      answer: "Free users can download their resume up to 3 times per month. Premium users have unlimited downloads."
    }
  ],
  "collaboration": [
    {
      id: "collaboration-1",
      question: "How do I invite others to review my resume?",
      answer: "From your resume dashboard, select the resume you want to share, click on 'Collaborate', and enter the email addresses of the people you want to invite. They'll receive an invitation to view and comment on your resume."
    },
    {
      id: "collaboration-2",
      question: "Can collaborators edit my resume?",
      answer: "Yes, you can grant different permission levels to collaborators. 'Viewers' can only view and comment, while 'Editors' can make direct changes to your resume."
    },
    {
      id: "collaboration-3",
      question: "How do I see comments from collaborators?",
      answer: "When viewing your resume in the builder, a comments panel will be visible if there are any comments. You can also see all comments by clicking on the 'Comments' tab in the collaboration section."
    }
  ],
  "ai-features": [
    {
      id: "ai-1",
      question: "What AI features does ResumeX offer?",
      answer: "Our AI features include resume content enhancement, job description analysis, career path recommendations, and skill suggestions based on your target role."
    },
    {
      id: "ai-2",
      question: "How accurate are the AI career recommendations?",
      answer: "Our AI recommendations are based on current industry data and trends. While they provide valuable insights, we recommend using them as guidance along with your own research and networking."
    },
    {
      id: "ai-3",
      question: "Can the AI write my entire resume?",
      answer: "Our AI can enhance and improve your existing content, but we believe the best resumes combine your authentic experiences with AI-powered optimization. Start with your own content, then use our AI tools to refine and improve it."
    }
  ],
  "privacy": [
    {
      id: "privacy-1",
      question: "How is my resume data secured?",
      answer: "We take your privacy seriously. We never share your personal information with third parties. Your resume data is stored securely and only accessible to you and any collaborators you explicitly invite."
    },
    {
      id: "privacy-2",
      question: "Can ResumeX see my resume content?",
      answer: "Our systems may analyze your resume content to provide AI-powered suggestions, but our staff cannot access your personal information unless you explicitly request support that requires reviewing your resume."
    },
    {
      id: "privacy-3",
      question: "Is my payment information secure?",
      answer: "Yes, we use industry-standard encryption and secure payment processors (Stripe and PayPal). We never store your full credit card details on our servers."
    }
  ]
};

// All FAQ categories
const categories = [
  { id: "pricing", label: "Pricing & Billing", icon: <CreditCard className="h-4 w-4" /> },
  { id: "templates", label: "Templates", icon: <FileText className="h-4 w-4" /> },
  { id: "account", label: "Account Settings", icon: <Settings className="h-4 w-4" /> },
  { id: "exporting", label: "Exporting & Sharing", icon: <Download className="h-4 w-4" /> },
  { id: "collaboration", label: "Collaboration", icon: <Users className="h-4 w-4" /> },
  { id: "ai-features", label: "AI Features", icon: <Shield className="h-4 w-4" /> },
  { id: "privacy", label: "Privacy & Security", icon: <Shield className="h-4 w-4" /> }
];

export default function HelpCenter() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");
  const [expandedItems, setExpandedItems] = useState<string[]>([]);
  
  // Add custom SEO for the Help Center page
  useEffect(() => {
    // Dynamically expand FAQ items based on URL hash
    if (window.location.hash) {
      const faqId = window.location.hash.substring(1);
      setExpandedItems(prev => [...prev, faqId]);
      
      // Scroll to the FAQ item
      setTimeout(() => {
        const element = document.getElementById(faqId);
        if (element) {
          element.scrollIntoView({ behavior: "smooth", block: "center" });
        }
      }, 500);
    }
  }, []);

  // Filter FAQs based on search query and active category
  const filteredFaqs = Object.entries(faqData)
    .filter(([category]) => activeCategory === "all" || category === activeCategory)
    .flatMap(([_, questions]) => 
      questions.filter(item => 
        item.question.toLowerCase().includes(searchQuery.toLowerCase()) || 
        item.answer.toLowerCase().includes(searchQuery.toLowerCase())
      )
    );
    
  // Create a flattened array of all FAQs for schema markup
  const allFaqs = useMemo(() => {
    return Object.values(faqData).flat();
  }, []);

  return (
    <div className="container max-w-6xl py-12 px-4 sm:px-6 lg:px-8">
      <CanonicalUrl />
      <FAQPageSchema faqs={allFaqs} />
      <div className="text-center mb-10">
        <h1 className="text-4xl font-extrabold tracking-tight lg:text-5xl text-primary mb-4">
          Help Center
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Find answers to common questions about using ResumeX to create professional resumes
        </p>
      </div>

      {/* Search box */}
      <div className="relative max-w-2xl mx-auto mb-10">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-5 w-5" />
          <Input
            type="text"
            placeholder="Search for answers..."
            className="pl-10 py-6 text-lg"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {/* Category tabs */}
      <div className="flex flex-wrap gap-2 justify-center mb-8">
        <Button
          variant={activeCategory === "all" ? "default" : "outline"}
          onClick={() => setActiveCategory("all")}
          className="mb-2"
        >
          All Topics
        </Button>
        
        {categories.map((category) => (
          <Button
            key={category.id}
            variant={activeCategory === category.id ? "default" : "outline"}
            onClick={() => setActiveCategory(category.id)}
            className="mb-2"
          >
            <span className="mr-2">{category.icon}</span>
            {category.label}
          </Button>
        ))}
      </div>

      {/* Search results count */}
      {searchQuery && (
        <div className="text-center mb-6">
          <Badge variant="outline" className="px-3 py-1 text-sm">
            {filteredFaqs.length} {filteredFaqs.length === 1 ? 'result' : 'results'} for "{searchQuery}"
          </Badge>
        </div>
      )}

      {/* FAQ accordion */}
      <div className="max-w-3xl mx-auto">
        {filteredFaqs.length > 0 ? (
          <Accordion type="multiple" value={expandedItems} onValueChange={setExpandedItems} className="space-y-4">
            {filteredFaqs.map((faq) => (
              <AccordionItem 
                key={faq.id} 
                value={faq.id}
                className="border rounded-lg px-1 shadow-sm"
              >
                <AccordionTrigger className="px-4 py-4 hover:no-underline text-left">
                  <span className="text-lg font-medium">{faq.question}</span>
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-4 pt-1 text-muted-foreground">
                  <p className="whitespace-pre-line">{faq.answer}</p>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        ) : (
          <div className="text-center py-12">
            <p className="text-lg text-muted-foreground mb-6">No results found for your search.</p>
            <p className="mb-6">Try adjusting your search terms or browse by category.</p>
            <div className="flex justify-center">
              <Button variant="outline" onClick={() => setSearchQuery("")}>
                Clear search
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Contact support */}
      <div className="mt-16 max-w-xl mx-auto text-center border rounded-xl p-8 bg-muted/50">
        <h2 className="text-2xl font-bold mb-4">Still need help?</h2>
        <p className="text-muted-foreground mb-6">
          Can't find what you're looking for? Our support team is here to help.
        </p>
        <Button className="gap-2">
          <Mail className="h-4 w-4" />
          Contact Support
        </Button>
      </div>
    </div>
  );
}