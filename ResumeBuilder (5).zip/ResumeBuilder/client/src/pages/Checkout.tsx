import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { loadStripe } from "@stripe/stripe-js";
import {
  Elements,
  PaymentElement,
  useStripe,
  useElements
} from "@stripe/react-stripe-js";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Loader2, CreditCard } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PayPalButton from "@/components/PayPalButton";
import GooglePayButton from "@/components/GooglePayButton";

// Load Stripe outside of component to avoid recreating on renders
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

// Checkout form component that uses Stripe Elements
function CheckoutForm({ productName, amount }: { productName: string; amount: number }) {
  const stripe = useStripe();
  const elements = useElements();
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [location, navigate] = useLocation();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);
    setErrorMessage(null);

    // Confirm payment with Stripe
    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: window.location.origin + "/checkout-success",
      },
    });

    if (error) {
      setErrorMessage(error.message || "An error occurred during payment.");
      toast({
        title: "Payment Failed",
        description: error.message || "An error occurred during payment.",
        variant: "destructive"
      });
      setIsProcessing(false);
    }
    // Payment is handled by redirect, so we don't need to handle success here
  };

  return (
    <div className="max-w-md w-full mx-auto bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-border">
      <div className="mb-6 text-center">
        <h2 className="text-xl font-bold mb-2">Purchase {productName}</h2>
        <p className="text-muted-foreground">Unlock premium features for your resume</p>
      </div>
      
      <div className="mb-8">
        <div className="flex justify-between py-3 border-b border-border">
          <span>Product</span>
          <span className="font-medium">{productName}</span>
        </div>
        <div className="flex justify-between py-3 border-b border-border">
          <span>Price</span>
          <span className="font-medium">${amount.toFixed(2)}</span>
        </div>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <PaymentElement />
        
        {errorMessage && <div className="text-red-500 text-sm">{errorMessage}</div>}
        
        <Button 
          type="submit" 
          disabled={!stripe || isProcessing}
          className="w-full bg-gradient-to-r from-secondary to-primary"
        >
          {isProcessing ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Processing...
            </>
          ) : (
            `Pay $${amount.toFixed(2)}`
          )}
        </Button>
      </form>
    </div>
  );
}

// Main Checkout page that sets up Stripe Elements
export default function Checkout() {
  const [clientSecret, setClientSecret] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [productData, setProductData] = useState({ name: "Premium Template", amount: 9.99 });
  const { toast } = useToast();
  
  useEffect(() => {
    // Create a PaymentIntent on component mount
    const fetchPaymentIntent = async () => {
      try {
        const response = await apiRequest("POST", "/api/create-payment-intent", {
          amount: productData.amount
        });
        
        if (!response.ok) {
          throw new Error("Failed to create payment intent");
        }
        
        const data = await response.json();
        setClientSecret(data.clientSecret);
      } catch (error) {
        console.error("Error creating payment intent:", error);
        toast({
          title: "Error",
          description: "Failed to initialize payment. Please try again.",
          variant: "destructive"
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchPaymentIntent();
  }, [productData.amount, toast]);
  
  // Show loading state while payment intent is being created
  if (isLoading || !clientSecret) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4">
        <div className="flex flex-col items-center space-y-4">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
          <p className="text-lg text-muted-foreground">Preparing checkout...</p>
        </div>
      </div>
    );
  }
  
  // Handle PayPal payment success
  const handlePayPalSuccess = (data: any) => {
    toast({
      title: "Payment Successful",
      description: "Thank you for your purchase!",
    });
    window.location.href = "/checkout-success";
  };

  // Handle Google Pay payment success
  const handleGooglePaySuccess = (paymentData: any) => {
    toast({
      title: "Payment Successful",
      description: "Thank you for your purchase!",
    });
    window.location.href = "/checkout-success";
  };

  // Render payment options when client secret is available
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-accent/20">
      <div className="w-full max-w-4xl">
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold mb-2">Checkout</h1>
          <p className="text-muted-foreground">Complete your payment to access premium features</p>
        </div>
        
        <div className="max-w-md w-full mx-auto bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-border">
          <div className="mb-6 text-center">
            <h2 className="text-xl font-bold mb-2">Purchase {productData.name}</h2>
            <p className="text-muted-foreground">Unlock premium features for your resume</p>
          </div>
          
          <div className="mb-8">
            <div className="flex justify-between py-3 border-b border-border">
              <span>Product</span>
              <span className="font-medium">{productData.name}</span>
            </div>
            <div className="flex justify-between py-3 border-b border-border">
              <span>Price</span>
              <span className="font-medium">${productData.amount.toFixed(2)}</span>
            </div>
          </div>
          
          <Tabs defaultValue="card" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-4">
              <TabsTrigger value="card" className="flex items-center gap-2">
                <CreditCard className="h-4 w-4" />
                <span>Card</span>
              </TabsTrigger>
              <TabsTrigger value="paypal">
                <span>PayPal</span>
              </TabsTrigger>
              <TabsTrigger value="googlepay">
                <span>Google Pay</span>
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="card" className="space-y-4">
              <div className="bg-white dark:bg-gray-800 rounded-md p-4 border border-gray-200 dark:border-gray-700 shadow-sm">
                <div className="mb-4 text-center">
                  <h3 className="font-medium mb-2">Complete your purchase with Credit Card</h3>
                  <p className="text-sm text-muted-foreground">Secure payment with credit or debit card</p>
                </div>
                <Elements stripe={stripePromise} options={{ clientSecret }}>
                  <form onSubmit={(e) => {
                    e.preventDefault();
                    const stripeForm = document.querySelector('form[data-stripe-form]');
                    if (stripeForm) {
                      (stripeForm as HTMLFormElement).requestSubmit();
                    }
                  }}>
                    <div className="mb-6">
                      <PaymentElement />
                    </div>
                    <Button 
                      type="submit" 
                      className="w-full bg-gradient-to-r from-secondary to-primary"
                    >
                      Pay with Card ${productData.amount.toFixed(2)}
                    </Button>
                  </form>
                </Elements>
              </div>
            </TabsContent>
            
            <TabsContent value="paypal" className="space-y-4">
              <div className="bg-white dark:bg-gray-800 rounded-md p-4 border border-gray-200 dark:border-gray-700 shadow-sm">
                <div className="mb-4 text-center">
                  <h3 className="font-medium mb-2">Complete your purchase with PayPal</h3>
                  <p className="text-sm text-muted-foreground">Fast, secure checkout with PayPal</p>
                </div>
                <PayPalButton 
                  amount={productData.amount.toString()} 
                  currency="USD" 
                  intent="CAPTURE"
                  onSuccess={handlePayPalSuccess}
                />
              </div>
            </TabsContent>
            
            <TabsContent value="googlepay" className="space-y-4">
              <div className="bg-white dark:bg-gray-800 rounded-md p-4 border border-gray-200 dark:border-gray-700 shadow-sm">
                <div className="mb-4 text-center">
                  <h3 className="font-medium mb-2">Complete your purchase with Google Pay</h3>
                  <p className="text-sm text-muted-foreground">Fast, secure checkout with Google Pay</p>
                </div>
                <GooglePayButton 
                  amount={productData.amount.toString()}
                  onSuccess={handleGooglePaySuccess}
                />
              </div>
            </TabsContent>
          </Tabs>
        </div>
        
        <div className="text-center mt-8 text-sm text-muted-foreground">
          <p>Your payment is processed securely through your chosen payment method.</p>
          <p>Multiple payment options available: Credit Card, PayPal, and Google Pay.</p>
          <p>You will receive access to premium features immediately after payment.</p>
        </div>
      </div>
    </div>
  );
}