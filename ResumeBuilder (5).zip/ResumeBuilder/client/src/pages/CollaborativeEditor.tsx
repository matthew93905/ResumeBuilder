import React, { useState } from 'react';
import { useParams, Redirect, useLocation } from 'wouter';
import { useResume } from '@/hooks/use-resume';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { Helmet } from 'react-helmet-async';
import { 
  ResizablePanelGroup,
  ResizablePanel,
  ResizableHandle,
} from '@/components/ui/resizable';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import CollaborationPanel from '@/components/collaboration/CollaborationPanel';
import CommentsPanel from '@/components/collaboration/CommentsPanel';
import { CollaborationStatus } from '@/components/collaboration/CollaborationStatus';
import { WebSocketProvider } from '@/hooks/use-websocket';
import {
  Save,
  Users,
  MessageSquare,
  Share2,
  Download,
  History,
  UserPlus
} from 'lucide-react';
import { exportResumeToPdf } from '@/lib/pdfUtils';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';

export default function CollaborativeEditor() {
  const { id } = useParams<{ id: string }>();
  const resumeId = id ? parseInt(id) : null;
  const [, navigate] = useLocation();
  const { user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  
  // UI state
  const [showCollabPanel, setShowCollabPanel] = useState(false);
  const [showCommentsPanel, setShowCommentsPanel] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  
  // Get resume data from context
  const resumeContext = useResume();
  const { resumeData } = resumeContext;
  
  // Helper for avatar initials
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };
  
  const handleSave = async () => {
    try {
      setIsSaving(true);
      // Save implementation would go here
      // We'd implement this with a proper backend API call
      toast({
        title: 'Resume saved',
        description: 'All changes have been saved',
      });
    } catch (error: any) {
      toast({
        title: 'Error saving resume',
        description: error?.message || 'Failed to save changes',
        variant: 'destructive',
      });
    } finally {
      setIsSaving(false);
    }
  };
  
  const handleExport = async () => {
    try {
      setIsExporting(true);
      await exportResumeToPdf(resumeData, 'resume');
      toast({
        title: 'Resume exported',
        description: 'Your resume has been downloaded as a PDF',
      });
    } catch (error: any) {
      toast({
        title: 'Export failed',
        description: error?.message || 'Failed to export resume',
        variant: 'destructive',
      });
    } finally {
      setIsExporting(false);
    }
  };
  
  // Redirect if not authenticated
  if (!authLoading && !user) {
    return <Redirect to="/auth" />;
  }
  
  // Loading state
  if (authLoading) {
    return (
      <div className="container max-w-7xl py-6">
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <Skeleton className="h-10 w-64" />
            <div className="flex gap-2">
              <Skeleton className="h-10 w-24" />
              <Skeleton className="h-10 w-24" />
            </div>
          </div>
          <Skeleton className="h-[600px] w-full" />
        </div>
      </div>
    );
  }
  
  return (
    <WebSocketProvider resumeId={resumeId}>
      <div className="min-h-screen flex flex-col">
        <Helmet>
          <title>Collaborative Resume Editor | ResumeX</title>
        </Helmet>
        
        {/* Header with editing toolbar */}
        <header className="border-b sticky top-0 z-10 bg-background">
          <div className="container py-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Input 
                  value="Untitled Resume" 
                  className="font-semibold text-lg h-10 w-64"
                />
                
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={handleSave}
                    disabled={isSaving}
                  >
                    {isSaving ? (
                      <>
                        <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-background border-t-transparent" />
                        <span>Saving...</span>
                      </>
                    ) : (
                      <>
                        <Save className="mr-2 h-4 w-4" />
                        <span>Save</span>
                      </>
                    )}
                  </Button>
                  
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-9 w-9">
                          <History className="h-5 w-5" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Version History</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                {/* Collaboration status */}
                <CollaborationStatus />
                
                <Separator orientation="vertical" className="h-8" />
                
                {/* Collaborators placeholder */}
                <div className="flex -space-x-2 mr-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => setShowCollabPanel(true)}
                  >
                    <UserPlus className="mr-2 h-4 w-4" />
                    <span>Invite</span>
                  </Button>
                </div>
                
                <Separator orientation="vertical" className="h-8" />
                
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button 
                        variant={showCollabPanel ? "default" : "ghost"} 
                        size="icon" 
                        className="h-9 w-9"
                        onClick={() => {
                          setShowCollabPanel(!showCollabPanel);
                          if (showCommentsPanel && !showCollabPanel) {
                            setShowCommentsPanel(false);
                          }
                        }}
                      >
                        <Users className="h-5 w-5" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Collaboration</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
                
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button 
                        variant={showCommentsPanel ? "default" : "ghost"} 
                        size="icon" 
                        className="h-9 w-9"
                        onClick={() => {
                          setShowCommentsPanel(!showCommentsPanel);
                          if (showCollabPanel && !showCommentsPanel) {
                            setShowCollabPanel(false);
                          }
                        }}
                      >
                        <MessageSquare className="h-5 w-5" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Comments</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
                
                <Separator orientation="vertical" className="h-8" />
                
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-9 w-9"
                        onClick={() => {
                          // Share functionality
                          toast({
                            title: "Share link copied",
                            description: "The link has been copied to your clipboard"
                          });
                        }}
                      >
                        <Share2 className="h-5 w-5" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Share</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
                
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="gap-1"
                  onClick={handleExport}
                  disabled={isExporting}
                >
                  {isExporting ? (
                    <>
                      <div className="mr-1 h-4 w-4 animate-spin rounded-full border-2 border-background border-t-transparent" />
                      <span>Exporting...</span>
                    </>
                  ) : (
                    <>
                      <Download className="h-4 w-4" />
                      <span>Export PDF</span>
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>
        </header>
        
        {/* Main content */}
        <div className="flex-1 overflow-hidden">
          <ResizablePanelGroup direction="horizontal">
            {/* Main editor panel */}
            <ResizablePanel defaultSize={showCollabPanel || showCommentsPanel ? 70 : 100}>
              <div className="container py-6">
                {/* Resume editor content goes here */}
                <div className="bg-muted border rounded-lg p-8 flex items-center justify-center h-[600px]">
                  <div className="text-center">
                    <h2 className="text-lg font-medium mb-2">Resume Editor Placeholder</h2>
                    <p className="text-muted-foreground">Resume editing interface will be displayed here</p>
                  </div>
                </div>
              </div>
            </ResizablePanel>
            
            {/* Resizable handle */}
            {(showCollabPanel || showCommentsPanel) && (
              <ResizableHandle withHandle />
            )}
            
            {/* Collaboration panels */}
            {(showCollabPanel || showCommentsPanel) && (
              <ResizablePanel defaultSize={30}>
                <div className="p-6 h-full overflow-y-auto">
                  {showCollabPanel && (
                    <CollaborationPanel resumeId={resumeId} />
                  )}
                  
                  {showCommentsPanel && (
                    <CommentsPanel resumeId={resumeId} />
                  )}
                </div>
              </ResizablePanel>
            )}
          </ResizablePanelGroup>
        </div>
      </div>
    </WebSocketProvider>
  );
}