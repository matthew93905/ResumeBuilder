import { useEffect, useState } from "react";
import { Helmet } from "react-helmet-async";
import { useRoute, Link } from "wouter";
import { 
  ArrowLeft, 
  Calendar, 
  Clock, 
  Facebook, 
  Linkedin, 
  Twitter,
  Tag as TagIcon 
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

// Blog post type definition
interface BlogPost {
  id: number;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  category: string;
  tags: string[];
  author: string;
  authorTitle: string;
  authorImage: string;
  date: string;
  readTime: string;
  imageUrl: string;
}

// Sample blog post data with content
const blogPosts: BlogPost[] = [
  {
    id: 1,
    title: "10 Resume Mistakes That Could Cost You the Job",
    slug: "resume-mistakes",
    excerpt: "Discover the common resume mistakes that recruiters flag as immediate disqualifiers and learn how to avoid them to improve your chances of landing an interview.",
    content: `
      <p>Your resume is often the first impression you make on potential employers, and in a competitive job market, even small mistakes can cost you an interview opportunity. According to a survey of hiring managers, the average resume is scanned for just 7.4 seconds before a decision is made to keep or discard it.</p>
      
      <p>In this article, we'll explore the 10 most common resume mistakes that could be hurting your job search, and provide actionable tips to fix them.</p>
      
      <h2>1. Generic, One-Size-Fits-All Resumes</h2>
      
      <p>One of the biggest mistakes job seekers make is using the same resume for every application. Each job has unique requirements, and your resume should be tailored to highlight the skills and experiences that match what the employer is looking for.</p>
      
      <p><strong>Fix it:</strong> Carefully read the job description and customize your resume for each position. Highlight relevant experiences and use similar language to what appears in the job posting.</p>
      
      <h2>2. Typos and Grammatical Errors</h2>
      
      <p>In a survey of hiring managers, 77% said they would immediately disqualify a candidate because of spelling errors or typos on their resume. These mistakes signal carelessness and a lack of attention to detail.</p>
      
      <p><strong>Fix it:</strong> Proofread your resume multiple times, use spell check, and have at least one other person review it before submission.</p>
      
      <h2>3. Including Irrelevant Information</h2>
      
      <p>Adding information that doesn't relate to the position you're applying for wastes valuable space and can distract from your relevant qualifications.</p>
      
      <p><strong>Fix it:</strong> Focus on experiences, skills, and achievements that directly relate to the job requirements.</p>
      
      <h2>4. Focusing on Job Duties Instead of Achievements</h2>
      
      <p>Listing job responsibilities without showcasing your accomplishments makes your resume blend in with others. Employers want to see what you achieved, not just what you were responsible for.</p>
      
      <p><strong>Fix it:</strong> Use metrics and specific examples to quantify your achievements. For example, instead of "Responsible for sales," write "Increased quarterly sales by 15% through implementation of new client outreach strategies."</p>
      
      <h2>5. Poor Formatting and Design</h2>
      
      <p>A cluttered, disorganized resume with inconsistent formatting makes it difficult for hiring managers to find the information they need quickly.</p>
      
      <p><strong>Fix it:</strong> Use a clean, professional template with consistent formatting. Ensure adequate white space, use bullet points for readability, and stick to standard fonts like Arial or Calibri.</p>
      
      <h2>6. Including an Objective Statement Instead of a Professional Summary</h2>
      
      <p>Traditional objective statements focus on what you want rather than what you offer to the employer, which doesn't add value to your application.</p>
      
      <p><strong>Fix it:</strong> Replace objective statements with a professional summary that highlights your most relevant qualifications and what you bring to the organization.</p>
      
      <h2>7. Being Too Modest</h2>
      
      <p>Many candidates, especially women, tend to undersell their achievements. Your resume is not the place for modesty.</p>
      
      <p><strong>Fix it:</strong> Take credit for your accomplishments and use strong action verbs to describe them. Don't minimize your contributions to team projects.</p>
      
      <h2>8. Including References or "References Available Upon Request"</h2>
      
      <p>Including references on your resume or stating that "references are available upon request" takes up valuable space and is unnecessary.</p>
      
      <p><strong>Fix it:</strong> Prepare a separate reference list to provide when requested, and use the extra space on your resume to highlight additional qualifications.</p>
      
      <h2>9. Not Addressing Employment Gaps</h2>
      
      <p>Unexplained gaps in employment can raise red flags for hiring managers.</p>
      
      <p><strong>Fix it:</strong> If you have significant gaps, consider using a functional resume format or briefly explain gaps in your cover letter. If you used time away from traditional employment to volunteer, freelance, or learn new skills, include this information.</p>
      
      <h2>10. Not Optimizing for ATS</h2>
      
      <p>Most large companies use Applicant Tracking Systems (ATS) to scan and filter resumes before they reach human reviewers. If your resume isn't optimized for these systems, it might never be seen by a hiring manager.</p>
      
      <p><strong>Fix it:</strong> Use industry-standard section headings, incorporate keywords from the job description, and avoid using tables, headers/footers, or images that ATS might not be able to parse properly.</p>
      
      <h2>Final Thoughts</h2>
      
      <p>Your resume is a marketing tool designed to showcase your qualifications and secure an interview. By avoiding these common mistakes, you'll create a more compelling document that effectively communicates your value to potential employers.</p>
      
      <p>Remember, the goal of your resume is not to get you a job—it's to get you an interview. Make every word count and focus on making your qualifications clear, relevant, and impressive.</p>
    `,
    category: "Resume Tips",
    tags: ["resume", "mistakes", "job search"],
    author: "Emma Johnson",
    authorTitle: "Senior Career Advisor",
    authorImage: "https://randomuser.me/api/portraits/women/45.jpg",
    date: "May 2, 2025",
    readTime: "6 min read",
    imageUrl: "https://images.unsplash.com/photo-1586281380349-632531db7ed4?q=80&w=1200&auto=format&fit=crop"
  },
  {
    id: 2,
    title: "How to Optimize Your LinkedIn Profile to Complement Your Resume",
    slug: "linkedin-optimization",
    excerpt: "Learn how to create a consistent personal brand across your resume and LinkedIn profile, and discover strategies to leverage LinkedIn for networking and job opportunities.",
    content: `
      <p>In today's digital job market, your LinkedIn profile is as important as your resume—sometimes even more so. While a resume is typically tailored for specific job applications, your LinkedIn profile serves as your professional presence online, visible to recruiters, potential employers, and networking contacts around the clock.</p>
      
      <p>Creating a LinkedIn profile that complements and enhances your resume can significantly boost your job search efforts. Here's a comprehensive guide to optimizing your LinkedIn profile to work in tandem with your resume.</p>
      
      <h2>Why LinkedIn and Your Resume Should Work Together</h2>
      
      <p>Before diving into specific optimization strategies, it's important to understand why the relationship between your LinkedIn profile and resume matters:</p>
      
      <ul>
        <li><strong>Verification:</strong> Recruiters often check LinkedIn to verify resume information</li>
        <li><strong>Expanded Information:</strong> LinkedIn allows you to provide more detail than a typical 1-2 page resume</li>
        <li><strong>Social Proof:</strong> Recommendations and endorsements on LinkedIn validate your skills and experiences</li>
        <li><strong>Active Demonstration:</strong> Sharing industry content and participating in discussions demonstrates knowledge in a way a resume cannot</li>
      </ul>
      
      <h2>Creating a Cohesive Personal Brand</h2>
      
      <p>Your LinkedIn profile and resume should tell the same story, even if they don't contain identical information. Here's how to ensure consistency:</p>
      
      <h3>Professional Photo</h3>
      
      <p>Unlike your resume, LinkedIn requires a profile photo. Choose a high-quality, professional headshot where you're dressed appropriately for your industry. Studies show that profiles with professional photos receive 14 times more views than those without.</p>
      
      <h3>Headline and Summary</h3>
      
      <p>Your LinkedIn headline (the text under your name) should be more than just your current job title. Use this space (120 characters) to highlight your specialization and value proposition.</p>
      
      <p>Example: "Financial Analyst | Data Visualization Expert | Turning Complex Financial Data into Strategic Business Insights"</p>
      
      <p>Your summary should expand on your resume's professional summary but with a more conversational tone. Include your key qualifications, professional philosophy, and what you're passionate about in your field.</p>
      
      <h3>Experience Section</h3>
      
      <p>While your resume might focus on accomplishments with bullet points, LinkedIn gives you space to tell more of the story:</p>
      
      <ul>
        <li>Include all positions from your resume, with consistent job titles and dates</li>
        <li>Add brief company descriptions for context</li>
        <li>Begin with a paragraph about your role and responsibilities</li>
        <li>Follow with bullet points highlighting key achievements (similar to your resume)</li>
        <li>Include media such as presentations, publications, or projects where relevant</li>
      </ul>
      
      <h2>Leveraging LinkedIn-Specific Features</h2>
      
      <p>LinkedIn offers several features that resumes don't. Take advantage of these to create a more dynamic professional profile:</p>
      
      <h3>Skills and Endorsements</h3>
      
      <p>Add up to 50 skills that align with those mentioned in your resume. Prioritize the top 3 skills you want to be endorsed for, as these appear most prominently. Don't be afraid to directly ask colleagues and managers for specific endorsements.</p>
      
      <h3>Recommendations</h3>
      
      <p>Recommendations provide social proof of your abilities. Request recommendations from supervisors, colleagues, clients, or professors who can speak to different aspects of your professional capabilities. When requesting recommendations, suggest specific projects or skills they might mention to ensure relevance.</p>
      
      <h3>Accomplishments Section</h3>
      
      <p>Expand your professional story by adding:</p>
      
      <ul>
        <li>Publications</li>
        <li>Patents</li>
        <li>Courses</li>
        <li>Projects</li>
        <li>Honors & Awards</li>
        <li>Languages</li>
        <li>Organizations</li>
      </ul>
      
      <p>Many of these might be mentioned briefly on your resume but can be elaborated on in LinkedIn.</p>
      
      <h2>Activity and Engagement</h2>
      
      <p>Unlike your static resume, LinkedIn allows you to demonstrate your professional knowledge and engagement:</p>
      
      <ul>
        <li>Share relevant industry articles with your thoughtful commentary</li>
        <li>Write original posts or articles related to your expertise</li>
        <li>Engage meaningfully with content from your network</li>
        <li>Participate in relevant groups in your industry</li>
      </ul>
      
      <p>Regular, quality engagement positions you as an active participant in your field, something no resume can accomplish.</p>
      
      <h2>LinkedIn for Networking</h2>
      
      <p>Beyond serving as an online resume, LinkedIn is primarily a networking platform. Use it strategically to expand your professional connections:</p>
      
      <ul>
        <li>Connect with colleagues, classmates, and industry peers</li>
        <li>Follow companies you're interested in working for</li>
        <li>Engage with content from potential employers</li>
        <li>Participate in industry conversations through comments and posts</li>
        <li>Reach out to people for informational interviews (with a personalized message)</li>
      </ul>
      
      <h2>Final Tips for LinkedIn Optimization</h2>
      
      <ul>
        <li><strong>Customize your URL:</strong> Create a custom LinkedIn URL with your name for a more professional look and easier sharing</li>
        <li><strong>Add a background image:</strong> Choose a professional banner image related to your industry</li>
        <li><strong>Check your settings:</strong> Ensure your profile is fully visible to recruiters</li>
        <li><strong>Keep it updated:</strong> Regularly refresh your profile with new accomplishments, skills, and experiences</li>
        <li><strong>Use keywords strategically:</strong> Incorporate industry-specific keywords throughout your profile to improve searchability</li>
      </ul>
      
      <h2>Conclusion</h2>
      
      <p>Your LinkedIn profile and resume should work together as complementary tools in your job search strategy. While they should tell a consistent story about your professional background, each has unique advantages. Your resume allows for customization for specific opportunities, while LinkedIn offers expanded information, social proof, and active engagement opportunities.</p>
      
      <p>By thoughtfully optimizing both, you'll present a cohesive, compelling professional narrative that resonates with recruiters and potential employers.</p>
    `,
    category: "LinkedIn",
    tags: ["linkedin", "personal branding", "networking"],
    author: "Michael Chen",
    authorTitle: "Digital Branding Strategist",
    authorImage: "https://randomuser.me/api/portraits/men/32.jpg",
    date: "April 28, 2025",
    readTime: "8 min read",
    imageUrl: "https://images.unsplash.com/photo-1611944212129-29977ae1398c?q=80&w=1200&auto=format&fit=crop"
  }
];

export default function BlogPost() {
  const [, params] = useRoute("/blog/:slug");
  const [post, setPost] = useState<BlogPost | null>(null);
  const [loading, setLoading] = useState(true);
  const slug = params?.slug;

  useEffect(() => {
    // Simulate fetching a post
    setLoading(true);
    const foundPost = blogPosts.find(p => p.slug === slug);
    setPost(foundPost || null);
    setLoading(false);
  }, [slug]);

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-16 max-w-4xl text-center">
        <div className="animate-pulse">
          <div className="h-8 bg-muted rounded w-3/4 mx-auto mb-8"></div>
          <div className="h-64 bg-muted rounded mb-8"></div>
          <div className="space-y-4">
            <div className="h-4 bg-muted rounded"></div>
            <div className="h-4 bg-muted rounded"></div>
            <div className="h-4 bg-muted rounded"></div>
            <div className="h-4 bg-muted rounded w-5/6"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="container mx-auto px-4 py-16 max-w-4xl text-center">
        <h1 className="text-3xl font-bold mb-4">Article Not Found</h1>
        <p className="text-muted-foreground mb-8">The article you're looking for doesn't exist or has been moved.</p>
        <Link href="/blog">
          <Button>Back to Blog</Button>
        </Link>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>{post.title} | ResumeX Blog</title>
        <meta name="description" content={post.excerpt} />
        <meta name="keywords" content={post.tags.join(', ')} />
        <meta property="og:title" content={post.title} />
        <meta property="og:description" content={post.excerpt} />
        <meta property="og:image" content={post.imageUrl} />
        <meta property="og:type" content="article" />
        <meta property="article:published_time" content="2025-05-02" />
        <meta property="article:author" content={post.author} />
        <meta property="article:section" content={post.category} />
        {post.tags.map(tag => (
          <meta property="article:tag" content={tag} key={tag} />
        ))}
      </Helmet>
      
      <div className="container mx-auto px-4 py-12 max-w-4xl">
        {/* Back link */}
        <Link href="/blog" className="inline-flex items-center text-sm font-medium text-primary hover:text-primary/80 mb-8">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to all articles
        </Link>
        
        {/* Article header */}
        <header className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-6">{post.title}</h1>
          
          <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground mb-6">
            <div className="flex items-center gap-1">
              <Calendar className="h-4 w-4" />
              <span>{post.date}</span>
            </div>
            <div className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              <span>{post.readTime}</span>
            </div>
            <Badge variant="secondary">{post.category}</Badge>
          </div>
          
          {/* Featured image */}
          <div className="rounded-lg overflow-hidden mb-8">
            <img 
              src={post.imageUrl} 
              alt={post.title} 
              className="w-full h-auto object-cover"
            />
          </div>
        </header>
        
        {/* Article content */}
        <article className="prose prose-lg dark:prose-invert mx-auto max-w-none mb-10"
          dangerouslySetInnerHTML={{ __html: post.content }}
        />
        
        {/* Tags */}
        <div className="border-t border-border pt-6 mb-8">
          <div className="flex flex-wrap items-center gap-2">
            <TagIcon className="h-4 w-4 text-muted-foreground" />
            {post.tags.map(tag => (
              <Badge key={tag} variant="outline" className="text-sm">
                {tag}
              </Badge>
            ))}
          </div>
        </div>
        
        {/* Author info */}
        <div className="bg-accent/30 rounded-lg p-6 mb-8">
          <div className="flex items-center gap-4">
            <img 
              src={post.authorImage} 
              alt={post.author} 
              className="w-16 h-16 rounded-full object-cover border-2 border-background"
            />
            <div>
              <h3 className="font-bold text-lg">{post.author}</h3>
              <p className="text-muted-foreground text-sm">{post.authorTitle}</p>
            </div>
          </div>
        </div>
        
        {/* Social sharing */}
        <div className="border-t border-border pt-6 mb-10">
          <h3 className="font-medium mb-3">Share this article:</h3>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="rounded-full h-10 w-10 p-0">
              <Facebook className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" className="rounded-full h-10 w-10 p-0">
              <Twitter className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" className="rounded-full h-10 w-10 p-0">
              <Linkedin className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        {/* More articles */}
        <div className="border-t border-border pt-8">
          <h2 className="text-2xl font-bold mb-6">More Articles</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {blogPosts
              .filter(p => p.id !== post.id)
              .slice(0, 2)
              .map(relatedPost => (
                <Link href={`/blog/${relatedPost.slug}`} key={relatedPost.id}>
                  <div className="border border-border rounded-lg overflow-hidden hover:shadow-md transition-shadow group">
                    <div className="h-40 overflow-hidden">
                      <img 
                        src={relatedPost.imageUrl} 
                        alt={relatedPost.title} 
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                    </div>
                    <div className="p-4">
                      <h3 className="font-bold text-lg mb-2 group-hover:text-primary transition-colors">{relatedPost.title}</h3>
                      <p className="text-muted-foreground text-sm line-clamp-2">{relatedPost.excerpt}</p>
                    </div>
                  </div>
                </Link>
              ))}
          </div>
        </div>
      </div>
    </>
  );
}