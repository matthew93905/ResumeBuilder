import { useState, useEffect } from "react";
import { useResume } from "@/hooks/use-resume";
import { templates } from "@/lib/resumeTemplates";
import ResumeForm from "@/components/ResumeForm";
import ResumePreview from "@/components/ResumePreview";
import UpgradeModal from "@/components/UpgradeModal";
import { useToast } from "@/hooks/use-toast";
import { Helmet } from "react-helmet";
import { useSaveResume } from "@/hooks/use-save-resume";
import { useResume as useFetchResume } from "@/hooks/use-load-resume";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useAuth } from "@/hooks/use-auth";
import CollaborationPanel from "@/components/collaboration/CollaborationPanel";
import NotificationsPopover from "@/components/collaboration/NotificationsPopover";

export default function Builder() {
  // Debug templates
  console.log("Available templates:", templates);
  
  const { resumeData, setTemplateId, resetResume, updatePersonalInfo, updateSummary, addExperience, updateExperience, removeExperience, addEducation, updateEducation, removeEducation, addSkill, removeSkill } = useResume();
  const { toast } = useToast();
  const { user } = useAuth();
  const [isTemplateModalOpen, setIsTemplateModalOpen] = useState(false);
  const [isUpgradeModalOpen, setIsUpgradeModalOpen] = useState(false);
  const [isSaveModalOpen, setIsSaveModalOpen] = useState(false);
  const [resumeTitle, setResumeTitle] = useState("");
  const [isDefaultResume, setIsDefaultResume] = useState(false);
  const [currentResumeId, setCurrentResumeId] = useState<number | null>(null);
  const [loadedResumeId, setLoadedResumeId] = useState<number | null>(null);
  const [isCollaborationOpen, setIsCollaborationOpen] = useState(false);
  
  // Log when template modal is opened
  useEffect(() => {
    if (isTemplateModalOpen) {
      console.log("Template modal opened, available templates:", templates);
    }
  }, [isTemplateModalOpen]);
  
  // Get save and update functions from our custom hook
  const { saveResume, updateResume, isSaving, isUpdating } = useSaveResume();
  
  // Fetch resume data if ID is provided
  const { data: loadedResume, isLoading } = useFetchResume(loadedResumeId);
  
  // Effect to load resume data from URL params and check for selected template
  useEffect(() => {
    // Get resume ID from URL params
    const params = new URLSearchParams(window.location.search);
    const id = params.get('id');
    
    if (id) {
      const resumeId = parseInt(id);
      if (!isNaN(resumeId)) {
        setLoadedResumeId(resumeId);
        setCurrentResumeId(resumeId);
      }
    }
    
    // Check if a template was selected from the home page
    const selectedTemplateId = localStorage.getItem('selectedTemplateId');
    if (selectedTemplateId) {
      console.log("Found selected template in localStorage:", selectedTemplateId);
      setTemplateId(selectedTemplateId);
      
      // Clear the localStorage after applying the template
      localStorage.removeItem('selectedTemplateId');
      
      toast({
        title: "Template Applied",
        description: `The ${selectedTemplateId} template has been applied to your resume.`
      });
    }
  }, []);
  
  // Effect to populate form with loaded resume data
  useEffect(() => {
    if (loadedResume && loadedResume.data) {
      const data = loadedResume.data as any; // Type assertion to handle dynamic data structure
      
      // Set title and default status for save dialog
      setResumeTitle(loadedResume.title);
      // Use Boolean to ensure we're setting a boolean value
      setIsDefaultResume(Boolean(loadedResume.isDefault));
      
      // Update the resume context with loaded data
      if (data.personalInfo) {
        updatePersonalInfo(data.personalInfo);
      }
      
      if (data.summary) {
        updateSummary(data.summary);
      }
      
      if (data.templateId) {
        setTemplateId(data.templateId);
      }
      
      // Clear existing experience items first
      resumeData.experience.forEach(exp => removeExperience(exp.id));
      
      // Add loaded experience items
      if (data.experience && Array.isArray(data.experience)) {
        data.experience.forEach((exp: any) => {
          addExperience({
            company: exp.company,
            position: exp.position,
            location: exp.location,
            startDate: exp.startDate,
            endDate: exp.endDate,
            current: exp.current,
            description: exp.description
          });
        });
      }
      
      // Clear existing education items first
      resumeData.education.forEach(edu => removeEducation(edu.id));
      
      // Add loaded education items
      if (data.education && Array.isArray(data.education)) {
        data.education.forEach((edu: any) => {
          addEducation({
            institution: edu.institution,
            degree: edu.degree,
            field: edu.field,
            location: edu.location,
            startDate: edu.startDate,
            endDate: edu.endDate,
            description: edu.description
          });
        });
      }
      
      // Clear existing skills first
      resumeData.skills.forEach(skill => removeSkill(skill.id));
      
      // Add loaded skills
      if (data.skills && Array.isArray(data.skills)) {
        data.skills.forEach((skill: any) => {
          addSkill({ name: skill.name });
        });
      }
      
      toast({
        title: "Resume Loaded",
        description: `Successfully loaded "${loadedResume.title}"`
      });
    }
  }, [loadedResume]);
  
  // Handle template selection
  const handleTemplateChange = (templateId: string) => {
    console.log("Template selected:", templateId);
    const template = templates.find(t => t.id === templateId);
    
    if (template) {
      console.log("Found template:", template);
      // Only show upgrade modal for premium templates if user doesn't have premium access
      if (template.isPremium && (!user || !user.isPremium)) {
        console.log("Premium template - showing upgrade modal");
        // Show upgrade modal for premium templates
        setIsUpgradeModalOpen(true);
      } else {
        console.log("Applying template - either free or user has premium access");
        // Set the template
        setTemplateId(templateId);
        setIsTemplateModalOpen(false);
        
        toast({
          title: `${template.name} Template Applied`,
          description: "Your resume has been updated with the new template."
        });
      }
    } else {
      console.error("Template not found for ID:", templateId);
    }
  };
  
  // Handle resume reset
  const handleResetResume = () => {
    if (confirm("Are you sure you want to reset your resume? All your data will be lost.")) {
      resetResume();
      
      toast({
        title: "Resume Reset",
        description: "Your resume has been reset to the default template."
      });
    }
  };
  
  // Handle PDF export success
  const handleExportSuccess = () => {
    // Analytics could be added here
    console.log("Resume exported successfully");
  };
  
  // Handle save resume to database
  const handleSaveClick = () => {
    setResumeTitle(resumeData.personalInfo.name + "'s Resume");
    setIsSaveModalOpen(true);
  };
  
  // Handle saving a new resume
  const handleSaveResume = () => {
    if (!resumeTitle.trim()) {
      toast({
        title: "Title Required",
        description: "Please enter a title for your resume.",
        variant: "destructive"
      });
      return;
    }
    
    if (currentResumeId) {
      // Update existing resume
      updateResume({
        id: currentResumeId,
        resumeData,
        options: {
          title: resumeTitle,
          isDefault: isDefaultResume
        }
      });
    } else {
      // Save new resume
      saveResume({
        resumeData,
        options: {
          userId: user?.id || 1, // Use authenticated user ID or fallback to 1
          title: resumeTitle,
          isDefault: isDefaultResume
        }
      });
    }
    
    setIsSaveModalOpen(false);
  };
  
  return (
    <>
      <Helmet>
        <title>Resume Builder | ResumeX</title>
        <meta name="description" content="Build and customize your professional resume with our easy-to-use editor." />
      </Helmet>
      
      <div className="bg-white dark:bg-gray-800 min-h-screen">
        {/* Builder Header */}
        <div className="p-4 bg-accent/50 dark:bg-gray-700 border-b border-border flex items-center justify-between sticky top-20 z-10">
          <div className="flex space-x-3">
            <Button 
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-white dark:bg-gray-800 text-primary border border-border rounded-lg text-sm font-medium shadow-sm hover:bg-accent transition-colors"
              onClick={() => {
                console.log("Opening template modal");
                setIsTemplateModalOpen(true);
              }}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-layout-template"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/><path d="M9 21V9"/></svg>
              Change Template
            </Button>
            <button 
              className="inline-flex items-center gap-2 px-4 py-2.5 border border-border rounded-lg text-sm font-medium hover:bg-accent/50 transition-colors"
              onClick={handleResetResume}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-rotate-ccw"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>
              Reset
            </button>
            {currentResumeId && (
              <button 
                className={`inline-flex items-center gap-2 px-4 py-2.5 border border-border rounded-lg text-sm font-medium hover:bg-accent/50 transition-colors ${isCollaborationOpen ? 'bg-primary text-white hover:bg-primary/90' : ''}`}
                onClick={() => setIsCollaborationOpen(!isCollaborationOpen)}
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-users"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                Collaborate
              </button>
            )}
          </div>
          
          <div className="flex items-center space-x-4">
            {user && <NotificationsPopover />}
            <button
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-secondary to-primary text-white rounded-lg text-sm font-medium shadow-md hover:shadow-lg transition-all"
              onClick={handleSaveClick}
              disabled={isSaving || isUpdating}
            >
              {isSaving || isUpdating ? (
                <>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Saving...
                </>
              ) : (
                <>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-save"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                  Save Resume
                </>
              )}
            </button>
            <span className="hidden md:flex items-center gap-1.5 text-sm text-muted-foreground">
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check-circle-2 text-green-500"><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"/><path d="m9 12 2 2 4-4"/></svg>
              Auto-saving
            </span>
          </div>
        </div>
        
        {/* Builder Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 min-h-[calc(100vh-180px)]">
          {/* Form Section */}
          <div className="bg-white dark:bg-gray-800 overflow-auto border-r border-border">
            <ResumeForm />
          </div>
          
          {/* Preview Section */}
          <div className="bg-accent/30 dark:bg-gray-900 overflow-auto p-6 flex items-center justify-center">
            <ResumePreview onExport={handleExportSuccess} />
          </div>
        </div>
        
        {/* Template Selection Modal */}
        <Dialog open={isTemplateModalOpen} onOpenChange={setIsTemplateModalOpen}>
          <DialogContent className="sm:max-w-5xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-2xl font-bold">Choose a Template</DialogTitle>
              <DialogDescription>
                Select the perfect template for your professional resume
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 my-6">
              {templates.map(template => (
                <div 
                  key={template.id} 
                  className={`border rounded-lg overflow-hidden cursor-pointer ${resumeData.templateId === template.id ? 'ring-2 ring-primary border-primary' : ''} ${template.isPremium ? 'relative' : ''}`}
                  onClick={() => handleTemplateChange(template.id)}
                >
                  <div className="relative h-52 overflow-hidden">
                    <div className={`w-full h-full ${template.isPremium && (!user || !user.isPremium) ? 'filter blur-sm' : ''}`}>
                      {template.thumbnail}
                    </div>
                    <div className={`absolute top-3 left-3 ${template.isPremium ? 'bg-gradient-to-r from-secondary to-primary' : 'bg-gradient-to-r from-emerald-500 to-emerald-600'} text-white text-xs font-medium px-3 py-1.5 rounded-full`}>
                      {template.isPremium ? 'Premium' : 'Free'}
                    </div>
                    
                    {resumeData.templateId === template.id && (
                      <div className="absolute inset-0 bg-primary/10 flex items-center justify-center">
                        <div className="bg-primary text-white rounded-full px-3 py-1.5 text-sm font-medium">
                          Selected
                        </div>
                      </div>
                    )}
                  </div>
                  <div className="p-4">
                    <h4 className="font-semibold text-lg">{template.name}</h4>
                    <p className="text-sm text-muted-foreground mt-1">{template.description}</p>
                  </div>
                  
                  {/* Overlay for premium templates - only show if user doesn't have premium */}
                  {template.isPremium && (!user || !user.isPremium) && (
                    <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center">
                      <div className="text-center px-6">
                        <div className="w-12 h-12 rounded-full bg-accent flex items-center justify-center mx-auto mb-3">
                          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-lock text-primary"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                        </div>
                        <h4 className="text-white font-semibold">Premium Template</h4>
                        <p className="text-white/70 text-sm mt-1 mb-3">Upgrade to access premium templates</p>
                        <button className="text-white bg-gradient-to-r from-secondary to-primary px-4 py-1.5 rounded-lg text-sm">
                          Upgrade
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
            
            <DialogFooter>
              <Button 
                className="px-5 py-2.5 bg-primary text-white rounded-lg"
                onClick={() => setIsTemplateModalOpen(false)}
              >
                Apply Selected Template
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
        
        {/* Upgrade Modal */}
        <UpgradeModal 
          isOpen={isUpgradeModalOpen} 
          onClose={() => setIsUpgradeModalOpen(false)} 
        />
        
        {/* Save Resume Dialog */}
        <Dialog open={isSaveModalOpen} onOpenChange={setIsSaveModalOpen}>
          <DialogContent className="sm:max-w-[440px]">
            <DialogHeader>
              <div className="flex items-center gap-3 mb-2">
                <div className="bg-accent p-2 rounded-lg">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                </div>
                <DialogTitle className="text-xl">Save Your Resume</DialogTitle>
              </div>
              <DialogDescription>
                Give your resume a title and save it to your account for future access.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-6 py-6">
              <div className="space-y-2">
                <Label htmlFor="resume-title" className="font-medium">
                  Resume Title
                </Label>
                <Input
                  id="resume-title"
                  value={resumeTitle}
                  onChange={(e) => setResumeTitle(e.target.value)}
                  className="w-full"
                  placeholder="e.g. Software Developer Resume"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Choose a name that helps you identify this resume
                </p>
              </div>
              
              <div className="flex items-center justify-between bg-accent/50 p-3 rounded-lg">
                <div className="flex items-center space-x-2">
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><path d="m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/><path d="m22 17.65-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65"/><path d="m22 12.65-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65"/></svg>
                  <Label htmlFor="is-default" className="font-medium text-sm">
                    Set as default resume
                  </Label>
                </div>
                <Switch
                  id="is-default"
                  checked={isDefaultResume}
                  onCheckedChange={setIsDefaultResume}
                />
              </div>
            </div>
            <DialogFooter className="flex gap-3">
              <Button 
                variant="outline" 
                onClick={() => setIsSaveModalOpen(false)}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                onClick={handleSaveResume}
                disabled={isSaving || isUpdating}
                className="flex-1 bg-gradient-to-r from-secondary to-primary"
              >
                {isSaving || isUpdating ? (
                  <span className="flex items-center gap-1.5">
                    <svg className="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Saving...
                  </span>
                ) : 'Save Resume'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Collaboration Panel */}
        {isCollaborationOpen && currentResumeId && user && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setIsCollaborationOpen(false)}>
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 max-w-3xl w-full mx-auto shadow-2xl" onClick={e => e.stopPropagation()}>
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h3 className="font-montserrat font-bold text-2xl mb-2">Collaboration</h3>
                  <p className="text-muted-foreground">Collaborate with teammates on your resume</p>
                </div>
                <button 
                  className="w-8 h-8 rounded-full flex items-center justify-center text-gray-500 hover:bg-accent transition-colors"
                  onClick={() => setIsCollaborationOpen(false)}
                  aria-label="Close modal"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-x"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                </button>
              </div>
              
              <CollaborationPanel resumeId={currentResumeId} isOwner={true} />
            </div>
          </div>
        )}
      </div>
    </>
  );
}
