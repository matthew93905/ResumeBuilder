import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Helmet } from "react-helmet";
import { useLocation } from "wouter";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle, 
  CardFooter 
} from "@/components/ui/card";
import { 
  Table, 
  TableHeader, 
  TableBody, 
  TableHead, 
  TableRow, 
  TableCell, 
  TableCaption 
} from "@/components/ui/table";
import { 
  BarChart, 
  Bar, 
  LineChart,
  Line,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend
} from "recharts";
import { format, subDays } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { 
  ChevronRight, 
  BarChart as BarChartIcon, 
  Globe, 
  Users, 
  Eye, 
  Clock,
  FileSearch,
  Monitor,
  Activity,
  PlayCircle,
  Share2
} from "lucide-react";
import SocialMediaCampaigns from "@/components/SocialMediaCampaigns";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";

// Type for affiliate analytics
type AffiliateAnalytics = {
  totalClicks: number;
  affiliateClicks: number;
  conversionRate: number;
  topInstitutions: { name: string; count: number }[];
  recentClicks: {
    id: number;
    institution: string;
    isAffiliate: boolean;
    earnedCredits: boolean;
    timestamp: string;
    username: string;
  }[];
};

// Types for visitor analytics
type VisitorStatistics = {
  totalVisitors: number;
  newVisitorsToday: number;
  averagePageViews: number;
  topCountries: { country: string; count: number }[];
};

type PageViewStatistics = {
  totalPageViews: number;
  uniquePages: number;
  topPages: { path: string; views: number }[];
  averageTimeOnPage: number;
};

type DailyVisitorData = {
  date: string;
  count: number;
};

type Visitor = {
  id: number;
  visitorId: string;
  userId: number | null;
  userAgent: string;
  ip: string | null;
  country: string | null;
  city: string | null;
  region: string | null;
  os: string | null;
  browser: string | null;
  device: string | null;
  referrer: string | null;
  landingPage: string;
  firstVisit: string;
  lastVisit: string;
  visitCount: number;
};

type SessionRecording = {
  id: number;
  visitorId: string;
  userId: number | null;
  sessionId: string;
  startTime: string;
  endTime: string | null;
  duration: number | null;
  events: any;
  userAgent: string | null;
  deviceType: string | null;
  country: string | null;
  city: string | null;
};

// Colors for charts
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

export default function AdminDashboard() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("social");
  
  // Add a useEffect to turn off loading when the component mounts
  useEffect(() => {
    // Short delay to ensure loading only turns off after component is fully mounted
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 500);
    
    return () => clearTimeout(timer);
  }, []);
  const [affiliateData, setAffiliateData] = useState<AffiliateAnalytics | null>(null);
  const [visitorStats, setVisitorStats] = useState<VisitorStatistics | null>(null);
  const [pageViewStats, setPageViewStats] = useState<PageViewStatistics | null>(null);
  const [visitorsDaily, setVisitorsDaily] = useState<DailyVisitorData[]>([]);
  const [recentVisitors, setRecentVisitors] = useState<Visitor[]>([]);
  const [sessionRecordings, setSessionRecordings] = useState<SessionRecording[]>([]);
  const [selectedRecording, setSelectedRecording] = useState<SessionRecording | null>(null);
  const [isReplayingSession, setIsReplayingSession] = useState(false);

  // Check if user is admin, if not, redirect to home
  useEffect(() => {
    if (user && !user.isAdmin) {
      toast({
        title: "Access Denied",
        description: "You do not have permission to access this page.",
        variant: "destructive",
      });
      navigate("/");
    }
  }, [user, navigate, toast]);

  // Fetch affiliate analytics from the server
  useEffect(() => {
    const fetchAffiliateData = async () => {
      if (!user) return;
      
      try {
        const response = await apiRequest("GET", "/api/admin/affiliate-analytics");
        
        if (!response.ok) {
          throw new Error("Failed to fetch affiliate analytics");
        }
        
        const data = await response.json();
        setAffiliateData(data);
      } catch (error) {
        console.error("Error fetching affiliate analytics:", error);
        toast({
          title: "Error",
          description: "Failed to load affiliate analytics data.",
          variant: "destructive",
        });
      }
    };
    
    if (activeTab === "affiliates") {
      fetchAffiliateData();
    }
  }, [user, toast, activeTab]);

  // Fetch visitor statistics
  useEffect(() => {
    const fetchVisitorStats = async () => {
      if (!user) return;
      
      try {
        const response = await apiRequest("GET", "/api/admin/analytics/visitors");
        
        if (!response.ok) {
          throw new Error("Failed to fetch visitor statistics");
        }
        
        const data = await response.json();
        setVisitorStats(data);
      } catch (error) {
        console.error("Error fetching visitor statistics:", error);
        toast({
          title: "Error",
          description: "Failed to load visitor statistics.",
          variant: "destructive",
        });
      }
    };
    
    if (activeTab === "analytics") {
      fetchVisitorStats();
    }
  }, [user, toast, activeTab]);

  // Fetch page view statistics
  useEffect(() => {
    const fetchPageViewStats = async () => {
      if (!user) return;
      
      try {
        const response = await apiRequest("GET", "/api/admin/analytics/pageviews");
        
        if (!response.ok) {
          throw new Error("Failed to fetch page view statistics");
        }
        
        const data = await response.json();
        setPageViewStats(data);
      } catch (error) {
        console.error("Error fetching page view statistics:", error);
        toast({
          title: "Error",
          description: "Failed to load page view statistics.",
          variant: "destructive",
        });
      }
    };
    
    if (activeTab === "analytics") {
      fetchPageViewStats();
    }
  }, [user, toast, activeTab]);

  // Fetch daily visitor data
  useEffect(() => {
    const fetchVisitorsByDay = async () => {
      if (!user) return;
      
      try {
        const response = await apiRequest("GET", "/api/admin/analytics/visitors-by-day?days=30");
        
        if (!response.ok) {
          throw new Error("Failed to fetch daily visitor data");
        }
        
        const data = await response.json();
        setVisitorsDaily(data);
      } catch (error) {
        console.error("Error fetching daily visitor data:", error);
        toast({
          title: "Error",
          description: "Failed to load daily visitor data.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    if (activeTab === "analytics") {
      fetchVisitorsByDay();
    }
  }, [user, toast, activeTab]);

  // Fetch recent visitors
  useEffect(() => {
    const fetchRecentVisitors = async () => {
      if (!user) return;
      
      try {
        const response = await apiRequest("GET", "/api/admin/analytics/visitors-list?limit=20");
        
        if (!response.ok) {
          throw new Error("Failed to fetch recent visitors");
        }
        
        const data = await response.json();
        setRecentVisitors(data);
      } catch (error) {
        console.error("Error fetching recent visitors:", error);
        toast({
          title: "Error",
          description: "Failed to load recent visitors.",
          variant: "destructive",
        });
      }
    };
    
    if (activeTab === "visitors") {
      fetchRecentVisitors();
    }
  }, [user, toast, activeTab]);

  // Fetch session recordings
  useEffect(() => {
    const fetchSessionRecordings = async () => {
      if (!user) return;
      
      try {
        const response = await apiRequest("GET", "/api/admin/analytics/session-recordings?limit=50");
        
        if (!response.ok) {
          throw new Error("Failed to fetch session recordings");
        }
        
        const data = await response.json();
        setSessionRecordings(data);
      } catch (error) {
        console.error("Error fetching session recordings:", error);
        toast({
          title: "Error",
          description: "Failed to load session recordings.",
          variant: "destructive",
        });
      }
    };
    
    if (activeTab === "recordings") {
      fetchSessionRecordings();
    }
  }, [user, toast, activeTab]);

  // Function to play a session recording
  const playSessionRecording = async (recordingId: number) => {
    try {
      const response = await apiRequest("GET", `/api/admin/analytics/session-recordings/${recordingId}`);
      
      if (!response.ok) {
        throw new Error("Failed to fetch session recording");
      }
      
      const data = await response.json();
      setSelectedRecording(data);
      setIsReplayingSession(true);
      
      // In a real implementation, we would use rrweb to replay the session
      // rrweb.replay(data.events);
      
    } catch (error) {
      console.error("Error fetching session recording:", error);
      toast({
        title: "Error",
        description: "Failed to load session recording.",
        variant: "destructive",
      });
    }
  };

  // Format data for affiliate charts
  const prepareConversionData = () => {
    if (!affiliateData) return [];
    
    return [
      { name: 'Affiliate Clicks', value: affiliateData.affiliateClicks },
      { name: 'Non-Affiliate Clicks', value: affiliateData.totalClicks - affiliateData.affiliateClicks }
    ];
  };

  // If not authenticated or loading, show loading state
  if (!user || isLoading) {
    return (
      <div className="container py-8 mx-auto flex items-center justify-center min-h-[60vh]">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Admin Dashboard | ResumeX</title>
      </Helmet>
      
      <div className="container py-8 mx-auto">
        <div className="flex flex-col gap-2 pb-6">
          <h1 className="text-3xl font-bold tracking-tight">Admin Dashboard</h1>
          <p className="text-muted-foreground">
            Monitor website analytics, visitor behavior, and marketing performance
          </p>
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-5 mb-6">
            <TabsTrigger value="analytics">
              <BarChartIcon className="w-4 h-4 mr-2" />
              Website Analytics
            </TabsTrigger>
            <TabsTrigger value="visitors">
              <Users className="w-4 h-4 mr-2" />
              Visitor Tracking
            </TabsTrigger>
            <TabsTrigger value="recordings">
              <Activity className="w-4 h-4 mr-2" />
              Session Recordings
            </TabsTrigger>
            <TabsTrigger value="affiliates">
              <Globe className="w-4 h-4 mr-2" />
              Affiliate Marketing
            </TabsTrigger>
            <TabsTrigger value="social">
              <Share2 className="w-4 h-4 mr-2" />
              Social Media
            </TabsTrigger>
          </TabsList>
          
          {/* Website Analytics Tab */}
          <TabsContent value="analytics" className="w-full">
            {visitorStats && pageViewStats ? (
              <>
                {/* Analytics Summary Cards */}
                <div className="grid gap-4 md:grid-cols-4 mb-6">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-md font-medium text-muted-foreground">Total Visitors</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-3xl font-bold">{visitorStats.totalVisitors}</div>
                      <p className="text-xs mt-1 text-muted-foreground">
                        <span className="text-green-500 font-medium">+{visitorStats.newVisitorsToday}</span> new today
                      </p>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-md font-medium text-muted-foreground">Page Views</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-3xl font-bold">{pageViewStats.totalPageViews}</div>
                      <p className="text-xs mt-1 text-muted-foreground">
                        Across {pageViewStats.uniquePages} unique pages
                      </p>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-md font-medium text-muted-foreground">Avg. Page Views</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-3xl font-bold">{visitorStats.averagePageViews.toFixed(1)}</div>
                      <p className="text-xs mt-1 text-muted-foreground">
                        Per visitor session
                      </p>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-md font-medium text-muted-foreground">Avg. Time on Page</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-3xl font-bold">
                        {Math.floor(pageViewStats.averageTimeOnPage / 60)}:{(pageViewStats.averageTimeOnPage % 60).toString().padStart(2, '0')}
                      </div>
                      <p className="text-xs mt-1 text-muted-foreground">
                        Minutes:Seconds
                      </p>
                    </CardContent>
                  </Card>
                </div>
                
                {/* Analytics Charts */}
                <div className="grid gap-6 md:grid-cols-2 mb-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Visitors Over Time</CardTitle>
                      <CardDescription>Daily visitor count for the past 30 days</CardDescription>
                    </CardHeader>
                    <CardContent className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart
                          data={visitorsDaily}
                          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis 
                            dataKey="date" 
                            tickFormatter={(date) => {
                              return format(new Date(date), 'MMM d');
                            }}
                          />
                          <YAxis />
                          <Tooltip 
                            labelFormatter={(date) => format(new Date(date), 'MMMM d, yyyy')}
                            formatter={(value) => [`${value} visitors`, 'Visitors']}
                          />
                          <Line 
                            type="monotone" 
                            dataKey="count" 
                            stroke="#8884d8" 
                            strokeWidth={2}
                            activeDot={{ r: 8 }}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle>Top Pages</CardTitle>
                      <CardDescription>Most viewed pages on your site</CardDescription>
                    </CardHeader>
                    <CardContent className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={pageViewStats.topPages.slice(0, 5)}
                          layout="vertical"
                          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis type="number" />
                          <YAxis 
                            type="category" 
                            dataKey="path"
                            tick={{ fontSize: 12 }}
                            width={150}
                            tickFormatter={(path) => {
                              if (path.length > 20) {
                                return path.substring(0, 17) + '...';
                              }
                              return path;
                            }}
                          />
                          <Tooltip formatter={(value) => [`${value} views`, 'Views']} />
                          <Bar dataKey="views" fill="#82ca9d" />
                        </BarChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                </div>

                <div className="grid gap-6 md:grid-cols-2 mb-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Top Countries</CardTitle>
                      <CardDescription>Visitor distribution by country</CardDescription>
                    </CardHeader>
                    <CardContent className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={visitorStats.topCountries}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={100}
                            fill="#8884d8"
                            dataKey="count"
                            nameKey="country"
                            label={({ country, count, percent }) => 
                              `${country}: ${(percent * 100).toFixed(0)}%`
                            }
                          >
                            {visitorStats.topCountries.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value) => [`${value} visitors`, 'Visitors']} />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                </div>
              </>
            ) : (
              <Card>
                <CardContent className="py-10">
                  <div className="text-center">
                    <p className="text-muted-foreground">No analytics data available yet.</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>
          
          {/* Visitor Tracking Tab */}
          <TabsContent value="visitors" className="w-full">
            <Card>
              <CardHeader>
                <CardTitle>Recent Visitors</CardTitle>
                <CardDescription>Details of recent website visitors</CardDescription>
              </CardHeader>
              <CardContent>
                {recentVisitors.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Last Visit</TableHead>
                        <TableHead>Location</TableHead>
                        <TableHead>Device / Browser</TableHead>
                        <TableHead>Visit Count</TableHead>
                        <TableHead>First Seen</TableHead>
                        <TableHead>Landing Page</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {recentVisitors.map((visitor) => (
                        <TableRow key={visitor.id}>
                          <TableCell>
                            {format(new Date(visitor.lastVisit), 'MMM d, yyyy h:mm a')}
                          </TableCell>
                          <TableCell>
                            {visitor.country ? (
                              <div className="flex items-center">
                                <Globe className="w-4 h-4 mr-2 text-gray-400" />
                                <span>{visitor.country}{visitor.city ? `, ${visitor.city}` : ''}</span>
                              </div>
                            ) : (
                              <span className="text-muted-foreground">Unknown</span>
                            )}
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-col">
                              <span>{visitor.device || 'Unknown'}</span>
                              <span className="text-xs text-muted-foreground">{visitor.browser || 'Unknown'}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">{visitor.visitCount}</Badge>
                          </TableCell>
                          <TableCell>
                            {format(new Date(visitor.firstVisit), 'MMM d, yyyy')}
                          </TableCell>
                          <TableCell className="font-medium truncate max-w-[200px]" title={visitor.landingPage}>
                            {visitor.landingPage}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-10">
                    <p className="text-muted-foreground">No visitor data available yet.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Session Recordings Tab */}
          <TabsContent value="recordings" className="w-full h-full">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
              <Card className="lg:col-span-1 h-full">
                <CardHeader>
                  <CardTitle>Session Recordings</CardTitle>
                  <CardDescription>Replay user sessions to understand behavior</CardDescription>
                </CardHeader>
                <CardContent className="p-0">
                  <ScrollArea className="h-[600px]">
                    {sessionRecordings.length > 0 ? (
                      <div>
                        {sessionRecordings.map((recording) => (
                          <div 
                            key={recording.id}
                            className={`p-4 border-b last:border-b-0 cursor-pointer hover:bg-muted transition-colors ${selectedRecording?.id === recording.id ? 'bg-muted' : ''}`}
                            onClick={() => playSessionRecording(recording.id)}
                          >
                            <div className="flex justify-between items-start">
                              <div>
                                <div className="font-medium mb-1">
                                  Session #{recording.id}
                                  {recording.duration && (
                                    <span className="text-xs font-normal text-muted-foreground ml-2">
                                      ({Math.floor(recording.duration / 60)}:{(recording.duration % 60).toString().padStart(2, '0')})
                                    </span>
                                  )}
                                </div>
                                <div className="text-xs text-muted-foreground mb-2">
                                  {format(new Date(recording.startTime), 'MMM d, yyyy h:mm a')}
                                </div>
                                <div className="flex items-center text-xs text-muted-foreground">
                                  <Globe className="w-3 h-3 mr-1" />
                                  <span>{recording.country || 'Unknown'}</span>
                                  <span className="mx-2">•</span>
                                  <Monitor className="w-3 h-3 mr-1" />
                                  <span>{recording.deviceType || 'Unknown'}</span>
                                </div>
                              </div>
                              <Button size="sm" variant="outline" className="h-7">
                                <PlayCircle className="w-4 h-4 mr-1" />
                                Play
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-10">
                        <p className="text-muted-foreground">No session recordings available yet.</p>
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>
              
              <Card className="lg:col-span-2 h-full">
                <CardHeader>
                  <CardTitle>Session Replay</CardTitle>
                  <CardDescription>
                    {selectedRecording ? (
                      `Session #${selectedRecording.id} - ${format(new Date(selectedRecording.startTime), 'MMM d, yyyy h:mm a')}`
                    ) : (
                      "Select a session to replay"
                    )}
                  </CardDescription>
                </CardHeader>
                <CardContent className="h-[500px] flex items-center justify-center">
                  {selectedRecording ? (
                    isReplayingSession ? (
                      <div className="w-full h-full flex flex-col">
                        <div className="bg-muted p-2 mb-2 flex justify-between items-center">
                          <div className="text-xs">
                            <span className="font-medium">Replaying Session #{selectedRecording.id}</span>
                            <span className="mx-2">•</span>
                            <span>{selectedRecording.country || 'Unknown'}</span>
                            <span className="mx-2">•</span>
                            <span>{selectedRecording.deviceType || 'Unknown'}</span>
                          </div>
                          <Button size="sm" variant="outline" className="h-7" onClick={() => setIsReplayingSession(false)}>
                            Stop Replay
                          </Button>
                        </div>
                        <div className="flex-1 border rounded flex items-center justify-center bg-background">
                          <div className="text-center p-6">
                            <FileSearch className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                            <p className="text-lg mb-1">Session replay would appear here</p>
                            <p className="text-sm text-muted-foreground">
                              In a production environment, the actual user session would be replayed using rrweb
                            </p>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center">
                        <Clock className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                        <p className="text-lg mb-2">Session selected but not playing</p>
                        <Button onClick={() => setIsReplayingSession(true)}>
                          <PlayCircle className="w-4 h-4 mr-2" />
                          Start Replay
                        </Button>
                      </div>
                    )
                  ) : (
                    <div className="text-center">
                      <Activity className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                      <p className="text-lg mb-2">No session selected</p>
                      <p className="text-muted-foreground">Select a session from the list to replay it</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* Affiliate Marketing Tab */}
          <TabsContent value="affiliates" className="w-full">
            {affiliateData ? (
              <>
                {/* Summary Cards */}
                <div className="grid gap-4 md:grid-cols-3 mb-6">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-xl">Total Clicks</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-3xl font-bold">{affiliateData.totalClicks}</div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-xl">Affiliate Clicks</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-3xl font-bold">{affiliateData.affiliateClicks}</div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-xl">Conversion Rate</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-3xl font-bold">{affiliateData.conversionRate.toFixed(1)}%</div>
                    </CardContent>
                  </Card>
                </div>
                
                {/* Charts */}
                <div className="grid gap-6 md:grid-cols-2 mb-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Top Institutions</CardTitle>
                      <CardDescription>Most popular educational institutions by clicks</CardDescription>
                    </CardHeader>
                    <CardContent className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={affiliateData.topInstitutions}
                          margin={{ top: 5, right: 30, left: 20, bottom: 60 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis
                            dataKey="name"
                            angle={-45}
                            textAnchor="end"
                            height={70}
                            interval={0}
                            tick={{ fontSize: 12 }}
                          />
                          <YAxis />
                          <Tooltip />
                          <Bar dataKey="count" fill="#8884d8" />
                        </BarChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle>Conversion Distribution</CardTitle>
                      <CardDescription>Affiliate vs. non-affiliate clicks</CardDescription>
                    </CardHeader>
                    <CardContent className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={prepareConversionData()}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                            outerRadius={100}
                            fill="#8884d8"
                            dataKey="value"
                          >
                            {prepareConversionData().map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip />
                        </PieChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                </div>
                
                {/* Recent Activity Table */}
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Affiliate Activity</CardTitle>
                    <CardDescription>Latest clicks on educational institution links</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableCaption>Recent affiliate marketing interactions</TableCaption>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Time</TableHead>
                          <TableHead>User</TableHead>
                          <TableHead>Institution</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Credits</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {affiliateData.recentClicks.map((click) => (
                          <TableRow key={click.id}>
                            <TableCell>
                              {format(new Date(click.timestamp), 'MMM d, yyyy h:mm a')}
                            </TableCell>
                            <TableCell>{click.username}</TableCell>
                            <TableCell className="font-medium">{click.institution}</TableCell>
                            <TableCell>
                              {click.isAffiliate ? (
                                <Badge className="bg-green-500">Partner</Badge>
                              ) : (
                                <Badge variant="outline">Regular</Badge>
                              )}
                            </TableCell>
                            <TableCell>
                              {click.earnedCredits ? (
                                <Badge className="bg-amber-500">Earned</Badge>
                              ) : (
                                <Badge variant="outline">-</Badge>
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </>
            ) : (
              <Card>
                <CardContent className="py-10">
                  <div className="text-center">
                    <p className="text-muted-foreground">No affiliate data available yet.</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>
          
          {/* Social Media Tab */}
          <TabsContent value="social" className="w-full">
            <SocialMediaCampaigns />
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
}