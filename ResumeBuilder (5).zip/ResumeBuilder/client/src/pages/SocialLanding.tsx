import { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ChevronRight, CheckCircle2, Shield, Star } from "lucide-react";
import CanonicalUrl from '@/components/CanonicalUrl';
import RouteSEO from '@/components/RouteSEO';
import JsonLdSchema from '@/components/JsonLdSchema';

// Social media platform-specific content
const platformContent = {
  linkedin: {
    heading: "Create a Resume That Gets You Hired",
    subheading: "LinkedIn professionals trust ResumeX for standout resumes that land interviews.",
    cta: "Build Your Professional Resume",
    benefits: [
      "Optimized for ATS systems used by 95% of Fortune 500 companies",
      "Templates designed for professional networking and corporate roles",
      "AI tools to highlight your professional achievements",
      "One-click apply feature for LinkedIn job listings"
    ],
    testimonial: {
      text: "ResumeX helped me create a resume that perfectly showcased my skills. I landed interviews at three top tech companies within a week!",
      author: "Sarah Johnson, Software Engineer",
      company: "Hired at Microsoft"
    }
  },
  facebook: {
    heading: "Your Dream Job Starts With a Perfect Resume",
    subheading: "Join over 1 million professionals who landed interviews with ResumeX resumes.",
    cta: "Create Your Resume Now",
    benefits: [
      "Easy-to-use builder with step-by-step guidance",
      "Templates for all experience levels and industries",
      "Expert tips built into the editor",
      "Share your professional resume across platforms"
    ],
    testimonial: {
      text: "I was struggling to get interviews until I rebuilt my resume with ResumeX. The AI suggestions were a game-changer!",
      author: "Michael Chen",
      company: "Marketing Director"
    }
  },
  instagram: {
    heading: "Resumes As Impressive As Your Instagram Feed",
    subheading: "Stand out with visually stunning yet professional resume templates.",
    cta: "Design Your Resume",
    benefits: [
      "Visually striking templates that maintain professionalism",
      "Custom color schemes to match your personal brand",
      "Modern layouts for creative industries",
      "Export options optimized for digital sharing"
    ],
    testimonial: {
      text: "As a graphic designer, I needed a resume that showcased my aesthetic sense. ResumeX delivered with templates that were both beautiful and professional.",
      author: "Emma Rodriguez",
      company: "Creative Director"
    }
  },
  tiktok: {
    heading: "Resume Building That Doesn't Take Forever",
    subheading: "Create a professional resume in minutes, not hours. No experience needed.",
    cta: "Get Started (It's Quick!)",
    benefits: [
      "Build your entire resume in under 15 minutes",
      "Perfect for first-time job seekers and students",
      "Video tutorials for each section",
      "Templates that grab attention quickly"
    ],
    testimonial: {
      text: "I had no idea where to start with my first resume. ResumeX made it super easy and I got my first internship!",
      author: "Tyler Washington",
      company: "Marketing Intern"
    }
  },
  twitter: {
    heading: "Resumes That Make an Impact in 280 Characters or More",
    subheading: "Concise, powerful resumes that tell your professional story effectively.",
    cta: "Craft Your Career Story",
    benefits: [
      "AI tools to create impactful bullet points",
      "Templates that maximize limited space",
      "Keyword optimization for your industry",
      "Easy sharing with potential employers"
    ],
    testimonial: {
      text: "ResumeX helped me distill my 15 years of experience into a concise, powerful resume that got results immediately.",
      author: "David Patel",
      company: "Senior Project Manager"
    }
  },
  pinterest: {
    heading: "Resume Templates Worth Pinning",
    subheading: "Beautifully designed resume templates that get you noticed.",
    cta: "Find Your Perfect Template",
    benefits: [
      "Visually stunning yet ATS-friendly designs",
      "Color schemes for every personal brand",
      "Printable and digital-optimized versions",
      "Coordinating cover letter templates"
    ],
    testimonial: {
      text: "I found ResumeX through Pinterest and was blown away by the template quality. My resume now looks as professional as my portfolio.",
      author: "Jessica Kim",
      company: "Interior Designer"
    }
  },
  default: {
    heading: "Professional Resumes Made Simple",
    subheading: "Create standout resumes with ResumeX's easy-to-use builder and AI-powered tools.",
    cta: "Create Your Resume",
    benefits: [
      "Multiple professional templates for every industry",
      "AI-enhanced content suggestions",
      "ATS-friendly designs to pass screening software",
      "Export to PDF, Word, or share online"
    ],
    testimonial: {
      text: "ResumeX transformed my resume from basic to exceptional. I received multiple interview offers within days of applying with my new resume.",
      author: "Alex Rivera",
      company: "Financial Analyst"
    }
  }
};

export default function SocialLanding() {
  const [location, navigate] = useLocation();
  const [platform, setPlatform] = useState('default');
  const [content, setContent] = useState(platformContent.default);
  
  // Extract the UTM source from URL parameters
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const source = params.get('utm_source');
    
    // Map utm_source to platform content
    if (source) {
      const platformKey = Object.keys(platformContent).find(key => 
        source.toLowerCase().includes(key)
      ) || 'default';
      
      setPlatform(platformKey);
      setContent(platformContent[platformKey as keyof typeof platformContent]);
    }
  }, []);
  
  // Create schema data for the page
  const landingPageSchema = {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "name": content.heading,
    "description": content.subheading,
    "offers": {
      "@type": "Offer",
      "price": "0",
      "priceCurrency": "USD"
    }
  };
  
  // SEO keywords based on platform
  const keywords = [
    "resume builder", 
    "professional resume", 
    "job application", 
    `${platform} resume`, 
    "career development",
    "resume templates",
    "CV maker"
  ];
  
  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-background to-muted/30">
      {/* SEO components */}
      <RouteSEO 
        title={`${content.heading} | ResumeX Resume Builder`}
        description={content.subheading}
        keywords={keywords}
        path="/social-landing"
        type="website"
      />
      <CanonicalUrl 
        path="/social-landing" 
        preservedParams={["ref_campaign"]} 
      />
      <JsonLdSchema schema={landingPageSchema} />
      
      <div className="container max-w-7xl mx-auto px-4 py-16 md:py-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left column: Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-primary to-indigo-500">
                {content.heading}
              </h1>
              
              <p className="text-xl text-muted-foreground">
                {content.subheading}
              </p>
            </div>
            
            <div className="space-y-4">
              <h2 className="text-2xl font-semibold">Why choose ResumeX?</h2>
              <ul className="space-y-3">
                {content.benefits.map((benefit, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle2 className="h-6 w-6 text-primary flex-shrink-0 mr-2" />
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            <div className="bg-card p-6 rounded-xl border shadow-sm">
              <p className="italic text-muted-foreground mb-4">"{content.testimonial.text}"</p>
              <div>
                <p className="font-medium">{content.testimonial.author}</p>
                <p className="text-sm text-muted-foreground">{content.testimonial.company}</p>
              </div>
            </div>
            
            <div className="pt-4">
              <Button size="lg" onClick={() => navigate('/auth')} className="w-full sm:w-auto text-lg">
                {content.cta}
                <ChevronRight className="h-4 w-4 ml-2" />
              </Button>
              <p className="text-sm text-muted-foreground mt-2 flex items-center justify-center sm:justify-start">
                <Shield className="h-4 w-4 mr-1" />
                Free to start. No credit card required.
              </p>
            </div>
          </div>
          
          {/* Right column: Template previews */}
          <div className="space-y-6">
            <Tabs defaultValue="modern" className="w-full">
              <TabsList className="grid grid-cols-3 mb-4">
                <TabsTrigger value="modern">Modern</TabsTrigger>
                <TabsTrigger value="professional">Professional</TabsTrigger>
                <TabsTrigger value="creative">Creative</TabsTrigger>
              </TabsList>
              
              <TabsContent value="modern" className="mt-0">
                <div className="relative group">
                  <div className="overflow-hidden rounded-lg border shadow-lg">
                    <img 
                      src="/images/templates/modern-template.jpg" 
                      alt="Modern resume template" 
                      className="w-full h-auto object-cover transition-transform group-hover:scale-105 duration-300"
                    />
                  </div>
                  <div className="absolute top-3 right-3 bg-primary text-white px-3 py-1 rounded-full text-sm font-medium flex items-center">
                    <Star className="h-3 w-3 mr-1 fill-current" />
                    Popular
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="professional" className="mt-0">
                <div className="overflow-hidden rounded-lg border shadow-lg">
                  <img 
                    src="/images/templates/executive-template.jpg" 
                    alt="Professional resume template" 
                    className="w-full h-auto object-cover transition-transform group-hover:scale-105 duration-300"
                  />
                </div>
              </TabsContent>
              
              <TabsContent value="creative" className="mt-0">
                <div className="overflow-hidden rounded-lg border shadow-lg">
                  <img 
                    src="/images/templates/creative-template.jpg" 
                    alt="Creative resume template" 
                    className="w-full h-auto object-cover transition-transform group-hover:scale-105 duration-300"
                  />
                </div>
              </TabsContent>
            </Tabs>
            
            <div className="flex justify-center space-x-1.5">
              <div className="w-2 h-2 rounded-full bg-primary"></div>
              <div className="w-2 h-2 rounded-full bg-muted"></div>
              <div className="w-2 h-2 rounded-full bg-muted"></div>
              <div className="w-2 h-2 rounded-full bg-muted"></div>
            </div>
            
            <div className="bg-muted/50 p-4 rounded-lg">
              <div className="flex items-center space-x-4 mb-3">
                <div className="bg-primary/20 p-2 rounded-full">
                  <Shield className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">ATS-Friendly Templates</h3>
                  <p className="text-sm text-muted-foreground">All our templates pass applicant tracking systems</p>
                </div>
              </div>
              
              <div className="grid grid-cols-3 gap-2 mt-2">
                <div className="text-center text-sm p-2 rounded-lg bg-background border shadow-sm">
                  <div className="font-semibold">60+</div>
                  <div className="text-xs text-muted-foreground">Templates</div>
                </div>
                <div className="text-center text-sm p-2 rounded-lg bg-background border shadow-sm">
                  <div className="font-semibold">2M+</div>
                  <div className="text-xs text-muted-foreground">Users</div>
                </div>
                <div className="text-center text-sm p-2 rounded-lg bg-background border shadow-sm">
                  <div className="font-semibold">4.8</div>
                  <div className="text-xs text-muted-foreground">Rating</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}