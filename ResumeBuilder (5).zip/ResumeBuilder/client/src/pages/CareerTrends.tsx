import { useState } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Helmet } from 'react-helmet';
import { Loader2, TrendingUp, Star, Clock, ArrowRight, ChevronDown, ChevronUp, BarChart3 } from 'lucide-react';
import { Redirect } from 'wouter';

// UI Components
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { 
  Card, 
  CardHeader, 
  CardTitle, 
  CardDescription, 
  CardContent, 
  CardFooter 
} from '@/components/ui/card';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';

// Career trend types
type TrendInsight = {
  trendName: string;
  description: string;
  impactLevel: 'High' | 'Medium' | 'Low';
  timeframe: 'Current' | 'Emerging' | 'Future';
  relevantSkills: string[];
  industries: string[];
  demandMetric: number;
  recommendedActions: string[];
};

type CareerTrendReport = {
  industryOverview: string;
  topTrends: TrendInsight[];
  skillsAnalysis: {
    inDemandSkills: string[];
    decliningSkills: string[];
    emergingSkills: string[];
  };
  salaryTrends: {
    overview: string;
    ranges: {
      role: string;
      range: string;
      growth: string;
    }[];
  };
  recommendations: {
    shortTerm: string[];
    longTerm: string[];
  };
};

// Form schema
const formSchema = z.object({
  industry: z.string().min(1, 'Industry is required'),
  jobTitle: z.string().min(1, 'Job title is required'),
  skills: z.string().min(1, 'At least one skill is required'),
  location: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

// Impact level color mapping
const getImpactColor = (level: string) => {
  switch (level) {
    case 'High':
      return 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400';
    case 'Medium':
      return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400';
    case 'Low':
      return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400';
    default:
      return 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400';
  }
};

// Timeframe color mapping
const getTimeframeColor = (timeframe: string) => {
  switch (timeframe) {
    case 'Current':
      return 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400';
    case 'Emerging':
      return 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400';
    case 'Future':
      return 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-400';
    default:
      return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-400';
  }
};

export default function CareerTrends() {
  const { user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const [reportData, setReportData] = useState<CareerTrendReport | null>(null);
  const [showForm, setShowForm] = useState(true);

  // Define form
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      industry: '',
      jobTitle: '',
      skills: '',
      location: '',
    },
  });

  // Career trend mutation
  const trendMutation = useMutation({
    mutationFn: async (values: FormValues) => {
      const res = await apiRequest('POST', '/api/ai/career-trends', {
        industry: values.industry,
        jobTitle: values.jobTitle,
        skills: values.skills.split(',').map(s => s.trim()),
        location: values.location || undefined,
      });
      
      return res.json();
    },
    onSuccess: (data) => {
      setReportData(data);
      setShowForm(false);
      toast({
        title: 'Career trends report generated',
        description: 'Your personalized market insights are ready!',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error generating report',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Submit handler
  const onSubmit = (values: FormValues) => {
    trendMutation.mutate(values);
  };

  // Loading states
  const isLoading = authLoading || trendMutation.isPending;

  // Redirect if not authenticated
  if (!authLoading && !user) {
    return <Redirect to="/auth" />;
  }

  return (
    <div className="container py-10 max-w-7xl">
      <Helmet>
        <title>Career Trend Insights | ResumeX</title>
        <meta name="description" content="Get AI-powered career market insights based on your industry, skills, and job goals." />
      </Helmet>

      <div className="flex flex-col gap-6">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">Career Trend Insights</h1>
          <p className="text-muted-foreground">
            Get AI-powered market insights tailored to your career path and skills.
          </p>
        </div>

        <Separator />

        {isLoading && (
          <div className="flex items-center justify-center py-20">
            <div className="flex flex-col items-center gap-2">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p className="text-sm text-muted-foreground">Analyzing market trends...</p>
            </div>
          </div>
        )}

        {!isLoading && showForm && (
          <Card>
            <CardHeader>
              <CardTitle>Generate Your Career Trend Report</CardTitle>
              <CardDescription>
                Enter your professional details to receive a personalized analysis of current market trends.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                    <FormField
                      control={form.control}
                      name="industry"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Industry</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. Technology, Healthcare, Finance" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="jobTitle"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Current or Target Job Title</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. Software Engineer, Marketing Manager" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="skills"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Skills (comma-separated)</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. JavaScript, Project Management, Data Analysis" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Location (optional)</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. New York, United States, Global" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <Button type="submit" className="w-full" disabled={isLoading}>
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <TrendingUp className="mr-2 h-4 w-4" />
                        Generate Insights
                      </>
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        )}

        {!isLoading && reportData && !showForm && (
          <div className="space-y-8">
            <div className="flex justify-end">
              <Button variant="outline" onClick={() => setShowForm(true)}>
                Modify Search
              </Button>
            </div>

            {/* Industry Overview */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="mr-2 h-5 w-5" />
                  Industry Overview
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{reportData.industryOverview}</p>
              </CardContent>
            </Card>

            {/* Top Trends */}
            <div>
              <h2 className="text-2xl font-bold mb-4">Top Market Trends</h2>
              <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
                {reportData.topTrends.map((trend, index) => (
                  <Card key={index} className="overflow-hidden">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-xl">{trend.trendName}</CardTitle>
                        <div className="flex gap-2">
                          <Badge className={getImpactColor(trend.impactLevel)}>
                            {trend.impactLevel} Impact
                          </Badge>
                          <Badge className={getTimeframeColor(trend.timeframe)}>
                            {trend.timeframe}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="pb-3">
                      <p className="text-muted-foreground mb-4">{trend.description}</p>
                      
                      <div className="mb-4">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-medium">Demand Level</span>
                          <span className="text-sm">{trend.demandMetric}%</span>
                        </div>
                        <Progress value={trend.demandMetric} className="h-2" />
                      </div>
                      
                      <div className="space-y-3">
                        <div>
                          <h4 className="text-sm font-semibold mb-1">Relevant Skills</h4>
                          <div className="flex flex-wrap gap-1">
                            {trend.relevantSkills.map((skill, i) => (
                              <Badge key={i} variant="outline">{skill}</Badge>
                            ))}
                          </div>
                        </div>
                        
                        <div>
                          <h4 className="text-sm font-semibold mb-1">Industries Affected</h4>
                          <div className="flex flex-wrap gap-1">
                            {trend.industries.map((industry, i) => (
                              <Badge key={i} variant="secondary">{industry}</Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter className="bg-muted/50 pt-3">
                      <div className="w-full">
                        <h4 className="text-sm font-semibold mb-2">Recommended Actions</h4>
                        <ul className="text-sm space-y-1">
                          {trend.recommendedActions.map((action, i) => (
                            <li key={i} className="flex">
                              <ArrowRight className="h-4 w-4 mr-2 mt-0.5 flex-shrink-0 text-primary" />
                              <span>{action}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </div>

            {/* Skills Analysis */}
            <Card>
              <CardHeader>
                <CardTitle>Skills Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="inDemand">
                  <TabsList className="w-full md:w-auto mb-6">
                    <TabsTrigger value="inDemand" className="flex-1">In-Demand Skills</TabsTrigger>
                    <TabsTrigger value="emerging" className="flex-1">Emerging Skills</TabsTrigger>
                    <TabsTrigger value="declining" className="flex-1">Declining Skills</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="inDemand">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {reportData.skillsAnalysis.inDemandSkills.map((skill, i) => (
                        <div key={i} className="flex items-center p-3 border rounded-lg bg-green-50 dark:bg-green-900/20">
                          <Star className="h-4 w-4 mr-2 text-green-600 dark:text-green-400" />
                          <span>{skill}</span>
                        </div>
                      ))}
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="emerging">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {reportData.skillsAnalysis.emergingSkills.map((skill, i) => (
                        <div key={i} className="flex items-center p-3 border rounded-lg bg-blue-50 dark:bg-blue-900/20">
                          <TrendingUp className="h-4 w-4 mr-2 text-blue-600 dark:text-blue-400" />
                          <span>{skill}</span>
                        </div>
                      ))}
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="declining">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {reportData.skillsAnalysis.decliningSkills.map((skill, i) => (
                        <div key={i} className="flex items-center p-3 border rounded-lg bg-amber-50 dark:bg-amber-900/20">
                          <Clock className="h-4 w-4 mr-2 text-amber-600 dark:text-amber-400" />
                          <span>{skill}</span>
                        </div>
                      ))}
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>

            {/* Salary Trends */}
            <div>
              <h2 className="text-2xl font-bold mb-4">Salary Trends</h2>
              <Card>
                <CardHeader>
                  <CardDescription className="text-base">
                    {reportData.salaryTrends.overview}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left py-3 px-4">Role</th>
                          <th className="text-left py-3 px-4">Salary Range</th>
                          <th className="text-left py-3 px-4">Growth</th>
                        </tr>
                      </thead>
                      <tbody>
                        {reportData.salaryTrends.ranges.map((salary, i) => (
                          <tr key={i} className="border-b last:border-0">
                            <td className="py-3 px-4 font-medium">{salary.role}</td>
                            <td className="py-3 px-4">{salary.range}</td>
                            <td className="py-3 px-4">{salary.growth}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recommendations */}
            <div>
              <h2 className="text-2xl font-bold mb-4">Personalized Recommendations</h2>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="shortTerm">
                  <AccordionTrigger className="text-xl">Short-Term Actions</AccordionTrigger>
                  <AccordionContent>
                    <ul className="space-y-3 pl-1">
                      {reportData.recommendations.shortTerm.map((rec, i) => (
                        <li key={i} className="flex items-start">
                          <div className="flex-shrink-0 h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center mt-0.5 mr-3">
                            <span className="text-sm font-medium text-primary">{i + 1}</span>
                          </div>
                          <span>{rec}</span>
                        </li>
                      ))}
                    </ul>
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="longTerm">
                  <AccordionTrigger className="text-xl">Long-Term Strategy</AccordionTrigger>
                  <AccordionContent>
                    <ul className="space-y-3 pl-1">
                      {reportData.recommendations.longTerm.map((rec, i) => (
                        <li key={i} className="flex items-start">
                          <div className="flex-shrink-0 h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center mt-0.5 mr-3">
                            <span className="text-sm font-medium text-primary">{i + 1}</span>
                          </div>
                          <span>{rec}</span>
                        </li>
                      ))}
                    </ul>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </div>
            
            {/* Final call to action */}
            <Card className="bg-gradient-to-br from-primary/20 via-primary/10 to-background border-primary/20">
              <CardContent className="pt-6">
                <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Ready to update your resume?</h3>
                    <p className="text-muted-foreground">Apply these insights to your resume and stand out to employers.</p>
                  </div>
                  <Button size="lg" className="whitespace-nowrap">
                    Update Resume Now
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}