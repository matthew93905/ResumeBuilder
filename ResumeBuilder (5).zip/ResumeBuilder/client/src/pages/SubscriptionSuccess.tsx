import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function SubscriptionSuccess() {
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const [subscriptionStatus, setSubscriptionStatus] = useState<"success" | "processing" | "error">("processing");
  
  useEffect(() => {
    // In a real app, you would verify the subscription status with your server
    // For demo purposes, we'll just simulate a successful subscription
    const timer = setTimeout(() => {
      setSubscriptionStatus("success");
      toast({
        title: "Subscription Activated",
        description: "Your premium subscription is now active.",
      });
    }, 1500);
    
    return () => clearTimeout(timer);
  }, [toast]);
  
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-accent/20">
      <div className="w-full max-w-md bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 text-center">
        {subscriptionStatus === "processing" ? (
          <>
            <div className="mb-6 w-20 h-20 rounded-full bg-blue-100 mx-auto flex items-center justify-center">
              <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
            </div>
            <h1 className="text-2xl font-bold mb-2">Activating Subscription</h1>
            <p className="text-muted-foreground mb-6">Please wait while we set up your premium account...</p>
          </>
        ) : subscriptionStatus === "success" ? (
          <>
            <div className="mb-6">
              <div className="w-20 h-20 rounded-full bg-green-100 mx-auto flex items-center justify-center">
                <CheckCircle className="w-10 h-10 text-green-500" />
              </div>
            </div>
            <h1 className="text-2xl font-bold mb-2">Welcome to Premium!</h1>
            <p className="text-muted-foreground mb-6">Your subscription has been successfully activated. You now have unlimited access to all premium features.</p>
            <div className="space-y-3">
              <Button asChild className="w-full bg-gradient-to-r from-secondary to-primary">
                <Link href="/builder">
                  <span>Start Creating Premium Resumes</span>
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button asChild variant="outline" className="w-full">
                <Link href="/account">Manage Subscription</Link>
              </Button>
            </div>
          </>
        ) : (
          <>
            <div className="mb-6 w-20 h-20 rounded-full bg-red-100 mx-auto flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="w-10 h-10 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </div>
            <h1 className="text-2xl font-bold mb-2">Subscription Error</h1>
            <p className="text-muted-foreground mb-6">There was an issue activating your subscription. Please contact support.</p>
            <Button asChild className="w-full">
              <Link href="/subscribe">Try Again</Link>
            </Button>
          </>
        )}
      </div>
      
      {subscriptionStatus === "success" && (
        <div className="mt-8 max-w-md">
          <h2 className="text-lg font-semibold mb-3 text-center">Your Premium Benefits:</h2>
          <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow border border-border">
            <div className="space-y-4">
              <div className="border-b border-border pb-3">
                <div className="text-sm text-muted-foreground">Your subscription plan</div>
                <div className="font-semibold">Premium Membership</div>
              </div>
              
              <div className="border-b border-border pb-3">
                <div className="text-sm text-muted-foreground">Status</div>
                <div className="font-semibold flex items-center">
                  <span className="h-2 w-2 rounded-full bg-green-500 mr-2"></span>
                  Active
                </div>
              </div>
              
              <div>
                <div className="text-sm text-muted-foreground mb-2">Included Features</div>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <svg className="h-5 w-5 text-green-500 mr-2 mt-0.5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span>Access to all premium resume templates</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="h-5 w-5 text-green-500 mr-2 mt-0.5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span>Unlimited resume exports to PDF</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="h-5 w-5 text-green-500 mr-2 mt-0.5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span>Cloud storage for all your created resumes</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="h-5 w-5 text-green-500 mr-2 mt-0.5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span>Priority customer support</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="h-5 w-5 text-green-500 mr-2 mt-0.5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span>Early access to new features and templates</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}