import { Switch, Route, useLocation } from "wouter";
import { useEffect } from "react";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { HelmetProvider } from "react-helmet-async";
import RouteSEO from "@/components/RouteSEO";
import JsonLdSchema from "@/components/JsonLdSchema";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Builder from "@/pages/Builder";
import ResumeList from "@/pages/ResumeList";
import Checkout from "@/pages/Checkout";
import CheckoutSuccess from "@/pages/CheckoutSuccess";
import Subscribe from "@/pages/Subscribe";
import SubscriptionSuccess from "@/pages/SubscriptionSuccess";
import CareerExplorer from "@/pages/CareerExplorer";
import CareerTrends from "@/pages/CareerTrends"; 
import CareerPathVisualizationPage from "@/pages/CareerPathVisualizationPage";
import AdminDashboard from "@/pages/AdminDashboard";
import Blog from "@/pages/Blog";
import BlogPost from "@/pages/BlogPost";
import CoverLetterBuilder from "@/pages/CoverLetterBuilder";
import CollaborativeEditor from "@/pages/CollaborativeEditor";
import AuthPage from "@/pages/AuthPage";
import HelpCenter from "@/pages/HelpCenter";
import SocialLanding from "@/pages/SocialLanding";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import FloatingThemeToggle from "@/components/FloatingThemeToggle";

import { ResumeProvider } from "@/hooks/use-resume";
import { ThemeProvider } from "@/hooks/use-theme";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/ProtectedRoute";
import { initAnalytics, trackPageView, cleanupAnalytics } from "@/lib/analytics";
import TrackingManager from "@/components/TrackingManager";

function TrackingWrapper() {
  const [location] = useLocation();
  
  // Initialize analytics on first render
  useEffect(() => {
    try {
      initAnalytics();
    } catch (error) {
      console.error("Failed to initialize analytics:", error);
    }
    
    return () => {
      try {
        cleanupAnalytics();
      } catch (error) {
        console.error("Failed to cleanup analytics:", error);
      }
    };
  }, []);
  
  // Track page views when location changes
  useEffect(() => {
    try {
      trackPageView(location);
    } catch (error) {
      console.error("Failed to track page view:", error);
    }
  }, [location]);
  
  return null;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <ProtectedRoute path="/builder" component={Builder} />
      <ProtectedRoute path="/resumes" component={ResumeList} />
      <ProtectedRoute path="/career-explorer" component={CareerExplorer} />
      <ProtectedRoute path="/career-trends" component={CareerTrends} />
      <ProtectedRoute path="/career-paths" component={CareerPathVisualizationPage} />
      <ProtectedRoute path="/checkout" component={Checkout} />
      <ProtectedRoute path="/checkout-success" component={CheckoutSuccess} />
      <ProtectedRoute path="/subscribe" component={Subscribe} />
      <ProtectedRoute path="/subscription-success" component={SubscriptionSuccess} />
      <ProtectedRoute path="/admin" component={AdminDashboard} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/blog" component={Blog} />
      <Route path="/blog/:slug" component={BlogPost} />
      <Route path="/help" component={HelpCenter} />
      <Route path="/social-landing" component={SocialLanding} />
      <ProtectedRoute path="/cover-letter" component={CoverLetterBuilder} />
      <ProtectedRoute path="/collaborate/:id" component={CollaborativeEditor} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  // Website-wide schema for organization information
  const organizationSchema = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "ResumeX",
    "url": "https://resumex.replit.app/",
    "logo": "https://resumex.replit.app/logo.png",
    "description": "Modern, professional resume builder with AI-powered tools and multiple templates",
    "sameAs": [
      "https://twitter.com/resumex",
      "https://www.facebook.com/resumex",
      "https://www.linkedin.com/company/resumex"
    ],
    "contactPoint": {
      "@type": "ContactPoint",
      "telephone": "+1-800-123-4567",
      "contactType": "customer service",
      "email": "support@resumex.com"
    }
  };
  
  // Website schema for sitewide information
  const websiteSchema = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "name": "ResumeX - Professional Resume Builder",
    "url": "https://resumex.replit.app/",
    "potentialAction": {
      "@type": "SearchAction",
      "target": "https://resumex.replit.app/search?q={search_term_string}",
      "query-input": "required name=search_term_string"
    },
    "description": "Create standout resumes with ResumeX. Choose from professional templates, use AI tools to improve content, and get hired faster."
  };
  
  // Software application schema for app info
  const applicationSchema = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    "name": "ResumeX Resume Builder",
    "applicationCategory": "BusinessApplication",
    "offers": {
      "@type": "Offer",
      "price": "0",
      "priceCurrency": "USD"
    },
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "4.8",
      "ratingCount": "2430"
    }
  };

  return (
    <HelmetProvider>
      <QueryClientProvider client={queryClient}>
        <ThemeProvider>
          <AuthProvider>
            <TooltipProvider>
              <ResumeProvider>
                <RouteSEO 
                  title="ResumeX - Build a Professional Resume in Minutes"
                  description="Create a professional resume with our easy-to-use builder. Choose from multiple templates and download your resume instantly."
                  keywords={["resume builder", "CV creator", "professional templates", "resume templates", "job application"]}
                />
                <JsonLdSchema schema={[organizationSchema, websiteSchema, applicationSchema]} />
                <Toaster />
                <TrackingWrapper />
                <TrackingManager />
                <div className="flex flex-col min-h-screen">
                  <Header />
                  <main className="flex-grow">
                    <Router />
                  </main>
                  <Footer />
                  <FloatingThemeToggle />
                </div>
              </ResumeProvider>
            </TooltipProvider>
          </AuthProvider>
        </ThemeProvider>
      </QueryClientProvider>
    </HelmetProvider>
  );
}

export default App;
