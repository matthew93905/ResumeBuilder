import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from './use-toast';

// Hooks for collaborative resume editing feature

// Types
export type CollaboratorWithUser = {
  id: number;
  resumeId: number;
  userId: number;
  role: string;
  createdAt: string;
  updatedAt: string;
  user: {
    id: number;
    username: string;
    email: string;
    fullName: string | null;
  } | null;
};

export type CommentWithUser = {
  id: number;
  resumeId: number;
  userId: number;
  content: string;
  section: string | null;
  resolved: boolean;
  createdAt: string;
  updatedAt: string;
  user: {
    id: number;
    username: string;
    email: string;
    fullName: string | null;
  } | null;
};

export type Invitation = {
  id: number;
  resumeId: number;
  invitedByUserId: number;
  email: string;
  role: string;
  token: string;
  accepted: boolean;
  expiresAt: string;
  createdAt: string;
  updatedAt: string;
};

export type Notification = {
  id: number;
  userId: number;
  type: string;
  content: string;
  relatedId: number | null;
  read: boolean;
  createdAt: string;
};

// Hooks

// Get collaborators for a resume
export function useCollaborators(resumeId: number | null) {
  return useQuery({
    queryKey: ['/api/resume', resumeId, 'collaborators'],
    queryFn: async () => {
      if (!resumeId) return [];
      const res = await apiRequest('GET', `/api/resume/${resumeId}/collaborators`);
      return res.json();
    },
    enabled: !!resumeId
  });
}

// Add a collaborator to a resume
export function useAddCollaborator(resumeId: number | null) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (data: { username: string; role: string }) => {
      if (!resumeId) throw new Error('Resume ID is required');
      const res = await apiRequest('POST', `/api/resume/${resumeId}/collaborators`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/resume', resumeId, 'collaborators'] });
      toast({
        title: 'Collaborator added',
        description: 'The user has been added as a collaborator',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to add collaborator',
        description: error.message,
        variant: 'destructive',
      });
    }
  });
}

// Update collaborator role
export function useUpdateCollaboratorRole() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({ id, role, resumeId }: { id: number; role: string; resumeId: number }) => {
      const res = await apiRequest('PUT', `/api/collaborator/${id}`, { role });
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['/api/resume', variables.resumeId, 'collaborators'] });
      toast({
        title: 'Collaborator role updated',
        description: `Role has been updated to ${variables.role}`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to update role',
        description: error.message,
        variant: 'destructive',
      });
    }
  });
}

// Remove a collaborator
export function useRemoveCollaborator() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({ id, resumeId }: { id: number; resumeId: number }) => {
      await apiRequest('DELETE', `/api/collaborator/${id}`);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['/api/resume', variables.resumeId, 'collaborators'] });
      toast({
        title: 'Collaborator removed',
        description: 'The collaborator has been removed',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to remove collaborator',
        description: error.message,
        variant: 'destructive',
      });
    }
  });
}

// Get comments for a resume
export function useComments(resumeId: number | null) {
  return useQuery({
    queryKey: ['/api/resume', resumeId, 'comments'],
    queryFn: async () => {
      if (!resumeId) return [];
      const res = await apiRequest('GET', `/api/resume/${resumeId}/comments`);
      return res.json();
    },
    enabled: !!resumeId
  });
}

// Add a comment to a resume
export function useAddComment(resumeId: number | null) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (data: { content: string; section?: string }) => {
      if (!resumeId) throw new Error('Resume ID is required');
      const res = await apiRequest('POST', `/api/resume/${resumeId}/comments`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/resume', resumeId, 'comments'] });
      toast({
        title: 'Comment added',
        description: 'Your comment has been added',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to add comment',
        description: error.message,
        variant: 'destructive',
      });
    }
  });
}

// Resolve/unresolve a comment
export function useResolveComment() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({ id, resolved, resumeId }: { id: number; resolved: boolean; resumeId: number }) => {
      const res = await apiRequest('PUT', `/api/comment/${id}/resolve`, { resolved });
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['/api/resume', variables.resumeId, 'comments'] });
      toast({
        title: variables.resolved ? 'Comment resolved' : 'Comment reopened',
        description: variables.resolved ? 'The comment has been marked as resolved' : 'The comment has been reopened',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to update comment',
        description: error.message,
        variant: 'destructive',
      });
    }
  });
}

// Delete a comment
export function useDeleteComment() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({ id, resumeId }: { id: number; resumeId: number }) => {
      await apiRequest('DELETE', `/api/comment/${id}`);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['/api/resume', variables.resumeId, 'comments'] });
      toast({
        title: 'Comment deleted',
        description: 'The comment has been deleted',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to delete comment',
        description: error.message,
        variant: 'destructive',
      });
    }
  });
}

// Generate a shareable link for a resume
export function useGenerateShareableLink() {
  const [isGenerating, setIsGenerating] = useState(false);
  const { toast } = useToast();
  
  const generateLink = async (resumeId: number): Promise<string | null> => {
    try {
      setIsGenerating(true);
      const res = await apiRequest('POST', `/api/resume/${resumeId}/share`);
      const data = await res.json();
      return data.shareableLink;
    } catch (error: any) {
      toast({
        title: 'Failed to generate link',
        description: error.message,
        variant: 'destructive',
      });
      return null;
    } finally {
      setIsGenerating(false);
    }
  };
  
  return { generateLink, isGenerating };
}

// Invite a collaborator by email
export function useInviteCollaborator(resumeId: number | null) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (data: { email: string; role: string }) => {
      if (!resumeId) throw new Error('Resume ID is required');
      const res = await apiRequest('POST', `/api/resume/${resumeId}/invite`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/resume', resumeId, 'invitations'] });
      toast({
        title: 'Invitation sent',
        description: 'The invitation has been sent to the user',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to send invitation',
        description: error.message,
        variant: 'destructive',
      });
    }
  });
}

// Get invitations for a resume
export function useInvitations(resumeId: number | null) {
  return useQuery({
    queryKey: ['/api/resume', resumeId, 'invitations'],
    queryFn: async () => {
      if (!resumeId) return [];
      const res = await apiRequest('GET', `/api/resume/${resumeId}/invitations`);
      return res.json();
    },
    enabled: !!resumeId
  });
}

// Delete an invitation
export function useDeleteInvitation() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({ id, resumeId }: { id: number; resumeId: number }) => {
      await apiRequest('DELETE', `/api/invitation/${id}`);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['/api/resume', variables.resumeId, 'invitations'] });
      toast({
        title: 'Invitation deleted',
        description: 'The invitation has been deleted',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to delete invitation',
        description: error.message,
        variant: 'destructive',
      });
    }
  });
}

// Accept an invitation
export function useAcceptInvitation() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (token: string) => {
      const res = await apiRequest('POST', `/api/invitation/${token}/accept`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/shared-with-me'] });
      toast({
        title: 'Invitation accepted',
        description: 'You are now a collaborator on this resume',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to accept invitation',
        description: error.message,
        variant: 'destructive',
      });
    }
  });
}

// Get all resumes shared with the current user
export function useSharedResumes() {
  return useQuery({
    queryKey: ['/api/shared-with-me'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/shared-with-me');
      return res.json();
    }
  });
}

// Get notifications
export function useNotifications() {
  return useQuery({
    queryKey: ['/api/notifications'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/notifications');
      return res.json();
    }
  });
}

// Get unread notification count
export function useUnreadNotificationCount() {
  return useQuery({
    queryKey: ['/api/notifications/unread/count'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/notifications/unread/count');
      const data = await res.json();
      return data.count;
    }
  });
}

// Mark notification as read
export function useMarkNotificationAsRead() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest('PUT', `/api/notification/${id}/read`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/notifications'] });
      queryClient.invalidateQueries({ queryKey: ['/api/notifications/unread/count'] });
    }
  });
}

// Mark all notifications as read
export function useMarkAllNotificationsAsRead() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async () => {
      const res = await apiRequest('PUT', '/api/notifications/read/all');
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/notifications'] });
      queryClient.invalidateQueries({ queryKey: ['/api/notifications/unread/count'] });
      toast({
        title: 'Notifications marked as read',
        description: 'All notifications have been marked as read',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to mark notifications as read',
        description: error.message,
        variant: 'destructive',
      });
    }
  });
}