import { useQuery, useMutation } from '@tanstack/react-query';
import { resumeApi, queryClient } from '@/lib/queryClient';
import { Resume } from '@shared/schema';

// Hook for loading resumes from the database for a specific user
export function useUserResumes(userId: number | null) {
  return useQuery({
    queryKey: [`/api/resumes/${userId}`],
    queryFn: () => {
      if (!userId) return Promise.resolve([]);
      return resumeApi.getResumesByUserId(userId);
    },
    enabled: !!userId, // Only run the query if we have a userId
  });
}

// Hook for loading a single resume by its ID
export function useResume(id: number | null) {
  return useQuery({
    queryKey: [`/api/resume/${id}`],
    queryFn: () => {
      if (!id) return Promise.resolve(null);
      return resumeApi.getResume(id);
    },
    enabled: !!id, // Only run the query if we have an ID
  });
}

// Hook for loading the default resume for a user
export function useDefaultResume(userId: number | null) {
  const { data: resumes, isLoading, error } = useUserResumes(userId);
  
  // Find the default resume in the list
  const defaultResume = resumes?.find(resume => resume.isDefault) || null;
  
  return {
    defaultResume,
    isLoading,
    error
  };
}

// Hook for deleting a resume
export function useDeleteResume(userId: number | null) {
  return useMutation({
    mutationFn: async (resumeId: number) => {
      return resumeApi.deleteResume(resumeId);
    },
    onSuccess: () => {
      // Invalidate the resume list query to trigger a refetch
      if (userId) {
        queryClient.invalidateQueries({ queryKey: [`/api/resumes/${userId}`] });
      }
    },
  });
}