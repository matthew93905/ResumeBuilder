import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

// Types for collaboration data
export interface CollaboratorWithUser {
  id: number;
  resumeId: number;
  userId: number;
  role: string;
  createdAt: string;
  updatedAt: string;
  user?: {
    id: number;
    username: string;
    email: string;
  };
}

export interface Invitation {
  id: number;
  resumeId: number;
  email: string;
  role: string;
  accepted: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CommentWithUser {
  id: number;
  resumeId: number;
  userId: number;
  content: string;
  section: string | null;
  resolved: boolean;
  createdAt: string;
  updatedAt: string;
  user?: {
    id: number;
    username: string;
    email: string;
  };
}

// Function to get collaborators for a resume
export function useCollaborators(resumeId: number | null) {
  return useQuery({
    queryKey: ['/api/collaborators', resumeId],
    queryFn: async () => {
      if (!resumeId) return [];
      const res = await apiRequest('GET', `/api/resumes/${resumeId}/collaborators`);
      return await res.json();
    },
    enabled: !!resumeId,
  });
}

// Function to get invitations for a resume
export function useInvitations(resumeId: number | null) {
  return useQuery({
    queryKey: ['/api/invitations', resumeId],
    queryFn: async () => {
      if (!resumeId) return [];
      const res = await apiRequest('GET', `/api/resumes/${resumeId}/invitations`);
      return await res.json();
    },
    enabled: !!resumeId,
  });
}

// Function to add a collaborator to a resume
export function useAddCollaborator() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({ 
      resumeId, 
      username, 
      role 
    }: { 
      resumeId: number; 
      username: string; 
      role: string;
    }) => {
      const res = await apiRequest('POST', `/api/resumes/${resumeId}/collaborators`, {
        username,
        role,
      });
      return await res.json();
    },
    onSuccess: (_, { resumeId }) => {
      queryClient.invalidateQueries({ queryKey: ['/api/collaborators', resumeId] });
      toast({
        title: 'Collaborator added',
        description: 'User has been added to this resume',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to add collaborator',
        description: error.message || 'Something went wrong',
        variant: 'destructive',
      });
    },
  });
}

// Function to update a collaborator's role
export function useUpdateCollaboratorRole() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({ 
      id, 
      role, 
      resumeId 
    }: { 
      id: number; 
      role: string; 
      resumeId: number;
    }) => {
      const res = await apiRequest('PATCH', `/api/collaborators/${id}`, { role });
      return await res.json();
    },
    onSuccess: (_, { resumeId }) => {
      queryClient.invalidateQueries({ queryKey: ['/api/collaborators', resumeId] });
      toast({
        title: 'Role updated',
        description: 'Collaborator role has been updated',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to update role',
        description: error.message || 'Something went wrong',
        variant: 'destructive',
      });
    },
  });
}

// Function to remove a collaborator
export function useRemoveCollaborator() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({ 
      id, 
      resumeId 
    }: { 
      id: number; 
      resumeId: number;
    }) => {
      await apiRequest('DELETE', `/api/collaborators/${id}`);
    },
    onSuccess: (_, { resumeId }) => {
      queryClient.invalidateQueries({ queryKey: ['/api/collaborators', resumeId] });
      toast({
        title: 'Collaborator removed',
        description: 'User has been removed from this resume',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to remove collaborator',
        description: error.message || 'Something went wrong',
        variant: 'destructive',
      });
    },
  });
}

// Function to invite a collaborator via email
export function useInviteCollaborator() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({ 
      resumeId, 
      email, 
      role 
    }: { 
      resumeId: number; 
      email: string; 
      role: string;
    }) => {
      const res = await apiRequest('POST', `/api/resumes/${resumeId}/invitations`, {
        email,
        role,
      });
      return await res.json();
    },
    onSuccess: (_, { resumeId, email }) => {
      queryClient.invalidateQueries({ queryKey: ['/api/invitations', resumeId] });
      toast({
        title: 'Invitation sent',
        description: `Invitation has been sent to ${email}`,
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to send invitation',
        description: error.message || 'Something went wrong',
        variant: 'destructive',
      });
    },
  });
}

// Function to delete an invitation
export function useDeleteInvitation() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({ 
      id, 
      resumeId 
    }: { 
      id: number; 
      resumeId: number;
    }) => {
      await apiRequest('DELETE', `/api/invitations/${id}`);
    },
    onSuccess: (_, { resumeId }) => {
      queryClient.invalidateQueries({ queryKey: ['/api/invitations', resumeId] });
      toast({
        title: 'Invitation deleted',
        description: 'Invitation has been removed',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to delete invitation',
        description: error.message || 'Something went wrong',
        variant: 'destructive',
      });
    },
  });
}

// Function to get comments for a resume
export function useComments(resumeId: number | null) {
  return useQuery({
    queryKey: ['/api/comments', resumeId],
    queryFn: async () => {
      if (!resumeId) return [];
      const res = await apiRequest('GET', `/api/resumes/${resumeId}/comments`);
      return await res.json();
    },
    enabled: !!resumeId,
  });
}

// Function to add a comment
export function useAddComment() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({ 
      resumeId, 
      content, 
      section 
    }: { 
      resumeId: number | null; 
      content: string; 
      section?: string;
    }) => {
      if (!resumeId) throw new Error('Resume ID is required');
      
      const res = await apiRequest('POST', `/api/resumes/${resumeId}/comments`, {
        content,
        section,
      });
      return await res.json();
    },
    onSuccess: (_, { resumeId }) => {
      if (resumeId) {
        queryClient.invalidateQueries({ queryKey: ['/api/comments', resumeId] });
      }
      toast({
        title: 'Comment added',
        description: 'Your comment has been added',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to add comment',
        description: error.message || 'Something went wrong',
        variant: 'destructive',
      });
    },
  });
}

// Function to resolve/unresolve a comment
export function useResolveComment() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({ 
      id, 
      resolved, 
      resumeId 
    }: { 
      id: number; 
      resolved: boolean; 
      resumeId: number;
    }) => {
      const res = await apiRequest('PATCH', `/api/comments/${id}`, { resolved });
      return await res.json();
    },
    onSuccess: (_, { resumeId, resolved }) => {
      queryClient.invalidateQueries({ queryKey: ['/api/comments', resumeId] });
      toast({
        title: resolved ? 'Comment resolved' : 'Comment reopened',
        description: resolved 
          ? 'Comment has been marked as resolved' 
          : 'Comment has been reopened',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to update comment',
        description: error.message || 'Something went wrong',
        variant: 'destructive',
      });
    },
  });
}

// Function to delete a comment
export function useDeleteComment() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({ 
      id, 
      resumeId 
    }: { 
      id: number; 
      resumeId: number;
    }) => {
      await apiRequest('DELETE', `/api/comments/${id}`);
    },
    onSuccess: (_, { resumeId }) => {
      queryClient.invalidateQueries({ queryKey: ['/api/comments', resumeId] });
      toast({
        title: 'Comment deleted',
        description: 'Your comment has been deleted',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to delete comment',
        description: error.message || 'Something went wrong',
        variant: 'destructive',
      });
    },
  });
}

// Functions for notifications

// Interface for notifications
export interface Notification {
  id: number;
  userId: number;
  content: string;
  type: string;
  relatedId?: number;
  read: boolean;
  createdAt: string;
  updatedAt: string;
}

// Get all notifications for current user
export function useNotifications() {
  return useQuery({
    queryKey: ['/api/notifications'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/notifications');
      return await res.json();
    },
  });
}

// Get count of unread notifications
export function useUnreadNotificationCount() {
  return useQuery({
    queryKey: ['/api/notifications/unread/count'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/notifications/unread/count');
      const data = await res.json();
      return data.count;
    },
  });
}

// Mark a notification as read
export function useMarkNotificationAsRead() {
  return useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('PATCH', `/api/notifications/${id}`, { read: true });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/notifications'] });
      queryClient.invalidateQueries({ queryKey: ['/api/notifications/unread/count'] });
    },
  });
}

// Mark all notifications as read
export function useMarkAllNotificationsAsRead() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async () => {
      await apiRequest('POST', '/api/notifications/mark-all-read');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/notifications'] });
      queryClient.invalidateQueries({ queryKey: ['/api/notifications/unread/count'] });
      toast({
        title: 'Notifications cleared',
        description: 'All notifications marked as read',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to mark notifications as read',
        description: error.message || 'Something went wrong',
        variant: 'destructive',
      });
    },
  });
}