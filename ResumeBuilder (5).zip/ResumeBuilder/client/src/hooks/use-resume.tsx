import React, { createContext, useContext, useEffect, useState } from 'react';

// Resume data types
export interface PersonalInfo {
  name: string;
  jobTitle: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zip: string;
  linkedin: string;
  website: string;
  photo: string | null;
}

export interface Summary {
  content: string;
}

export interface Experience {
  id: string;
  company: string;
  position: string;
  location: string;
  startDate: string;
  endDate: string;
  current: boolean;
  description: string[];
}

export interface Education {
  id: string;
  institution: string;
  degree: string;
  field: string;
  location: string;
  startDate: string;
  endDate: string;
  description: string;
}

export interface Skill {
  id: string;
  name: string;
}

export interface ResumeData {
  personalInfo: PersonalInfo;
  summary: Summary;
  experience: Experience[];
  education: Education[];
  skills: Skill[];
  templateId: string;
}

const defaultPersonalInfo: PersonalInfo = {
  name: 'John Anderson',
  jobTitle: 'Senior Product Designer',
  email: 'john.anderson@example.com',
  phone: '(555) 123-4567',
  address: '123 Main Street',
  city: 'New York',
  state: 'NY',
  zip: '10001',
  linkedin: 'linkedin.com/in/johnanderson',
  website: 'johnanderson.design',
  photo: null
};

const defaultSummary: Summary = {
  content: 'Experienced Product Designer with over 8 years of experience creating user-centered digital experiences for top-tier companies. Specialized in UI/UX design, design systems, and product strategy.'
};

const defaultExperience: Experience[] = [
  {
    id: '1',
    company: 'Design Company Inc.',
    position: 'Senior Product Designer',
    location: 'New York',
    startDate: '2019-01',
    endDate: '',
    current: true,
    description: [
      'Led design for flagship product, increasing user engagement by 45%',
      'Created and maintained component library used by 20+ designers',
      'Conducted user research and usability testing for new features'
    ]
  },
  {
    id: '2',
    company: 'Tech Solutions LLC',
    position: 'UX Designer',
    location: 'San Francisco',
    startDate: '2016-05',
    endDate: '2018-12',
    current: false,
    description: [
      'Designed user flows and wireframes for mobile applications',
      'Collaborated with developers to implement pixel-perfect designs'
    ]
  }
];

const defaultEducation: Education[] = [
  {
    id: '1',
    institution: 'Rhode Island School of Design',
    degree: 'Bachelor of Fine Arts',
    field: 'Graphic Design',
    location: 'Providence, RI',
    startDate: '2012-09',
    endDate: '2016-05',
    description: ''
  }
];

const defaultSkills: Skill[] = [
  { id: '1', name: 'UI Design' },
  { id: '2', name: 'UX Research' },
  { id: '3', name: 'Figma' },
  { id: '4', name: 'Adobe CC' },
  { id: '5', name: 'Prototyping' },
  { id: '6', name: 'Design Systems' },
  { id: '7', name: 'User Testing' },
  { id: '8', name: 'HTML/CSS' }
];

const defaultResumeData: ResumeData = {
  personalInfo: defaultPersonalInfo,
  summary: defaultSummary,
  experience: defaultExperience,
  education: defaultEducation,
  skills: defaultSkills,
  templateId: 'essential'
};

interface ResumeContextType {
  resumeData: ResumeData;
  updatePersonalInfo: (data: Partial<PersonalInfo>) => void;
  updateSummary: (data: Summary) => void;
  addExperience: (exp: Omit<Experience, 'id'>) => void;
  updateExperience: (id: string, exp: Partial<Experience>) => void;
  removeExperience: (id: string) => void;
  addEducation: (edu: Omit<Education, 'id'>) => void;
  updateEducation: (id: string, edu: Partial<Education>) => void;
  removeEducation: (id: string) => void;
  addSkill: (skill: Omit<Skill, 'id'>) => void;
  removeSkill: (id: string) => void;
  setTemplateId: (id: string) => void;
  resetResume: () => void;
  activeSection: string;
  setActiveSection: (section: string) => void;
}

const ResumeContext = createContext<ResumeContextType | undefined>(undefined);

export function ResumeProvider({ children }: { children: React.ReactNode }) {
  const [resumeData, setResumeData] = useState<ResumeData>(() => {
    const saved = localStorage.getItem('resumeData');
    return saved ? JSON.parse(saved) : defaultResumeData;
  });
  
  const [activeSection, setActiveSection] = useState<string>('personal');

  // Save to localStorage whenever data changes
  useEffect(() => {
    localStorage.setItem('resumeData', JSON.stringify(resumeData));
  }, [resumeData]);

  const updatePersonalInfo = (data: Partial<PersonalInfo>) => {
    setResumeData(prev => ({
      ...prev,
      personalInfo: {
        ...prev.personalInfo,
        ...data
      }
    }));
  };

  const updateSummary = (data: Summary) => {
    setResumeData(prev => ({
      ...prev,
      summary: data
    }));
  };

  const addExperience = (exp: Omit<Experience, 'id'>) => {
    const newExp: Experience = {
      ...exp,
      id: Date.now().toString()
    };
    setResumeData(prev => ({
      ...prev,
      experience: [...prev.experience, newExp]
    }));
  };

  const updateExperience = (id: string, exp: Partial<Experience>) => {
    setResumeData(prev => ({
      ...prev,
      experience: prev.experience.map(item => 
        item.id === id ? { ...item, ...exp } : item
      )
    }));
  };

  const removeExperience = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      experience: prev.experience.filter(item => item.id !== id)
    }));
  };

  const addEducation = (edu: Omit<Education, 'id'>) => {
    const newEdu: Education = {
      ...edu,
      id: Date.now().toString()
    };
    setResumeData(prev => ({
      ...prev,
      education: [...prev.education, newEdu]
    }));
  };

  const updateEducation = (id: string, edu: Partial<Education>) => {
    setResumeData(prev => ({
      ...prev,
      education: prev.education.map(item => 
        item.id === id ? { ...item, ...edu } : item
      )
    }));
  };

  const removeEducation = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      education: prev.education.filter(item => item.id !== id)
    }));
  };

  const addSkill = (skill: Omit<Skill, 'id'>) => {
    const newSkill: Skill = {
      ...skill,
      id: Date.now().toString()
    };
    setResumeData(prev => ({
      ...prev,
      skills: [...prev.skills, newSkill]
    }));
  };

  const removeSkill = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      skills: prev.skills.filter(item => item.id !== id)
    }));
  };

  const setTemplateId = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      templateId: id
    }));
  };

  const resetResume = () => {
    setResumeData(defaultResumeData);
  };

  return (
    <ResumeContext.Provider
      value={{
        resumeData,
        updatePersonalInfo,
        updateSummary,
        addExperience,
        updateExperience,
        removeExperience,
        addEducation,
        updateEducation,
        removeEducation,
        addSkill,
        removeSkill,
        setTemplateId,
        resetResume,
        activeSection,
        setActiveSection
      }}
    >
      {children}
    </ResumeContext.Provider>
  );
}

export function useResume() {
  const context = useContext(ResumeContext);
  if (context === undefined) {
    throw new Error('useResume must be used within a ResumeProvider');
  }
  return context;
}