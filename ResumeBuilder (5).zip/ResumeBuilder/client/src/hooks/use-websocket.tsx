import { createContext, useContext, ReactNode } from 'react';
import { useCollabWebSocket, ActiveCollaborator, WebSocketMessage } from '@/lib/websocket';

// Create a context for WebSocket connection state
interface WebSocketContextType {
  connected: boolean;
  connectionError: string | null;
  activeCollaborators: ActiveCollaborator[];
  updateResume: (data: any) => boolean;
  updateCursor: (position: { section: string; field: string }) => boolean;
  sendMessage: (message: WebSocketMessage) => boolean;
}

// Fallback values for the context
const defaultWebSocketContext: WebSocketContextType = {
  connected: false,
  connectionError: null,
  activeCollaborators: [],
  updateResume: () => false,
  updateCursor: () => false,
  sendMessage: () => false
};

const WebSocketContext = createContext<WebSocketContextType>(defaultWebSocketContext);

// Provider component to wrap parts of the app that need WebSocket access
export function WebSocketProvider({ 
  children, 
  resumeId 
}: { 
  children: ReactNode; 
  resumeId: number | null;
}) {
  const websocketState = useCollabWebSocket(resumeId);
  
  return (
    <WebSocketContext.Provider value={websocketState}>
      {children}
    </WebSocketContext.Provider>
  );
}

// Hook to use the WebSocket context
export function useWebSocket() {
  const context = useContext(WebSocketContext);
  
  if (context === undefined) {
    throw new Error('useWebSocket must be used within a WebSocketProvider');
  }
  
  return context;
}