import { useMutation } from '@tanstack/react-query';
import { resumeApi } from '@/lib/queryClient';
import { queryClient } from '@/lib/queryClient';
import { ResumeData } from './use-resume';
import { useToast } from './use-toast';
import { InsertResume } from '@shared/schema';

interface SaveResumeOptions {
  userId: number;
  title: string;
  isDefault?: boolean;
}

// Hook for saving resumes to the database
export function useSaveResume() {
  const { toast } = useToast();
  
  // Create a mutation for saving a resume
  const saveMutation = useMutation({
    mutationFn: async ({ resumeData, options }: { resumeData: ResumeData, options: SaveResumeOptions }) => {
      const { userId, title, isDefault = false } = options;
      
      const insertData: InsertResume = {
        userId,
        title,
        data: resumeData,
        templateId: resumeData.templateId,
        isDefault
      };
      
      return resumeApi.createResume(insertData);
    },
    onSuccess: () => {
      // Invalidate the resumes query to refresh the list
      queryClient.invalidateQueries({ queryKey: ['/api/resumes'] });
      
      toast({
        title: "Resume Saved",
        description: "Your resume has been saved to your account."
      });
    },
    onError: (error) => {
      console.error('Error saving resume:', error);
      
      toast({
        title: "Save Failed",
        description: "There was an error saving your resume. Please try again.",
        variant: "destructive"
      });
    }
  });
  
  // Create a mutation for updating a resume
  const updateMutation = useMutation({
    mutationFn: async ({ id, resumeData, options }: { id: number, resumeData: ResumeData, options: Partial<SaveResumeOptions> }) => {
      const { title, isDefault } = options;
      
      const updateData: Partial<InsertResume> = {
        title,
        data: resumeData,
        templateId: resumeData.templateId,
        isDefault
      };
      
      return resumeApi.updateResume(id, updateData);
    },
    onSuccess: () => {
      // Invalidate the resumes query to refresh the list
      queryClient.invalidateQueries({ queryKey: ['/api/resumes'] });
      
      toast({
        title: "Resume Updated",
        description: "Your resume has been updated successfully."
      });
    },
    onError: (error) => {
      console.error('Error updating resume:', error);
      
      toast({
        title: "Update Failed",
        description: "There was an error updating your resume. Please try again.",
        variant: "destructive"
      });
    }
  });
  
  return {
    saveResume: saveMutation.mutate,
    updateResume: updateMutation.mutate,
    isSaving: saveMutation.isPending,
    isUpdating: updateMutation.isPending
  };
}