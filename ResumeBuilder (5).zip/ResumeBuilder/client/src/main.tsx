import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { StrictMode } from "react";

// Create a root element
const root = createRoot(document.getElementById("root")!);

// Render the app within StrictMode
root.render(
  <StrictMode>
    <App />
  </StrictMode>
);
