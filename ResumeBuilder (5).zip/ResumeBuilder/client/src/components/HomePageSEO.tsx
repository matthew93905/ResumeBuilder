import { Helmet } from "react-helmet-async";

/**
 * Enhanced SEO component specifically for the homepage
 * with additional structured data for better ranking
 */
export default function HomePageSEO() {
  const websiteStructuredData = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "url": "https://resumex.replit.app/",
    "name": "ResumeX - Professional Resume Builder",
    "description": "Create standout resumes with ResumeX. Choose from professional templates, use AI tools to enhance your content, and get hired faster.",
    "potentialAction": {
      "@type": "SearchAction",
      "target": {
        "@type": "EntryPoint",
        "urlTemplate": "https://resumex.replit.app/search?q={search_term_string}"
      },
      "query-input": "required name=search_term_string"
    }
  };

  const organizationStructuredData = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "url": "https://resumex.replit.app/",
    "logo": "https://resumex.replit.app/logo.png",
    "name": "ResumeX",
    "description": "The leading resume builder platform with AI-powered tools and professional templates",
    "sameAs": [
      "https://twitter.com/resumex",
      "https://www.facebook.com/resumex",
      "https://www.linkedin.com/company/resumex",
      "https://www.instagram.com/resumex_app"
    ],
    "contactPoint": {
      "@type": "ContactPoint",
      "telephone": "+1-800-123-4567",
      "contactType": "customer service",
      "email": "support@resumex.com",
      "availableLanguage": ["English"]
    }
  };

  const reviewStructuredData = {
    "@context": "https://schema.org",
    "@type": "Review",
    "itemReviewed": {
      "@type": "SoftwareApplication",
      "name": "ResumeX Resume Builder",
      "applicationCategory": "BusinessApplication"
    },
    "reviewRating": {
      "@type": "Rating",
      "ratingValue": "4.9",
      "bestRating": "5"
    },
    "author": {
      "@type": "Person",
      "name": "Sarah Johnson"
    },
    "reviewBody": "ResumeX helped me create a stunning resume that landed me multiple interviews. The AI suggestions for my job descriptions were incredibly helpful!"
  };

  const howToStructuredData = {
    "@context": "https://schema.org",
    "@type": "HowTo",
    "name": "How to Create a Professional Resume with ResumeX",
    "description": "Step by step guide to creating a professional resume using ResumeX",
    "totalTime": "PT15M",
    "tool": {
      "@type": "HowToTool",
      "name": "ResumeX Resume Builder"
    },
    "step": [
      {
        "@type": "HowToStep",
        "name": "Sign up for an account",
        "text": "Create an account on ResumeX to get started",
        "url": "https://resumex.replit.app/auth?tab=register"
      },
      {
        "@type": "HowToStep",
        "name": "Choose a template",
        "text": "Browse through our professional templates and select one that fits your style and industry",
        "url": "https://resumex.replit.app/templates"
      },
      {
        "@type": "HowToStep",
        "name": "Add your information",
        "text": "Fill in your personal details, work experience, education, and skills",
        "url": "https://resumex.replit.app/builder"
      },
      {
        "@type": "HowToStep",
        "name": "Enhance with AI",
        "text": "Use our AI tools to improve your content and make it more impactful",
        "url": "https://resumex.replit.app/builder"
      },
      {
        "@type": "HowToStep",
        "name": "Download your resume",
        "text": "Export your resume as a PDF and start applying for jobs",
        "url": "https://resumex.replit.app/builder"
      }
    ]
  };

  return (
    <Helmet>
      {/* Primary Meta Tags - Already handled by SEOHead component */}
      
      {/* Additional tags specific to homepage */}
      <meta name="news_keywords" content="resume builder, CV creator, job application, career development, professional templates" />
      <link rel="alternate" href="https://resumex.replit.app/" hrefLang="en-us" />
      <link rel="alternate" href="https://resumex.replit.app/" hrefLang="x-default" />
      
      {/* Add multiple structured data elements for rich results */}
      <script type="application/ld+json">
        {JSON.stringify(websiteStructuredData)}
      </script>
      <script type="application/ld+json">
        {JSON.stringify(organizationStructuredData)}
      </script>
      <script type="application/ld+json">
        {JSON.stringify(reviewStructuredData)}
      </script>
      <script type="application/ld+json">
        {JSON.stringify(howToStructuredData)}
      </script>
    </Helmet>
  );
}