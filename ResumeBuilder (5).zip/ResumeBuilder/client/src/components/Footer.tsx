import { Link } from "wouter";
import { Facebook, Twitter, Linkedin, Instagram, Mail, Phone, MapPin } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-primary/5 dark:bg-gray-900 py-16 px-4">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10">
          {/* Brand */}
          <div className="md:col-span-4">
            <Link href="/" className="inline-block mb-6">
              <span className="font-montserrat font-bold text-2xl text-gradient">ResumeX</span>
            </Link>
            <p className="text-muted-foreground mb-6 pr-4">
              Professional resume builder that helps you create stunning resumes that stand out and get you hired faster.
            </p>
            <div className="flex space-x-4 mb-8">
              <a href="https://twitter.com/resumex" target="_blank" rel="noopener noreferrer" className="w-9 h-9 rounded-full bg-accent flex items-center justify-center text-primary hover:bg-primary hover:text-white transition-colors" aria-label="Twitter">
                <Twitter className="w-4 h-4" />
              </a>
              <a href="https://linkedin.com/company/resumex" target="_blank" rel="noopener noreferrer" className="w-9 h-9 rounded-full bg-accent flex items-center justify-center text-primary hover:bg-primary hover:text-white transition-colors" aria-label="LinkedIn">
                <Linkedin className="w-4 h-4" />
              </a>
              <a href="https://facebook.com/resumex" target="_blank" rel="noopener noreferrer" className="w-9 h-9 rounded-full bg-accent flex items-center justify-center text-primary hover:bg-primary hover:text-white transition-colors" aria-label="Facebook">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="https://instagram.com/resumex" target="_blank" rel="noopener noreferrer" className="w-9 h-9 rounded-full bg-accent flex items-center justify-center text-primary hover:bg-primary hover:text-white transition-colors" aria-label="Instagram">
                <Instagram className="w-4 h-4" />
              </a>
            </div>
          </div>
          
          {/* Quick Links */}
          <div className="md:col-span-2">
            <h3 className="font-semibold text-lg mb-4">Quick Links</h3>
            <ul className="space-y-3">
              <li><Link href="/" className="text-muted-foreground hover:text-primary transition-colors">Home</Link></li>
              <li><Link href="/#features" className="text-muted-foreground hover:text-primary transition-colors">Features</Link></li>
              <li><Link href="/#templates" className="text-muted-foreground hover:text-primary transition-colors">Templates</Link></li>
              <li><Link href="/#pricing" className="text-muted-foreground hover:text-primary transition-colors">Pricing</Link></li>
              <li><Link href="/resumes" className="text-muted-foreground hover:text-primary transition-colors">My Resumes</Link></li>
            </ul>
          </div>
          
          {/* Resources */}
          <div className="md:col-span-2">
            <h3 className="font-semibold text-lg mb-4">Resources</h3>
            <ul className="space-y-3">
              <li><Link href="/resume-examples" className="text-muted-foreground hover:text-primary transition-colors">Resume Examples</Link></li>
              <li><Link href="/blog/category/career-advice" className="text-muted-foreground hover:text-primary transition-colors">Career Advice</Link></li>
              <li><Link href="/blog/category/job-search" className="text-muted-foreground hover:text-primary transition-colors">Job Search Tips</Link></li>
              <li><Link href="/blog/category/interview" className="text-muted-foreground hover:text-primary transition-colors">Interview Prep</Link></li>
              <li><Link href="/blog" className="text-muted-foreground hover:text-primary transition-colors">Blog</Link></li>
            </ul>
          </div>
          
          {/* Company */}
          <div className="md:col-span-2">
            <h3 className="font-semibold text-lg mb-4">Company</h3>
            <ul className="space-y-3">
              <li><Link href="/about" className="text-muted-foreground hover:text-primary transition-colors">About Us</Link></li>
              <li><Link href="/team" className="text-muted-foreground hover:text-primary transition-colors">Our Team</Link></li>
              <li><Link href="/careers" className="text-muted-foreground hover:text-primary transition-colors">Careers</Link></li>
              <li><Link href="/press" className="text-muted-foreground hover:text-primary transition-colors">Press Kit</Link></li>
              <li><Link href="/#testimonials" className="text-muted-foreground hover:text-primary transition-colors">Testimonials</Link></li>
            </ul>
          </div>
          
          {/* Contact */}
          <div className="md:col-span-2">
            <h3 className="font-semibold text-lg mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                <a href="mailto:support@resumex.com" className="text-muted-foreground hover:text-primary transition-colors">support@resumex.com</a>
              </li>
              <li className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                <a href="tel:+18312722794" className="text-muted-foreground hover:text-primary transition-colors">+1 (831) 272-2794</a>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                <a href="https://maps.google.com/?q=123+Resume+Way,+San+Francisco,+CA+94107" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors">123 Resume Way, San Francisco, CA 94107</a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-border mt-12 pt-8 flex flex-col text-center md:text-left">
          <div className="flex flex-col md:flex-row justify-between items-center text-muted-foreground text-sm mb-4">
            <p>&copy; {new Date().getFullYear()} ResumeX. All rights reserved.</p>
            <div className="flex gap-6 mt-4 md:mt-0">
              <Link href="/privacy" className="hover:text-primary transition-colors">Privacy Policy</Link>
              <Link href="/terms" className="hover:text-primary transition-colors">Terms of Service</Link>
              <Link href="/cookies" className="hover:text-primary transition-colors">Cookie Policy</Link>
            </div>
          </div>
          
          <div className="flex flex-col items-center md:items-start">
            <p className="font-medium text-primary">ResumeX founded by Matthew Pacheco</p>
            <div className="mt-1 inline-flex items-center bg-primary/10 text-primary font-medium px-3 py-1 rounded-full text-sm">
              <span className="mr-1.5">★</span>
              ResumeX is a veteran owned company
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
