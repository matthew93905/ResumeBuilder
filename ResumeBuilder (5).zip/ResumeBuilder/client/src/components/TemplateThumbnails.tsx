import React from 'react';

// Template thumbnail components
export const EssentialTemplateThumbnail: React.FC = () => (
  <svg width="100%" height="100%" viewBox="0 0 400 550" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="400" height="550" fill="white"/>
    
    {/* Header Section */}
    <rect x="40" y="40" width="320" height="80" rx="4" fill="#FAFAFA"/>
    <circle cx="80" cy="80" r="30" fill="#E5E7EB"/>
    <rect x="130" y="65" width="180" height="10" rx="2" fill="#111827"/>
    <rect x="130" y="85" width="120" height="6" rx="2" fill="#4F46E5"/>
    
    {/* Contact Details */}
    <rect x="40" y="140" width="80" height="6" rx="3" fill="#4F46E5"/>
    <rect x="40" y="155" width="320" height="1" rx="0.5" fill="#E5E7EB"/>
    <rect x="40" y="165" width="145" height="6" rx="3" fill="#6B7280"/>
    <rect x="195" y="165" width="165" height="6" rx="3" fill="#6B7280"/>
    <rect x="40" y="180" width="145" height="6" rx="3" fill="#6B7280"/>
    <rect x="195" y="180" width="165" height="6" rx="3" fill="#6B7280"/>
    
    {/* Summary Section */}
    <rect x="40" y="210" width="110" height="8" rx="4" fill="#4F46E5"/>
    <rect x="40" y="225" width="320" height="1" rx="0.5" fill="#E5E7EB"/>
    <rect x="40" y="240" width="320" height="6" rx="3" fill="#6B7280"/>
    <rect x="40" y="255" width="320" height="6" rx="3" fill="#6B7280"/>
    <rect x="40" y="270" width="240" height="6" rx="3" fill="#6B7280"/>
    
    {/* Experience Section */}
    <rect x="40" y="300" width="150" height="8" rx="4" fill="#4F46E5"/>
    <rect x="40" y="315" width="320" height="1" rx="0.5" fill="#E5E7EB"/>
    <rect x="40" y="330" width="160" height="7" rx="3.5" fill="#374151"/>
    <rect x="280" y="330" width="80" height="7" rx="3.5" fill="#6B7280"/>
    <rect x="40" y="345" width="130" height="6" rx="3" fill="#6B7280"/>
    <rect x="40" y="360" width="320" height="1" rx="0.5" fill="#E5E7EB"/>
    <rect x="60" y="375" width="300" height="5" rx="2.5" fill="#6B7280"/>
    <rect x="60" y="388" width="300" height="5" rx="2.5" fill="#6B7280"/>
    <rect x="60" y="401" width="240" height="5" rx="2.5" fill="#6B7280"/>
    
    {/* Skills Section */}
    <rect x="40" y="430" width="80" height="8" rx="4" fill="#4F46E5"/>
    <rect x="40" y="445" width="320" height="1" rx="0.5" fill="#E5E7EB"/>
    <rect x="40" y="460" width="65" height="24" rx="12" fill="#EEF2FF"/>
    <rect x="115" y="460" width="75" height="24" rx="12" fill="#EEF2FF"/>
    <rect x="200" y="460" width="60" height="24" rx="12" fill="#EEF2FF"/>
    <rect x="270" y="460" width="90" height="24" rx="12" fill="#EEF2FF"/>
    <rect x="40" y="494" width="80" height="24" rx="12" fill="#EEF2FF"/>
    <rect x="130" y="494" width="65" height="24" rx="12" fill="#EEF2FF"/>
  </svg>
);

export const ExecutiveTemplateThumbnail: React.FC = () => (
  <svg width="100%" height="100%" viewBox="0 0 400 550" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="400" height="550" fill="white"/>
    
    {/* Header Section with name and title */}
    <rect x="40" y="40" width="320" height="80" rx="2" fill="white"/>
    <rect x="100" y="50" width="200" height="14" rx="2" fill="#1E40AF"/>
    <rect x="120" y="75" width="160" height="8" rx="4" fill="#6B7280"/>
    <rect x="40" y="130" width="320" height="2" rx="1" fill="#1E40AF"/>
    
    {/* Contact Details - centered row */}
    <rect x="80" y="145" width="20" height="6" rx="3" fill="#1E40AF"/>
    <rect x="110" y="145" width="60" height="6" rx="3" fill="#6B7280"/>
    <rect x="190" y="145" width="20" height="6" rx="3" fill="#1E40AF"/>
    <rect x="220" y="145" width="60" height="6" rx="3" fill="#6B7280"/>
    <rect x="300" y="145" width="20" height="6" rx="3" fill="#1E40AF"/>
    <rect x="330" y="145" width="30" height="6" rx="3" fill="#6B7280"/>
    
    {/* Executive Summary Section */}
    <rect x="40" y="180" width="320" height="70" rx="4" fill="#F3F4F6"/>
    <rect x="60" y="195" width="120" height="10" rx="5" fill="#1E40AF"/>
    <rect x="60" y="215" width="280" height="6" rx="3" fill="#6B7280"/>
    <rect x="60" y="230" width="280" height="6" rx="3" fill="#6B7280"/>
    
    {/* Professional Experience Section */}
    <rect x="40" y="280" width="200" height="10" rx="5" fill="#1E40AF"/>
    
    {/* First Job */}
    <rect x="40" y="305" width="320" height="2" rx="1" fill="#E5E7EB"/>
    <rect x="40" y="315" width="180" height="8" rx="4" fill="#374151"/>
    <rect x="280" y="315" width="80" height="6" rx="3" fill="#6B7280"/>
    <rect x="40" y="330" width="160" height="6" rx="3" fill="#6B7280"/>
    <rect x="60" y="350" width="300" height="5" rx="2.5" fill="#6B7280"/>
    <rect x="60" y="363" width="300" height="5" rx="2.5" fill="#6B7280"/>
    <rect x="60" y="376" width="300" height="5" rx="2.5" fill="#6B7280"/>
    
    {/* Second Job */}
    <rect x="40" y="395" width="320" height="2" rx="1" fill="#E5E7EB"/>
    <rect x="40" y="405" width="180" height="8" rx="4" fill="#374151"/>
    <rect x="280" y="405" width="80" height="6" rx="3" fill="#6B7280"/>
    <rect x="40" y="420" width="160" height="6" rx="3" fill="#6B7280"/>
    <rect x="60" y="440" width="300" height="5" rx="2.5" fill="#6B7280"/>
    <rect x="60" y="453" width="300" height="5" rx="2.5" fill="#6B7280"/>
    
    {/* Education - Two Column Layout */}
    <rect x="40" y="480" width="150" height="8" rx="4" fill="#1E40AF"/>
    <rect x="40" y="500" width="145" height="40" rx="2" fill="#F3F4F6"/>
    <rect x="55" y="510" width="115" height="8" rx="4" fill="#374151"/>
    <rect x="55" y="525" width="90" height="6" rx="3" fill="#6B7280"/>
    
    <rect x="200" y="500" width="145" height="40" rx="2" fill="#F3F4F6"/>
    <rect x="215" y="510" width="115" height="8" rx="4" fill="#374151"/>
    <rect x="215" y="525" width="90" height="6" rx="3" fill="#6B7280"/>
  </svg>
);

export const CreativeTemplateThumbnail: React.FC = () => (
  <svg width="100%" height="100%" viewBox="0 0 400 550" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="400" height="550" fill="white"/>
    
    {/* Purple Sidebar */}
    <rect width="120" height="550" fill="#7C3AED"/>
    
    {/* Profile Photo */}
    <circle cx="60" cy="70" r="35" fill="white"/>
    
    {/* Sidebar Contact Section */}
    <rect x="25" y="120" width="70" height="10" rx="5" fill="white"/>
    <rect x="15" y="140" width="90" height="2" rx="1" fill="white" fillOpacity="0.6"/>
    
    <rect x="20" y="155" width="15" height="6" rx="3" fill="white"/>
    <rect x="40" y="155" width="60" height="6" rx="3" fill="white" fillOpacity="0.9"/>
    
    <rect x="20" y="170" width="15" height="6" rx="3" fill="white"/>
    <rect x="40" y="170" width="60" height="6" rx="3" fill="white" fillOpacity="0.9"/>
    
    <rect x="20" y="185" width="15" height="6" rx="3" fill="white"/>
    <rect x="40" y="185" width="60" height="6" rx="3" fill="white" fillOpacity="0.9"/>
    
    {/* Sidebar Skills Section */}
    <rect x="25" y="215" width="70" height="10" rx="5" fill="white"/>
    <rect x="15" y="235" width="90" height="2" rx="1" fill="white" fillOpacity="0.6"/>
    
    {/* Skill Dots and Labels */}
    <rect x="25" y="250" width="10" height="10" rx="5" fill="white"/>
    <rect x="45" y="252" width="55" height="6" rx="3" fill="white" fillOpacity="0.9"/>
    
    <rect x="25" y="270" width="10" height="10" rx="5" fill="white"/>
    <rect x="45" y="272" width="55" height="6" rx="3" fill="white" fillOpacity="0.9"/>
    
    <rect x="25" y="290" width="10" height="10" rx="5" fill="white"/>
    <rect x="45" y="292" width="55" height="6" rx="3" fill="white" fillOpacity="0.9"/>
    
    <rect x="25" y="310" width="10" height="10" rx="5" fill="white"/>
    <rect x="45" y="312" width="55" height="6" rx="3" fill="white" fillOpacity="0.9"/>
    
    {/* Education Section */}
    <rect x="25" y="340" width="70" height="10" rx="5" fill="white"/>
    <rect x="15" y="360" width="90" height="2" rx="1" fill="white" fillOpacity="0.6"/>
    <rect x="25" y="375" width="80" height="6" rx="3" fill="white" fillOpacity="0.9"/>
    <rect x="25" y="390" width="70" height="6" rx="3" fill="white" fillOpacity="0.9"/>
    <rect x="25" y="405" width="50" height="6" rx="3" fill="white" fillOpacity="0.9"/>
    
    {/* Main Content Area */}
    {/* Name and Title */}
    <rect x="140" y="40" width="240" height="30" rx="4" fill="#F9FAFB"/>
    <rect x="155" y="50" width="180" height="12" rx="6" fill="#7C3AED"/>
    <rect x="155" y="70" width="150" height="6" rx="3" fill="#6B7280"/>
    
    {/* Summary Section */}
    <rect x="140" y="90" width="100" height="10" rx="5" fill="#7C3AED"/>
    <rect x="140" y="110" width="240" height="60" rx="2" fill="#F9FAFB"/>
    <rect x="155" y="120" width="210" height="6" rx="3" fill="#6B7280"/>
    <rect x="155" y="135" width="210" height="6" rx="3" fill="#6B7280"/>
    <rect x="155" y="150" width="210" height="6" rx="3" fill="#6B7280"/>
    
    {/* Experience Section */}
    <rect x="140" y="190" width="120" height="10" rx="5" fill="#7C3AED"/>
    
    {/* Job 1 */}
    <rect x="140" y="210" width="240" height="2" rx="1" fill="#E5E7EB"/>
    <rect x="140" y="220" width="180" height="8" rx="4" fill="#374151"/>
    <rect x="140" y="235" width="100" height="6" rx="3" fill="#6B7280"/>
    <rect x="300" y="235" width="80" height="6" rx="3" fill="#6B7280"/>
    
    <rect x="155" y="255" width="225" height="5" rx="2.5" fill="#6B7280"/>
    <rect x="155" y="270" width="225" height="5" rx="2.5" fill="#6B7280"/>
    <rect x="155" y="285" width="225" height="5" rx="2.5" fill="#6B7280"/>
    
    {/* Job 2 */}
    <rect x="140" y="305" width="240" height="2" rx="1" fill="#E5E7EB"/>
    <rect x="140" y="315" width="170" height="8" rx="4" fill="#374151"/>
    <rect x="140" y="330" width="100" height="6" rx="3" fill="#6B7280"/>
    <rect x="300" y="330" width="80" height="6" rx="3" fill="#6B7280"/>
    
    <rect x="155" y="350" width="225" height="5" rx="2.5" fill="#6B7280"/>
    <rect x="155" y="365" width="225" height="5" rx="2.5" fill="#6B7280"/>
    <rect x="155" y="380" width="225" height="5" rx="2.5" fill="#6B7280"/>
  </svg>
);

export const MinimalistTemplateThumbnail: React.FC = () => (
  <svg width="100%" height="100%" viewBox="0 0 400 550" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="400" height="550" fill="white"/>
    <rect x="40" y="40" width="180" height="16" rx="2" fill="#111827"/>
    <rect x="40" y="65" width="120" height="8" rx="4" fill="#4B5563"/>
    <rect x="40" y="85" width="100" height="6" rx="3" fill="#6B7280"/>
    <rect x="40" y="100" width="150" height="6" rx="3" fill="#6B7280"/>
    <rect x="280" y="40" width="80" height="80" rx="40" fill="#F3F4F6"/>
    <rect x="40" y="140" width="320" height="1" rx="0.5" fill="#E5E7EB"/>
    <rect x="40" y="160" width="80" height="8" rx="4" fill="#111827"/>
    <rect x="40" y="180" width="320" height="40" rx="2" fill="#F9FAFB"/>
    <rect x="40" y="240" width="80" height="8" rx="4" fill="#111827"/>
    <rect x="40" y="260" width="150" height="6" rx="3" fill="#374151"/>
    <rect x="40" y="275" width="100" height="6" rx="3" fill="#6B7280"/>
    <rect x="40" y="290" width="320" height="1" rx="0.5" fill="#E5E7EB"/>
    <rect x="40" y="305" width="150" height="6" rx="3" fill="#374151"/>
    <rect x="40" y="320" width="100" height="6" rx="3" fill="#6B7280"/>
    <rect x="40" y="335" width="320" height="1" rx="0.5" fill="#E5E7EB"/>
    <rect x="40" y="365" width="80" height="8" rx="4" fill="#111827"/>
    <rect x="40" y="385" width="150" height="6" rx="3" fill="#374151"/>
    <rect x="40" y="400" width="100" height="6" rx="3" fill="#6B7280"/>
    <rect x="40" y="420" width="320" height="1" rx="0.5" fill="#E5E7EB"/>
    <rect x="40" y="450" width="80" height="8" rx="4" fill="#111827"/>
    <rect x="40" y="470" width="55" height="20" rx="10" fill="#F3F4F6"/>
    <rect x="105" y="470" width="55" height="20" rx="10" fill="#F3F4F6"/>
    <rect x="170" y="470" width="55" height="20" rx="10" fill="#F3F4F6"/>
  </svg>
);

export const ModernTemplateThumbnail: React.FC = () => (
  <svg width="100%" height="100%" viewBox="0 0 400 550" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="400" height="550" fill="white"/>
    <rect width="400" height="120" fill="#2563EB"/>
    <circle cx="60" cy="60" r="30" fill="white"/>
    <rect x="110" y="45" width="200" height="12" rx="6" fill="white"/>
    <rect x="110" y="70" width="140" height="8" rx="4" fill="#93C5FD"/>
    <rect x="40" y="140" width="100" height="8" rx="4" fill="#2563EB"/>
    <rect x="40" y="160" width="320" height="40" rx="2" fill="#F3F4F6"/>
    <rect x="40" y="220" width="100" height="8" rx="4" fill="#2563EB"/>
    <rect x="40" y="240" width="150" height="6" rx="3" fill="#374151"/>
    <rect x="320" y="240" width="40" height="6" rx="3" fill="#6B7280"/>
    <rect x="40" y="255" width="110" height="6" rx="3" fill="#6B7280"/>
    <rect x="40" y="270" width="320" height="2" rx="1" fill="#E5E7EB"/>
    <rect x="60" y="280" width="300" height="6" rx="3" fill="#6B7280"/>
    <rect x="60" y="295" width="300" height="6" rx="3" fill="#6B7280"/>
    <rect x="60" y="310" width="300" height="6" rx="3" fill="#6B7280"/>
    <rect x="40" y="330" width="320" height="2" rx="1" fill="#E5E7EB"/>
    <rect x="40" y="350" width="100" height="8" rx="4" fill="#2563EB"/>
    <rect x="40" y="370" width="150" height="6" rx="3" fill="#374151"/>
    <rect x="320" y="370" width="40" height="6" rx="3" fill="#6B7280"/>
    <rect x="40" y="385" width="110" height="6" rx="3" fill="#6B7280"/>
    <rect x="40" y="400" width="320" height="2" rx="1" fill="#E5E7EB"/>
    <rect x="40" y="420" width="100" height="8" rx="4" fill="#2563EB"/>
    <rect x="40" y="440" width="60" height="24" rx="12" fill="#DBEAFE"/>
    <rect x="110" y="440" width="70" height="24" rx="12" fill="#DBEAFE"/>
    <rect x="190" y="440" width="80" height="24" rx="12" fill="#DBEAFE"/>
  </svg>
);

export const VisualImpactTemplateThumbnail: React.FC = () => (
  <svg width="100%" height="100%" viewBox="0 0 400 550" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="400" height="550" fill="white"/>
    <rect width="400" height="120" fill="url(#paint0_linear)"/>
    <circle cx="330" cy="60" r="30" fill="white"/>
    <rect x="40" y="45" width="200" height="12" rx="6" fill="white"/>
    <rect x="40" y="70" width="140" height="8" rx="4" fill="#C7D2FE"/>
    <rect x="40" y="140" width="320" height="80" rx="8" fill="#F3F4F6"/>
    <rect x="60" y="160" width="120" height="10" rx="5" fill="#4F46E5"/>
    <rect x="60" y="180" width="280" height="6" rx="3" fill="#6B7280"/>
    <rect x="60" y="195" width="280" height="6" rx="3" fill="#6B7280"/>
    <rect x="40" y="240" width="320" height="2" rx="1" fill="#E5E7EB"/>
    <rect x="80" y="260" width="320" height="2" rx="1" fill="#E5E7EB"/>
    <circle cx="60" cy="261" r="10" fill="#4F46E5"/>
    <rect x="80" y="280" width="150" height="8" rx="4" fill="#374151"/>
    <rect x="80" y="295" width="110" height="6" rx="3" fill="#6B7280"/>
    <rect x="300" y="290" width="60" height="6" rx="3" fill="#6B7280"/>
    <rect x="100" y="320" width="300" height="6" rx="3" fill="#6B7280"/>
    <rect x="100" y="335" width="300" height="6" rx="3" fill="#6B7280"/>
    <rect x="100" y="350" width="300" height="6" rx="3" fill="#6B7280"/>
    <rect x="80" y="380" width="320" height="2" rx="1" fill="#E5E7EB"/>
    <circle cx="60" cy="381" r="10" fill="#4F46E5"/>
    <rect x="80" y="400" width="150" height="8" rx="4" fill="#374151"/>
    <rect x="80" y="415" width="110" height="6" rx="3" fill="#6B7280"/>
    <rect x="300" y="410" width="60" height="6" rx="3" fill="#6B7280"/>
    <rect x="40" y="450" width="150" height="8" rx="4" fill="#4F46E5"/>
    <rect x="40" y="470" width="70" height="30" rx="15" fill="#EEF2FF"/>
    <rect x="120" y="470" width="70" height="30" rx="15" fill="#EEF2FF"/>
    <rect x="200" y="470" width="70" height="30" rx="15" fill="#EEF2FF"/>
    <defs>
      <linearGradient id="paint0_linear" x1="0" y1="0" x2="400" y2="120" gradientUnits="userSpaceOnUse">
        <stop stopColor="#4F46E5"/>
        <stop offset="1" stopColor="#7C3AED"/>
      </linearGradient>
    </defs>
  </svg>
);

export const InfographicTemplateThumbnail: React.FC = () => (
  <svg width="100%" height="100%" viewBox="0 0 400 550" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="400" height="550" fill="white"/>
    <rect width="400" height="100" fill="#059669"/>
    <circle cx="330" cy="50" r="30" fill="white"/>
    <rect x="40" y="40" width="180" height="12" rx="6" fill="white"/>
    <rect x="40" y="65" width="150" height="8" rx="4" fill="#A7F3D0"/>
    <rect x="40" y="120" width="160" height="10" rx="5" fill="#059669"/>
    <rect x="40" y="140" width="320" height="50" rx="4" fill="#F3F4F6"/>
    <rect x="40" y="210" width="120" height="100" rx="4" fill="#ECFDF5"/>
    <rect x="50" y="220" width="100" height="8" rx="4" fill="#059669"/>
    <rect x="50" y="235" width="60" height="6" rx="3" fill="#374151"/>
    <rect x="50" y="250" width="100" height="50" rx="4" fill="white"/>
    <rect x="60" y="260" width="80" height="10" rx="5" fill="#059669"/>
    <rect x="60" y="280" width="25" height="10" rx="5" fill="#D1FAE5"/>
    <rect x="95" y="280" width="50" height="10" rx="5" fill="#D1FAE5"/>
    <rect x="170" y="210" width="190" height="200" rx="4" fill="#ECFDF5"/>
    <rect x="180" y="220" width="170" height="8" rx="4" fill="#059669"/>
    <circle cx="190" cy="245" r="5" fill="#059669"/>
    <rect x="200" y="240" width="150" height="6" rx="3" fill="#374151"/>
    <circle cx="190" cy="265" r="5" fill="#059669"/>
    <rect x="200" y="260" width="150" height="6" rx="3" fill="#374151"/>
    <circle cx="190" cy="285" r="5" fill="#059669"/>
    <rect x="200" y="280" width="150" height="6" rx="3" fill="#374151"/>
    <rect x="40" y="330" width="120" height="120" rx="4" fill="#ECFDF5"/>
    <rect x="50" y="340" width="100" height="8" rx="4" fill="#059669"/>
    <rect x="60" y="365" width="20" height="70" rx="2" fill="#10B981"/>
    <rect x="90" y="385" width="20" height="50" rx="2" fill="#10B981"/>
    <rect x="120" y="350" width="20" height="85" rx="2" fill="#10B981"/>
    <rect x="40" y="470" width="320" height="60" rx="4" fill="#ECFDF5"/>
    <rect x="60" y="485" width="60" height="30" rx="15" fill="#D1FAE5"/>
    <rect x="140" y="485" width="60" height="30" rx="15" fill="#D1FAE5"/>
    <rect x="220" y="485" width="60" height="30" rx="15" fill="#D1FAE5"/>
    <rect x="300" y="485" width="40" height="30" rx="15" fill="#D1FAE5"/>
  </svg>
);

export const ExecutivePlusTemplateThumbnail: React.FC = () => (
  <svg width="100%" height="100%" viewBox="0 0 400 550" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="400" height="550" fill="#FFFCF5"/>
    <rect x="40" y="40" width="320" height="40" rx="4" fill="#F59E0B" fillOpacity="0.1"/>
    <rect x="60" y="55" width="200" height="10" rx="5" fill="#92400E"/>
    <rect x="40" y="100" width="180" height="12" rx="6" fill="#92400E"/>
    <rect x="40" y="120" width="140" height="8" rx="4" fill="#D97706"/>
    <rect x="40" y="140" width="320" height="2" rx="1" fill="#FCD34D"/>
    <rect x="40" y="160" width="320" height="70" rx="4" fill="#FFFBEB"/>
    <rect x="60" y="175" width="120" height="10" rx="5" fill="#92400E"/>
    <rect x="60" y="195" width="280" height="6" rx="3" fill="#92400E" fillOpacity="0.6"/>
    <rect x="60" y="210" width="280" height="6" rx="3" fill="#92400E" fillOpacity="0.6"/>
    <rect x="40" y="250" width="200" height="12" rx="6" fill="#92400E"/>
    <rect x="40" y="280" width="150" height="8" rx="4" fill="#D97706"/>
    <rect x="280" y="280" width="80" height="6" rx="3" fill="#D97706"/>
    <rect x="40" y="300" width="320" height="1" rx="0.5" fill="#FCD34D"/>
    <rect x="55" y="315" width="305" height="6" rx="3" fill="#92400E" fillOpacity="0.6"/>
    <rect x="50" y="313" width="5" height="10" rx="2.5" fill="#F59E0B"/>
    <rect x="55" y="335" width="305" height="6" rx="3" fill="#92400E" fillOpacity="0.6"/>
    <rect x="50" y="333" width="5" height="10" rx="2.5" fill="#F59E0B"/>
    <rect x="55" y="355" width="305" height="6" rx="3" fill="#92400E" fillOpacity="0.6"/>
    <rect x="50" y="353" width="5" height="10" rx="2.5" fill="#F59E0B"/>
    <rect x="40" y="390" width="320" height="1" rx="0.5" fill="#FCD34D"/>
    <rect x="40" y="410" width="150" height="8" rx="4" fill="#D97706"/>
    <rect x="40" y="430" width="150" height="30" rx="2" fill="#FFFBEB"/>
    <rect x="40" y="470" width="320" height="60" rx="4" fill="#FFFBEB"/>
    <rect x="55" y="485" width="290" height="6" rx="3" fill="#92400E" fillOpacity="0.6"/>
    <rect x="55" y="505" width="290" height="6" rx="3" fill="#92400E" fillOpacity="0.6"/>
    <rect x="310" y="525" width="30" height="4" rx="2" fill="#F59E0B"/>
    <rect x="280" y="525" width="25" height="4" rx="2" fill="#F59E0B"/>
  </svg>
);