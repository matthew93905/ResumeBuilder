import { useState, useEffect } from "react";
import { SunIcon, MoonIcon } from "lucide-react";
import { useTheme } from "@/hooks/use-theme";

export default function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();
  const [isMounted, setIsMounted] = useState(false);
  
  // Avoid hydration mismatch by only rendering after component mounts
  useEffect(() => {
    setIsMounted(true);
  }, []);

  if (!isMounted) {
    return <div className="w-10 h-10"></div>; // Empty placeholder to avoid layout shift
  }

  return (
    <button
      onClick={toggleTheme}
      className={`relative rounded-full w-10 h-10 flex items-center justify-center ${
        theme === 'dark' 
          ? 'bg-gray-700 text-yellow-300 hover:bg-gray-600' 
          : 'bg-blue-100 text-blue-600 hover:bg-blue-200'
      } transition-colors duration-300`}
      aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
    >
      <span className={`transform transition-transform duration-300 ${theme === 'dark' ? 'rotate-45 scale-110' : ''}`}>
        {theme === 'dark' ? (
          <SunIcon className="h-5 w-5" />
        ) : (
          <MoonIcon className="h-5 w-5" />
        )}
      </span>
      
      {/* Simple visual effect */}
      {theme === 'dark' && (
        <span className="absolute top-1.5 right-2 w-1 h-1 bg-white rounded-full opacity-70"></span>
      )}
    </button>
  );
}