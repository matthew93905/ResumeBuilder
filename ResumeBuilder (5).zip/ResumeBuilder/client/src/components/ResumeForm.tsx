import { useState } from "react";
import { useResume } from "@/hooks/use-resume";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { XIcon, PlusIcon } from "lucide-react";
import AIEnhanceButton from "./AIEnhanceButton";
import ResumeAnalyzer from "./ResumeAnalyzer";

export default function ResumeForm() {
  const {
    resumeData,
    updatePersonalInfo,
    updateSummary,
    addExperience,
    updateExperience,
    removeExperience,
    addEducation,
    updateEducation,
    removeEducation,
    addSkill,
    removeSkill,
    activeSection,
    setActiveSection
  } = useResume();
  
  const { toast } = useToast();
  
  // State for new experience item
  const [newExperience, setNewExperience] = useState({
    company: '',
    position: '',
    location: '',
    startDate: '',
    endDate: '',
    current: false,
    description: ['']
  });
  
  // State for new education item
  const [newEducation, setNewEducation] = useState({
    institution: '',
    degree: '',
    field: '',
    location: '',
    startDate: '',
    endDate: '',
    description: ''
  });
  
  // State for new skill
  const [newSkill, setNewSkill] = useState('');
  
  // Handle adding a new bullet point to experience description
  const addBulletPoint = (experienceId: string | null = null) => {
    if (experienceId) {
      // Add to existing experience
      const experience = resumeData.experience.find(exp => exp.id === experienceId);
      if (experience) {
        updateExperience(experienceId, {
          description: [...experience.description, '']
        });
      }
    } else {
      // Add to new experience form
      setNewExperience({
        ...newExperience,
        description: [...newExperience.description, '']
      });
    }
  };
  
  // Handle removing a bullet point from experience description
  const removeBulletPoint = (index: number, experienceId: string | null = null) => {
    if (experienceId) {
      // Remove from existing experience
      const experience = resumeData.experience.find(exp => exp.id === experienceId);
      if (experience) {
        const newDescription = [...experience.description];
        newDescription.splice(index, 1);
        updateExperience(experienceId, {
          description: newDescription
        });
      }
    } else {
      // Remove from new experience form
      const newDescription = [...newExperience.description];
      newDescription.splice(index, 1);
      setNewExperience({
        ...newExperience,
        description: newDescription
      });
    }
  };
  
  // Handle updating a bullet point in experience description
  const updateBulletPoint = (value: string, index: number, experienceId: string | null = null) => {
    if (experienceId) {
      // Update in existing experience
      const experience = resumeData.experience.find(exp => exp.id === experienceId);
      if (experience) {
        const newDescription = [...experience.description];
        newDescription[index] = value;
        updateExperience(experienceId, {
          description: newDescription
        });
      }
    } else {
      // Update in new experience form
      const newDescription = [...newExperience.description];
      newDescription[index] = value;
      setNewExperience({
        ...newExperience,
        description: newDescription
      });
    }
  };
  
  // Handle adding new experience
  const handleAddExperience = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate required fields
    if (!newExperience.company || !newExperience.position || !newExperience.startDate) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return;
    }
    
    // Add experience
    addExperience({
      company: newExperience.company,
      position: newExperience.position,
      location: newExperience.location,
      startDate: newExperience.startDate,
      endDate: newExperience.current ? '' : newExperience.endDate,
      current: newExperience.current,
      description: newExperience.description.filter(d => d.trim() !== '')
    });
    
    // Reset form
    setNewExperience({
      company: '',
      position: '',
      location: '',
      startDate: '',
      endDate: '',
      current: false,
      description: ['']
    });
    
    toast({
      title: "Experience added",
      description: "Your work experience has been added to your resume."
    });
  };
  
  // Handle adding new education
  const handleAddEducation = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate required fields
    if (!newEducation.institution || !newEducation.degree || !newEducation.startDate) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return;
    }
    
    // Add education
    addEducation(newEducation);
    
    // Reset form
    setNewEducation({
      institution: '',
      degree: '',
      field: '',
      location: '',
      startDate: '',
      endDate: '',
      description: ''
    });
    
    toast({
      title: "Education added",
      description: "Your education has been added to your resume."
    });
  };
  
  // Handle adding new skill
  const handleAddSkill = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newSkill.trim()) {
      toast({
        title: "Empty skill",
        description: "Please enter a skill before adding.",
        variant: "destructive"
      });
      return;
    }
    
    addSkill({ name: newSkill });
    setNewSkill('');
  };
  
  return (
    <div className="border-r border-gray-200 dark:border-gray-700">
      {/* Header with Tabs Navigation and Resume Analyzer */}
      <div className="border-b border-gray-200 dark:border-gray-700">
        <div className="flex justify-between items-center px-4 py-2">
          <h2 className="text-lg font-medium">Resume Editor</h2>
          <ResumeAnalyzer resumeData={resumeData} />
        </div>
        <div className="flex overflow-x-auto">
          <button 
            className={`px-6 py-3 border-b-2 ${activeSection === 'personal' ? 'border-secondary font-medium text-secondary' : 'border-transparent hover:text-secondary'} transition-colors flex-shrink-0`}
            onClick={() => setActiveSection('personal')}
          >
            Personal Info
          </button>
          <button 
            className={`px-6 py-3 border-b-2 ${activeSection === 'summary' ? 'border-secondary font-medium text-secondary' : 'border-transparent hover:text-secondary'} transition-colors flex-shrink-0`}
            onClick={() => setActiveSection('summary')}
          >
            Summary
          </button>
          <button 
            className={`px-6 py-3 border-b-2 ${activeSection === 'experience' ? 'border-secondary font-medium text-secondary' : 'border-transparent hover:text-secondary'} transition-colors flex-shrink-0`}
            onClick={() => setActiveSection('experience')}
          >
            Work Experience
          </button>
          <button 
            className={`px-6 py-3 border-b-2 ${activeSection === 'education' ? 'border-secondary font-medium text-secondary' : 'border-transparent hover:text-secondary'} transition-colors flex-shrink-0`}
            onClick={() => setActiveSection('education')}
          >
            Education
          </button>
          <button 
            className={`px-6 py-3 border-b-2 ${activeSection === 'skills' ? 'border-secondary font-medium text-secondary' : 'border-transparent hover:text-secondary'} transition-colors flex-shrink-0`}
            onClick={() => setActiveSection('skills')}
          >
            Skills
          </button>
        </div>
      </div>
      
      {/* Form Content */}
      <div className="p-6 overflow-auto max-h-[500px] custom-scrollbar">
        {/* Personal Info */}
        {activeSection === 'personal' && (
          <form className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium mb-2">Full Name*</label>
                <Input 
                  type="text" 
                  value={resumeData.personalInfo.name} 
                  onChange={(e) => updatePersonalInfo({ name: e.target.value })}
                  placeholder="John Doe"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Job Title*</label>
                <Input 
                  type="text" 
                  value={resumeData.personalInfo.jobTitle} 
                  onChange={(e) => updatePersonalInfo({ jobTitle: e.target.value })}
                  placeholder="Senior Product Designer"
                  required
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium mb-2">Email*</label>
                <Input 
                  type="email" 
                  value={resumeData.personalInfo.email} 
                  onChange={(e) => updatePersonalInfo({ email: e.target.value })}
                  placeholder="john.doe@example.com"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Phone*</label>
                <Input 
                  type="tel" 
                  value={resumeData.personalInfo.phone} 
                  onChange={(e) => updatePersonalInfo({ phone: e.target.value })}
                  placeholder="(555) 123-4567"
                  required
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2">Address</label>
              <Input 
                type="text" 
                value={resumeData.personalInfo.address} 
                onChange={(e) => updatePersonalInfo({ address: e.target.value })}
                placeholder="123 Main Street"
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="block text-sm font-medium mb-2">City</label>
                <Input 
                  type="text" 
                  value={resumeData.personalInfo.city} 
                  onChange={(e) => updatePersonalInfo({ city: e.target.value })}
                  placeholder="New York"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">State</label>
                <Input 
                  type="text" 
                  value={resumeData.personalInfo.state} 
                  onChange={(e) => updatePersonalInfo({ state: e.target.value })}
                  placeholder="NY"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">ZIP Code</label>
                <Input 
                  type="text" 
                  value={resumeData.personalInfo.zip} 
                  onChange={(e) => updatePersonalInfo({ zip: e.target.value })}
                  placeholder="10001"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium mb-2">LinkedIn</label>
                <Input 
                  type="url" 
                  value={resumeData.personalInfo.linkedin} 
                  onChange={(e) => updatePersonalInfo({ linkedin: e.target.value })}
                  placeholder="linkedin.com/in/johndoe"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Website</label>
                <Input 
                  type="url" 
                  value={resumeData.personalInfo.website} 
                  onChange={(e) => updatePersonalInfo({ website: e.target.value })}
                  placeholder="johndoe.com"
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2">Photo (Optional)</label>
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-gray-200 dark:bg-gray-600 rounded-full overflow-hidden">
                  {resumeData.personalInfo.photo ? (
                    <img 
                      src={resumeData.personalInfo.photo}
                      alt="User avatar" 
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-gray-400">
                      <i className="ri-user-line text-2xl"></i>
                    </div>
                  )}
                </div>
                <Button variant="outline" size="sm" type="button">
                  Change Photo
                </Button>
                {resumeData.personalInfo.photo && (
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="text-red-500 hover:text-red-700 hover:bg-red-50"
                    onClick={() => updatePersonalInfo({ photo: null })}
                    type="button"
                  >
                    Remove
                  </Button>
                )}
              </div>
            </div>
          </form>
        )}
        
        {/* Summary */}
        {activeSection === 'summary' && (
          <form className="space-y-6">
            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="block text-sm font-medium">Professional Summary*</label>
                <AIEnhanceButton 
                  type="summary"
                  content={resumeData.summary.content}
                  jobTitle={resumeData.personalInfo.jobTitle}
                  onEnhanced={(enhanced) => updateSummary({ content: enhanced as string })}
                />
              </div>
              <p className="text-xs text-gray-500 mb-2">
                Write a short summary highlighting your skills, experience, and what you bring to the table.
              </p>
              <Textarea 
                value={resumeData.summary.content} 
                onChange={(e) => updateSummary({ content: e.target.value })}
                placeholder="Experienced professional with a background in..."
                rows={6}
                required
              />
            </div>
          </form>
        )}
        
        {/* Work Experience */}
        {activeSection === 'experience' && (
          <div className="space-y-8">
            {/* Existing Work Experience */}
            {resumeData.experience.length > 0 && (
              <div className="space-y-6">
                <h3 className="font-medium text-lg">Your Experience</h3>
                
                {resumeData.experience.map((exp) => (
                  <div key={exp.id} className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h4 className="font-medium">{exp.position}</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{exp.company}, {exp.location}</p>
                      </div>
                      <Button 
                        variant="ghost"
                        size="sm"
                        className="text-red-500 hover:text-red-700 hover:bg-red-50"
                        onClick={() => removeExperience(exp.id)}
                      >
                        <XIcon className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div>
                        <label className="block text-sm font-medium mb-1">Start Date</label>
                        <Input 
                          type="month" 
                          value={exp.startDate} 
                          onChange={(e) => updateExperience(exp.id, { startDate: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">End Date</label>
                        <div className="flex items-center gap-2">
                          <Input 
                            type="month" 
                            value={exp.endDate} 
                            onChange={(e) => updateExperience(exp.id, { endDate: e.target.value })}
                            disabled={exp.current}
                          />
                          <label className="flex items-center gap-1 text-sm">
                            <input 
                              type="checkbox" 
                              checked={exp.current} 
                              onChange={(e) => updateExperience(exp.id, { 
                                current: e.target.checked,
                                endDate: e.target.checked ? '' : exp.endDate
                              })}
                              className="rounded"
                            />
                            Current
                          </label>
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <label className="block text-sm font-medium">Responsibilities & Achievements</label>
                        <AIEnhanceButton 
                          type="job-description"
                          content={exp.description}
                          jobTitle={exp.position}
                          onEnhanced={(enhanced) => updateExperience(exp.id, { description: enhanced as string[] })}
                        />
                      </div>
                      
                      {exp.description.map((desc, index) => (
                        <div key={index} className="flex gap-2">
                          <Input 
                            value={desc} 
                            onChange={(e) => updateBulletPoint(e.target.value, index, exp.id)}
                            placeholder={`Achievement ${index + 1}`}
                            className="flex-1"
                          />
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="text-red-500 hover:text-red-700 hover:bg-red-50"
                            onClick={() => removeBulletPoint(index, exp.id)}
                            disabled={exp.description.length <= 1}
                          >
                            <XIcon className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                      
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex items-center gap-1"
                        onClick={() => addBulletPoint(exp.id)}
                        type="button"
                      >
                        <PlusIcon className="h-4 w-4" /> Add Bullet Point
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
            
            {/* Add New Experience Form */}
            <form onSubmit={handleAddExperience} className="border-t border-gray-200 dark:border-gray-700 pt-6">
              <h3 className="font-medium text-lg mb-4">Add New Experience</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Company*</label>
                  <Input 
                    type="text" 
                    value={newExperience.company} 
                    onChange={(e) => setNewExperience({...newExperience, company: e.target.value})}
                    placeholder="Company Name"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Position*</label>
                  <Input 
                    type="text" 
                    value={newExperience.position} 
                    onChange={(e) => setNewExperience({...newExperience, position: e.target.value})}
                    placeholder="Job Title"
                    required
                  />
                </div>
              </div>
              
              <div className="mb-4">
                <label className="block text-sm font-medium mb-1">Location</label>
                <Input 
                  type="text" 
                  value={newExperience.location} 
                  onChange={(e) => setNewExperience({...newExperience, location: e.target.value})}
                  placeholder="City, State"
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Start Date*</label>
                  <Input 
                    type="month" 
                    value={newExperience.startDate} 
                    onChange={(e) => setNewExperience({...newExperience, startDate: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">End Date</label>
                  <div className="flex items-center gap-2">
                    <Input 
                      type="month" 
                      value={newExperience.endDate} 
                      onChange={(e) => setNewExperience({...newExperience, endDate: e.target.value})}
                      disabled={newExperience.current}
                    />
                    <label className="flex items-center gap-1 text-sm">
                      <input 
                        type="checkbox" 
                        checked={newExperience.current} 
                        onChange={(e) => setNewExperience({
                          ...newExperience, 
                          current: e.target.checked,
                          endDate: e.target.checked ? '' : newExperience.endDate
                        })}
                        className="rounded"
                      />
                      Current
                    </label>
                  </div>
                </div>
              </div>
              
              <div className="space-y-3 mb-4">
                <label className="block text-sm font-medium">Responsibilities & Achievements</label>
                
                {newExperience.description.map((desc, index) => (
                  <div key={index} className="flex gap-2">
                    <Input 
                      value={desc} 
                      onChange={(e) => updateBulletPoint(e.target.value, index)}
                      placeholder={`Achievement ${index + 1}`}
                      className="flex-1"
                    />
                    <Button 
                      type="button" 
                      variant="ghost" 
                      size="icon" 
                      className="text-red-500 hover:text-red-700 hover:bg-red-50"
                      onClick={() => removeBulletPoint(index)}
                      disabled={newExperience.description.length <= 1}
                    >
                      <XIcon className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
                
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="flex items-center gap-1"
                  onClick={() => addBulletPoint()}
                >
                  <PlusIcon className="h-4 w-4" /> Add Bullet Point
                </Button>
              </div>
              
              <Button type="submit" className="bg-secondary hover:bg-indigo-600">
                Add Experience
              </Button>
            </form>
          </div>
        )}
        
        {/* Education */}
        {activeSection === 'education' && (
          <div className="space-y-8">
            {/* Existing Education */}
            {resumeData.education.length > 0 && (
              <div className="space-y-6">
                <h3 className="font-medium text-lg">Your Education</h3>
                
                {resumeData.education.map((edu) => (
                  <div key={edu.id} className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h4 className="font-medium">{edu.degree} in {edu.field}</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{edu.institution}, {edu.location}</p>
                      </div>
                      <Button 
                        variant="ghost"
                        size="sm"
                        className="text-red-500 hover:text-red-700 hover:bg-red-50"
                        onClick={() => removeEducation(edu.id)}
                      >
                        <XIcon className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div>
                        <label className="block text-sm font-medium mb-1">Start Date</label>
                        <Input 
                          type="month" 
                          value={edu.startDate} 
                          onChange={(e) => updateEducation(edu.id, { startDate: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">End Date</label>
                        <Input 
                          type="month" 
                          value={edu.endDate} 
                          onChange={(e) => updateEducation(edu.id, { endDate: e.target.value })}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">Description (Optional)</label>
                      <Textarea 
                        value={edu.description} 
                        onChange={(e) => updateEducation(edu.id, { description: e.target.value })}
                        placeholder="Notable achievements, GPA, relevant coursework, etc."
                        rows={3}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
            
            {/* Add New Education Form */}
            <form onSubmit={handleAddEducation} className="border-t border-gray-200 dark:border-gray-700 pt-6">
              <h3 className="font-medium text-lg mb-4">Add New Education</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Institution*</label>
                  <Input 
                    type="text" 
                    value={newEducation.institution} 
                    onChange={(e) => setNewEducation({...newEducation, institution: e.target.value})}
                    placeholder="University or School Name"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Location</label>
                  <Input 
                    type="text" 
                    value={newEducation.location} 
                    onChange={(e) => setNewEducation({...newEducation, location: e.target.value})}
                    placeholder="City, State"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Degree*</label>
                  <Input 
                    type="text" 
                    value={newEducation.degree} 
                    onChange={(e) => setNewEducation({...newEducation, degree: e.target.value})}
                    placeholder="Bachelor of Science"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Field of Study</label>
                  <Input 
                    type="text" 
                    value={newEducation.field} 
                    onChange={(e) => setNewEducation({...newEducation, field: e.target.value})}
                    placeholder="Computer Science"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Start Date*</label>
                  <Input 
                    type="month" 
                    value={newEducation.startDate} 
                    onChange={(e) => setNewEducation({...newEducation, startDate: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">End Date</label>
                  <Input 
                    type="month" 
                    value={newEducation.endDate} 
                    onChange={(e) => setNewEducation({...newEducation, endDate: e.target.value})}
                  />
                </div>
              </div>
              
              <div className="mb-4">
                <label className="block text-sm font-medium mb-1">Description (Optional)</label>
                <Textarea 
                  value={newEducation.description} 
                  onChange={(e) => setNewEducation({...newEducation, description: e.target.value})}
                  placeholder="Notable achievements, GPA, relevant coursework, etc."
                  rows={3}
                />
              </div>
              
              <Button type="submit" className="bg-secondary hover:bg-indigo-600">
                Add Education
              </Button>
            </form>
          </div>
        )}
        
        {/* Skills */}
        {activeSection === 'skills' && (
          <div className="space-y-6">
            {/* Existing Skills */}
            <div>
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-medium text-lg">Your Skills</h3>
                <AIEnhanceButton 
                  type="skills"
                  content={resumeData.skills.map(skill => skill.name)}
                  jobTitle={resumeData.personalInfo.jobTitle}
                  onEnhanced={(enhanced) => {
                    const newSkills = (enhanced as string[]).filter(skill => 
                      !resumeData.skills.some(s => s.name.toLowerCase() === skill.toLowerCase())
                    );
                    newSkills.forEach(skill => addSkill({ name: skill }));
                  }}
                />
              </div>
              
              <div className="flex flex-wrap gap-2 mb-6">
                {resumeData.skills.map((skill) => (
                  <div key={skill.id} className="flex items-center bg-gray-100 dark:bg-gray-700 rounded-full px-3 py-1">
                    <span className="text-sm mr-1">{skill.name}</span>
                    <button
                      onClick={() => removeSkill(skill.id)}
                      className="text-gray-500 hover:text-red-500"
                      aria-label={`Remove ${skill.name}`}
                    >
                      <XIcon className="h-3 w-3" />
                    </button>
                  </div>
                ))}
                
                {resumeData.skills.length === 0 && (
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    No skills added yet. Add some skills below.
                  </p>
                )}
              </div>
            </div>
            
            {/* Add New Skill */}
            <form onSubmit={handleAddSkill} className="flex items-center gap-2">
              <Input 
                type="text" 
                value={newSkill} 
                onChange={(e) => setNewSkill(e.target.value)}
                placeholder="Add a skill (e.g. JavaScript, Project Management, etc.)"
                className="flex-1"
              />
              <Button type="submit" className="bg-secondary hover:bg-indigo-600">
                Add
              </Button>
            </form>
            
            <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <h4 className="font-medium mb-2">Skill Tips</h4>
              <ul className="text-sm space-y-1 list-disc pl-5">
                <li>Include both technical and soft skills</li>
                <li>Prioritize skills mentioned in the job description</li>
                <li>Be specific (e.g. "React.js" instead of just "JavaScript")</li>
                <li>List 8-12 skills for optimal impact</li>
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
