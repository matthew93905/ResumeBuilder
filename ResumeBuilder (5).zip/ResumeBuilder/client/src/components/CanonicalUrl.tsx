import { useLocation } from "wouter";
import { Helmet } from "react-helmet-async";
import { useEffect, useState } from "react";

interface CanonicalUrlProps {
  path?: string;
  removedParams?: string[];
  preservedParams?: string[];
  forceHttps?: boolean;
}

/**
 * Component to generate and add canonical URLs to prevent duplicate content issues
 * @param path Optional custom path (defaults to current URL path)
 * @param removedParams Optional array of query parameters to exclude from canonical URL
 * @param preservedParams Optional array of query parameters to preserve in canonical URL (overrides removedParams)
 * @param forceHttps Optional boolean to force HTTPS in canonical URL even if current page is HTTP
 */
export default function CanonicalUrl({ 
  path,
  removedParams = [
    // UTM parameters
    'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'utm_id',
    // Social media click IDs
    'fbclid', 'gclid', 'msclkid', 'ttclid', 'twclid', 'igshid',
    // Other tracking parameters
    'ref', 'referral', 'source', 'affiliate_id', 'partner', 'coupon',
    // Session and click IDs
    'session_id', 'click_id', 'cid', 'sid',
    // Device and platform identifiers
    'device', 'platform', 'browser',
    // Custom campaign tracking
    'campaign', 'campaign_id', 'adset', 'adgroup', 'placement'
  ],
  preservedParams = [],
  forceHttps = true
}: CanonicalUrlProps) {
  const [location] = useLocation();
  const [canonicalUrl, setCanonicalUrl] = useState<string>("");

  useEffect(() => {
    // Use window to get the full URL including query parameters
    if (typeof window !== 'undefined') {
      const url = new URL(window.location.href);
      
      // If a custom path is provided, use it instead of the current path
      if (path) {
        url.pathname = path;
      }
      
      // Force HTTPS if specified
      if (forceHttps && url.protocol === 'http:') {
        url.protocol = 'https:';
      }
      
      // Create a set of parameters to remove (all in removedParams except those in preservedParams)
      const finalRemoveParams = removedParams.filter(param => !preservedParams.includes(param));
      
      // First get all existing query parameters
      const allParams = Array.from(url.searchParams.keys());
      
      // Remove unwanted parameters
      allParams.forEach(param => {
        // Check if parameter isn't in the preserved list and is either in the remove list or isn't specifically preserved
        if (!preservedParams.includes(param) && 
            (finalRemoveParams.includes(param) || preservedParams.length > 0)) {
          url.searchParams.delete(param);
        }
      });
      
      // Ensure trailing slash for consistency
      if (!url.pathname.endsWith('/') && !url.pathname.includes('.')) {
        url.pathname = `${url.pathname}/`;
      }
      
      setCanonicalUrl(url.toString());
    }
  }, [location, path, removedParams, preservedParams, forceHttps]);

  if (!canonicalUrl) return null;

  return (
    <Helmet>
      <link rel="canonical" href={canonicalUrl} />
    </Helmet>
  );
}