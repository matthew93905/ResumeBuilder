import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Textarea } from './ui/textarea';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';
import { useToast } from '@/hooks/use-toast';
import { 
  Users, 
  MessageSquare, 
  CheckCircle2, 
  XCircle, 
  UserPlus, 
  AlertCircle,
  Edit3
} from 'lucide-react';

type Collaborator = {
  userId: number;
  username: string;
  role: string;
};

type CursorPosition = {
  userId: number;
  username: string;
  section: string;
  position: number;
};

type Comment = {
  id: number;
  userId: number;
  resumeId: number;
  content: string;
  section: string;
  resolved: boolean;
  createdAt: string;
  user: {
    id: number;
    username: string;
    fullName: string | null;
  };
};

interface CollaborativeEditorProps {
  resumeId: number;
  resumeData: any;
  onUpdateSection: (section: string, content: any) => void;
  userRole: string;
}

const CollaborativeEditor: React.FC<CollaborativeEditorProps> = ({
  resumeId,
  resumeData,
  onUpdateSection,
  userRole
}) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [connected, setConnected] = useState(false);
  const [activeCollaborators, setActiveCollaborators] = useState<Collaborator[]>([]);
  const [cursorPositions, setCursorPositions] = useState<CursorPosition[]>([]);
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState("");
  const [selectedSection, setSelectedSection] = useState<string | null>(null);
  const textareaRefs = useRef<{[key: string]: HTMLTextAreaElement | null}>({});
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  
  // Effect to fetch initial comments
  useEffect(() => {
    const fetchComments = async () => {
      try {
        const response = await fetch(`/api/resume/${resumeId}/comments`);
        if (response.ok) {
          const data = await response.json();
          setComments(data);
        }
      } catch (error) {
        console.error('Error fetching comments:', error);
      }
    };

    fetchComments();
  }, [resumeId]);

  // Setup WebSocket connection
  useEffect(() => {
    if (!user || !resumeId) return;
    
    const connectWebSocket = () => {
      // Clear any existing reconnect timeout
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      const ws = new WebSocket(wsUrl);
      
      ws.onopen = () => {
        // Send authentication message once connected
        ws.send(JSON.stringify({
          type: 'auth',
          userId: user.id,
          resumeId: resumeId
        }));
      };
      
      ws.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data);
          
          switch (message.type) {
            case 'auth_success':
              setConnected(true);
              toast({
                title: "Connected to collaborative session",
                description: message.data.message,
              });
              break;
              
            case 'error':
              toast({
                title: "Error",
                description: message.data.message,
                variant: "destructive"
              });
              break;
              
            case 'active_collaborators':
              setActiveCollaborators(message.data.collaborators);
              break;
              
            case 'collaborator_joined':
              toast({
                title: "Collaborator joined",
                description: `${message.data.username} has joined the session`,
              });
              // Update active collaborators list
              setActiveCollaborators(prev => {
                const existing = prev.find(c => c.userId === message.data.userId);
                if (existing) return prev;
                return [...prev, {
                  userId: message.data.userId,
                  username: message.data.username,
                  role: message.data.role
                }];
              });
              break;
              
            case 'collaborator_left':
              toast({
                title: "Collaborator left",
                description: `${message.data.username} has left the session`,
              });
              // Update active collaborators list
              setActiveCollaborators(prev => 
                prev.filter(c => c.userId !== message.data.userId)
              );
              // Remove cursor positions for this user
              setCursorPositions(prev => 
                prev.filter(c => c.userId !== message.data.userId)
              );
              break;
              
            case 'cursor_update':
              // Update cursor positions
              setCursorPositions(prev => {
                const filtered = prev.filter(c => c.userId !== message.data.userId);
                return [...filtered, {
                  userId: message.data.userId,
                  username: message.data.username,
                  section: message.data.section,
                  position: message.data.position
                }];
              });
              break;
              
            case 'section_updated':
              // Update local resume data
              onUpdateSection(message.data.section, message.data.content);
              toast({
                title: "Section updated",
                description: `${message.data.username} updated the ${message.data.section} section`,
              });
              break;
              
            case 'new_comment':
              // Add new comment to list
              setComments(prev => [message.data.comment, ...prev]);
              toast({
                title: "New comment",
                description: `New comment from ${message.data.comment.user.username}`,
              });
              break;
              
            case 'comment_updated':
              // Update comment in list
              setComments(prev => 
                prev.map(c => c.id === message.data.comment.id ? message.data.comment : c)
              );
              toast({
                title: "Comment updated",
                description: `Comment ${message.data.comment.resolved ? 'resolved' : 'unresolved'}`,
              });
              break;
              
            case 'pong':
              // Handle ping response
              break;
              
            default:
              console.warn('Unknown message type:', message.type);
          }
        } catch (error) {
          console.error('Error parsing message:', error);
        }
      };
      
      ws.onclose = () => {
        setConnected(false);
        // Attempt to reconnect after a delay
        reconnectTimeoutRef.current = setTimeout(connectWebSocket, 3000);
      };
      
      ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        toast({
          title: "Connection error",
          description: "Failed to connect to collaboration server",
          variant: "destructive"
        });
      };
      
      setSocket(ws);
      
      // Cleanup function to close socket when component unmounts
      return () => {
        ws.close();
        if (reconnectTimeoutRef.current) {
          clearTimeout(reconnectTimeoutRef.current);
        }
      };
    };
    
    connectWebSocket();
  }, [resumeId, user, toast, onUpdateSection]);
  
  // Function to send cursor position updates when user is typing
  const handleCursorPositionChange = useCallback((e: React.MouseEvent<HTMLTextAreaElement> | React.KeyboardEvent<HTMLTextAreaElement>, section: string) => {
    if (!socket || socket.readyState !== WebSocket.OPEN || !connected) return;
    
    const textarea = e.target as HTMLTextAreaElement;
    const position = textarea.selectionStart;
    
    socket.send(JSON.stringify({
      type: 'cursor_update',
      section,
      position
    }));
  }, [socket, connected]);
  
  // Function to send section content updates
  const handleSectionChange = useCallback((section: string, content: any) => {
    if (!socket || socket.readyState !== WebSocket.OPEN || !connected) {
      // Update locally even if not connected
      onUpdateSection(section, content);
      return;
    }
    
    // First update locally
    onUpdateSection(section, content);
    
    // Then broadcast to others
    socket.send(JSON.stringify({
      type: 'edit_section',
      section,
      content
    }));
  }, [socket, connected, onUpdateSection]);
  
  // Function to add a comment
  const addComment = useCallback(() => {
    if (!socket || socket.readyState !== WebSocket.OPEN || !connected || !selectedSection || !newComment.trim()) return;
    
    socket.send(JSON.stringify({
      type: 'add_comment',
      section: selectedSection,
      content: newComment.trim()
    }));
    
    setNewComment("");
  }, [socket, connected, selectedSection, newComment]);
  
  // Function to resolve/unresolve a comment
  const toggleCommentResolution = useCallback((commentId: number, resolved: boolean) => {
    if (!socket || socket.readyState !== WebSocket.OPEN || !connected) return;
    
    socket.send(JSON.stringify({
      type: 'resolve_comment',
      commentId,
      resolved
    }));
  }, [socket, connected]);
  
  // Send ping periodically to keep connection alive
  useEffect(() => {
    if (!socket || !connected) return;
    
    const interval = setInterval(() => {
      if (socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({ type: 'ping' }));
      }
    }, 30000); // 30 seconds
    
    return () => clearInterval(interval);
  }, [socket, connected]);
  
  // Function to render cursor indicators in textareas
  const renderCursorIndicators = (section: string) => {
    const sectionCursors = cursorPositions.filter(c => 
      c.section === section && c.userId !== user?.id
    );
    
    if (sectionCursors.length === 0) return null;
    
    return (
      <div className="absolute right-2 top-2 flex space-x-1">
        {sectionCursors.map(cursor => (
          <TooltipProvider key={cursor.userId}>
            <Tooltip>
              <TooltipTrigger asChild>
                <div 
                  className="h-6 w-6 rounded-full bg-blue-500 flex items-center justify-center text-white text-xs font-bold"
                >
                  {cursor.username.substring(0, 2).toUpperCase()}
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p>{cursor.username} is editing this section</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        ))}
      </div>
    );
  };
  
  // Render the section comments
  const renderSectionComments = (section: string) => {
    const sectionComments = comments.filter(c => c.section === section);
    
    if (sectionComments.length === 0) return null;
    
    return (
      <div className="mt-2 space-y-2">
        <h4 className="text-sm font-medium flex items-center">
          <MessageSquare className="h-4 w-4 mr-1" />
          Comments ({sectionComments.length})
        </h4>
        {sectionComments.map(comment => (
          <Card key={comment.id} className={`p-3 text-sm ${comment.resolved ? 'bg-gray-100 dark:bg-gray-800 opacity-70' : 'bg-yellow-50 dark:bg-yellow-900/20'}`}>
            <div className="flex justify-between">
              <div className="font-medium">
                {comment.user.fullName || comment.user.username}
              </div>
              <div className="text-gray-500 dark:text-gray-400 text-xs">
                {new Date(comment.createdAt).toLocaleString()}
              </div>
            </div>
            <div className="py-2">{comment.content}</div>
            <div className="flex justify-between items-center">
              <Badge variant={comment.resolved ? "secondary" : "outline"}>
                {comment.resolved ? 'Resolved' : 'Unresolved'}
              </Badge>
              <div className="flex space-x-1">
                {!comment.resolved && (
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={() => toggleCommentResolution(comment.id, true)}
                    disabled={!(userRole === 'owner' || user?.id === comment.userId)}
                  >
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                  </Button>
                )}
                {comment.resolved && (
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={() => toggleCommentResolution(comment.id, false)}
                    disabled={!(userRole === 'owner' || user?.id === comment.userId)}
                  >
                    <XCircle className="h-4 w-4 text-red-500" />
                  </Button>
                )}
              </div>
            </div>
          </Card>
        ))}
      </div>
    );
  };
  
  return (
    <div className="mt-4 space-y-6">
      {/* Active Collaborators */}
      <div className="flex items-center mb-4">
        <div className="font-semibold mr-2 flex items-center">
          <Users className="h-5 w-5 mr-1" />
          Active Collaborators:
        </div>
        <div className="flex space-x-2">
          {activeCollaborators.length === 0 ? (
            <span className="text-gray-500 dark:text-gray-400 text-sm">No one else is currently editing</span>
          ) : (
            activeCollaborators.map(collab => (
              <Badge key={collab.userId} variant={collab.userId === user?.id ? "default" : "secondary"}>
                {collab.username} 
                {collab.role === 'owner' && <span className="ml-1 text-xs">(Owner)</span>}
                {collab.role === 'editor' && <span className="ml-1 text-xs">(Editor)</span>}
                {collab.role === 'viewer' && <span className="ml-1 text-xs">(Viewer)</span>}
              </Badge>
            ))
          )}
        </div>
        
        {userRole === 'owner' && (
          <Button className="ml-auto" size="sm" variant="outline">
            <UserPlus className="h-4 w-4 mr-1" />
            Invite Collaborator
          </Button>
        )}
      </div>
      
      {/* Connection Status */}
      <div className={`text-sm ${connected ? 'text-green-500' : 'text-red-500'} flex items-center mb-4`}>
        <div className={`w-2 h-2 rounded-full mr-2 ${connected ? 'bg-green-500' : 'bg-red-500'}`}></div>
        {connected ? 'Connected to collaboration server' : 'Disconnected - trying to reconnect...'}
      </div>
      
      {/* Comment Box */}
      {selectedSection && (
        <Card className="p-4 my-4 border-blue-500">
          <h3 className="font-medium mb-2">Add Comment to {selectedSection}</h3>
          <Textarea 
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            placeholder="Add a comment or suggestion..."
            className="min-h-[100px] mb-2"
          />
          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={() => setSelectedSection(null)}>
              Cancel
            </Button>
            <Button onClick={addComment} disabled={newComment.trim() === ''}>
              Add Comment
            </Button>
          </div>
        </Card>
      )}
      
      {/* Editable Sections */}
      {resumeData && Object.entries(resumeData).map(([section, content]: [string, any]) => {
        // Skip non-object sections
        if (typeof content !== 'object' || content === null) return null;
        
        // Handle array sections differently (experience, education, skills)
        if (Array.isArray(content)) {
          return (
            <div key={section} className="mb-8">
              <h3 className="text-lg font-semibold capitalize mb-3 flex items-center justify-between">
                {section}
                {userRole !== 'viewer' && (
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setSelectedSection(section)}
                    className="ml-2"
                  >
                    <MessageSquare className="h-4 w-4 mr-1" />
                    Comment
                  </Button>
                )}
              </h3>
              
              {renderSectionComments(section)}
              
              {content.map((item: any, index: number) => {
                const itemSection = `${section}.${index}`;
                
                return (
                  <div key={itemSection} className="relative border rounded-md p-4 mb-4">
                    {renderCursorIndicators(itemSection)}
                    
                    {Object.entries(item).map(([field, value]: [string, any]) => {
                      // Skip non-string fields for simplicity
                      if (typeof value !== 'string') return null;
                      
                      const fieldSection = `${itemSection}.${field}`;
                      
                      return (
                        <div key={fieldSection} className="mb-3">
                          <div className="flex items-center justify-between">
                            <label className="block text-sm font-medium mb-1 capitalize">
                              {field.replace(/([A-Z])/g, ' $1').trim()}
                            </label>
                            
                            {userRole !== 'viewer' && (
                              <div className="flex space-x-1">
                                <Button 
                                  variant="ghost" 
                                  size="sm"
                                  onClick={() => setSelectedSection(fieldSection)}
                                >
                                  <MessageSquare className="h-4 w-4" />
                                </Button>
                              </div>
                            )}
                          </div>
                          
                          <div className="relative">
                            {renderCursorIndicators(fieldSection)}
                            <Textarea
                              ref={el => textareaRefs.current[fieldSection] = el}
                              value={value}
                              onChange={(e) => {
                                // Only call handleSectionChange if user has edit permissions
                                if (userRole === 'owner' || userRole === 'editor') {
                                  const updatedItem = { ...item, [field]: e.target.value };
                                  const updatedArray = [...content];
                                  updatedArray[index] = updatedItem;
                                  handleSectionChange(section, updatedArray);
                                }
                              }}
                              onKeyUp={(e) => handleCursorPositionChange(e, fieldSection)}
                              onClick={(e) => handleCursorPositionChange(e, fieldSection)}
                              disabled={userRole === 'viewer'}
                              className={userRole === 'viewer' ? 'bg-gray-100 cursor-not-allowed' : ''}
                            />
                          </div>
                          
                          {renderSectionComments(fieldSection)}
                        </div>
                      );
                    })}
                  </div>
                );
              })}
            </div>
          );
        }
        
        // Handle object sections (personalInfo, summary)
        return (
          <div key={section} className="mb-8">
            <h3 className="text-lg font-semibold capitalize mb-3 flex items-center justify-between">
              {section}
              {userRole !== 'viewer' && (
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setSelectedSection(section)}
                  className="ml-2"
                >
                  <MessageSquare className="h-4 w-4 mr-1" />
                  Comment
                </Button>
              )}
            </h3>
            
            {renderSectionComments(section)}
            
            {Object.entries(content).map(([field, value]: [string, any]) => {
              // Skip non-string fields for simplicity
              if (typeof value !== 'string') return null;
              
              const fieldSection = `${section}.${field}`;
              
              return (
                <div key={fieldSection} className="mb-3">
                  <div className="flex items-center justify-between">
                    <label className="block text-sm font-medium mb-1 capitalize">
                      {field.replace(/([A-Z])/g, ' $1').trim()}
                    </label>
                    
                    {userRole !== 'viewer' && (
                      <div className="flex space-x-1">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => setSelectedSection(fieldSection)}
                        >
                          <MessageSquare className="h-4 w-4" />
                        </Button>
                      </div>
                    )}
                  </div>
                  
                  <div className="relative">
                    {renderCursorIndicators(fieldSection)}
                    <Textarea
                      ref={el => textareaRefs.current[fieldSection] = el}
                      value={value}
                      onChange={(e) => {
                        // Only call handleSectionChange if user has edit permissions
                        if (userRole === 'owner' || userRole === 'editor') {
                          handleSectionChange(section, { ...content, [field]: e.target.value });
                        }
                      }}
                      onKeyUp={(e) => handleCursorPositionChange(e, fieldSection)}
                      onClick={(e) => handleCursorPositionChange(e, fieldSection)}
                      disabled={userRole === 'viewer'}
                      className={userRole === 'viewer' ? 'bg-gray-100 cursor-not-allowed' : ''}
                    />
                  </div>
                  
                  {renderSectionComments(fieldSection)}
                </div>
              );
            })}
          </div>
        );
      })}
      
      {/* Collaboration Tips */}
      <Card className="p-4 bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
        <h3 className="font-medium flex items-center mb-2">
          <AlertCircle className="h-5 w-5 mr-2 text-blue-500" />
          Collaboration Tips
        </h3>
        <ul className="text-sm space-y-1 text-gray-700 dark:text-gray-300">
          <li className="flex items-start">
            <Edit3 className="h-4 w-4 mr-2 mt-0.5 text-blue-500" />
            {userRole === 'viewer' ? 
              "You are in view-only mode. You can add comments but can't edit content." :
              "You can edit content and add comments - other collaborators will see your changes in real-time."
            }
          </li>
          <li className="flex items-start">
            <MessageSquare className="h-4 w-4 mr-2 mt-0.5 text-blue-500" />
            Add comments to specific sections by clicking the comment button next to each field.
          </li>
          <li className="flex items-start">
            <Users className="h-4 w-4 mr-2 mt-0.5 text-blue-500" />
            You'll see indicators when others are editing specific sections.
          </li>
        </ul>
      </Card>
    </div>
  );
};

export default CollaborativeEditor;