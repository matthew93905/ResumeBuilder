import React from 'react';
import { Star, Quote } from 'lucide-react';
import { cn } from '@/lib/utils';

interface TestimonialProps {
  quote: string;
  author: string;
  position: string;
  company: string;
  rating: number;
  imageSrc?: string;
  className?: string;
}

const Testimonial = ({ quote, author, position, company, rating, imageSrc, className }: TestimonialProps) => {
  return (
    <div className={cn("bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md border border-border transition-all hover:shadow-lg", className)}>
      <div className="flex items-center space-x-1 mb-4">
        {Array.from({ length: 5 }).map((_, i) => (
          <Star
            key={i}
            className={`h-4 w-4 ${i < rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
          />
        ))}
      </div>
      
      <div className="relative mb-6">
        <Quote className="absolute -top-2 -left-2 h-6 w-6 text-primary opacity-20" />
        <p className="text-gray-700 dark:text-gray-300 italic relative z-10">{quote}</p>
      </div>
      
      <div className="flex items-center">
        {imageSrc ? (
          <div className="mr-4">
            <img
              src={imageSrc}
              alt={author}
              className="h-12 w-12 rounded-full object-cover"
            />
          </div>
        ) : (
          <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mr-4">
            <span className="text-primary font-semibold text-lg">{author.charAt(0)}</span>
          </div>
        )}
        
        <div>
          <h4 className="font-semibold text-base">{author}</h4>
          <p className="text-sm text-muted-foreground">
            {position} {company && `at ${company}`}
          </p>
        </div>
      </div>
    </div>
  );
};

const Testimonials = () => {
  const testimonials = [
    {
      quote: "ResumeX helped me revamp my resume and land interviews at top tech companies within a week! The AI suggestions were spot-on for my industry.",
      author: "Michael Chen",
      position: "Software Engineer",
      company: "Google",
      rating: 5,
    },
    {
      quote: "I was struggling to update my resume after 10 years at the same company. ResumeX made it so easy to highlight my transferable skills and achievements!",
      author: "Sarah Johnson",
      position: "Marketing Director",
      company: "Adobe",
      rating: 5,
    },
    {
      quote: "The collaborative editing feature allowed my career coach to give me real-time feedback. Well worth the premium subscription!",
      author: "David Rodriguez",
      position: "MBA Graduate",
      company: "Stanford Business School",
      rating: 4,
    },
    {
      quote: "As a career counselor, I recommend ResumeX to all my students. The templates are modern and ATS-friendly, and the customization options are excellent.",
      author: "Jennifer Williams",
      position: "Career Services Director",
      company: "University of Michigan",
      rating: 5,
    },
    {
      quote: "ResumeX's premium templates and AI suggestions helped me transition from military to civilian career seamlessly. Landed a job within a month!",
      author: "Robert Martinez",
      position: "Operations Manager",
      company: "Amazon",
      rating: 5,
    },
    {
      quote: "The cover letter builder complemented my resume perfectly. I received compliments on both documents during my interviews.",
      author: "Emily Thompson",
      position: "UX Designer",
      company: "Spotify",
      rating: 4,
    }
  ];

  return (
    <section className="py-16 bg-accent/20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">What Our Users Say</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Join thousands of professionals who have transformed their careers with ResumeX
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Testimonial
              key={index}
              {...testimonial}
              className={index === 0 ? "md:col-span-2 lg:col-span-1 border-primary/20" : ""}
            />
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <div className="inline-block rounded-full bg-white dark:bg-gray-800 px-6 py-3 shadow-sm border border-border">
            <p className="font-medium">
              <span className="text-primary font-bold">4.8</span> rating average from{" "}
              <span className="font-bold">2,400+</span> reviews
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;