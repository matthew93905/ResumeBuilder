import React from 'react';

// Essential Template Thumbnail with real content - Technology Industry
export const EssentialTemplateThumbnail: React.FC = () => (
  <div className="w-full h-full bg-white overflow-hidden flex flex-col">
    {/* Header */}
    <div className="p-4 flex items-center space-x-3">
      <div className="w-12 h-12 bg-gray-200 rounded-full flex-shrink-0 flex items-center justify-center">
        <svg className="w-8 h-8 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
          <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd"></path>
        </svg>
      </div>
      <div>
        <div className="font-semibold text-base">David Wilson</div>
        <div className="text-xs text-gray-600">Full-Stack Developer</div>
      </div>
    </div>
    
    {/* Contact details */}
    <div className="px-4 grid grid-cols-2 gap-1 text-xs text-gray-600">
      <div className="flex items-center space-x-1">
        <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
        </svg>
        <span>david@techdev.io</span>
      </div>
      <div className="flex items-center space-x-1">
        <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path>
        </svg>
        <span>(555) 123-4567</span>
      </div>
      <div className="flex items-center space-x-1">
        <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
        </svg>
        <span>San Francisco, CA</span>
      </div>
      <div className="flex items-center space-x-1">
        <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
        </svg>
        <span>github.com/davidw</span>
      </div>
    </div>
    
    {/* Summary */}
    <div className="p-3 pt-2">
      <div className="text-sm font-semibold border-b border-gray-200 pb-1 text-blue-600">
        Professional Summary
      </div>
      <p className="text-xs mt-2 text-gray-700 leading-tight">
        Full-stack developer with 8+ years building scalable cloud applications and microservices. Expert in React, Node.js, and serverless architectures with a passion for clean code and DevOps practices.
      </p>
    </div>
    
    {/* Experience */}
    <div className="px-3 pb-1">
      <div className="text-sm font-semibold border-b border-gray-200 pb-1 text-blue-600">
        Work Experience
      </div>
      <div className="mt-2">
        <div className="flex justify-between items-center">
          <div className="font-medium text-xs">Senior Software Engineer</div>
          <div className="text-xs text-gray-600 whitespace-nowrap">2020 - Present</div>
        </div>
        <div className="text-xs text-gray-600">Cloud Innovations Inc., San Francisco, CA</div>
        <ul className="text-xs mt-1.5 list-disc ml-3 space-y-1 text-gray-700">
          <li className="truncate">Architected microservices for enterprise SaaS platform</li>
          <li className="truncate">Led team of 5 engineers, improving delivery time by 35%</li>
        </ul>
      </div>
      
      <div className="mt-2.5">
        <div className="flex justify-between items-center">
          <div className="font-medium text-xs">Full-Stack Developer</div>
          <div className="text-xs text-gray-600 whitespace-nowrap">2017 - 2020</div>
        </div>
        <div className="text-xs text-gray-600">TechStars Inc., Austin, TX</div>
      </div>
    </div>
    
    {/* Skills with progress bars */}
    <div className="px-3 pt-1">
      <div className="text-sm font-semibold border-b border-gray-200 pb-1 text-blue-600">
        Skills
      </div>
      
      <div className="space-y-2 mt-2">
        <div>
          <div className="flex justify-between text-xs mb-1">
            <span>JavaScript/TypeScript</span>
            <span className="text-blue-600">95%</span>
          </div>
          <div className="w-full bg-gray-200 h-1.5 rounded-full">
            <div className="bg-blue-600 h-1.5 rounded-full" style={{width: '95%'}}></div>
          </div>
        </div>
        
        <div>
          <div className="flex justify-between text-xs mb-1">
            <span>React/Redux</span>
            <span className="text-blue-600">90%</span>
          </div>
          <div className="w-full bg-gray-200 h-1.5 rounded-full">
            <div className="bg-blue-600 h-1.5 rounded-full" style={{width: '90%'}}></div>
          </div>
        </div>
        
        <div>
          <div className="flex justify-between text-xs mb-1">
            <span>Node.js/Express</span>
            <span className="text-blue-600">85%</span>
          </div>
          <div className="w-full bg-gray-200 h-1.5 rounded-full">
            <div className="bg-blue-600 h-1.5 rounded-full" style={{width: '85%'}}></div>
          </div>
        </div>
      </div>
      
      <div className="flex flex-wrap gap-1.5 mt-3">
        <span className="px-2 py-0.5 bg-blue-50 text-blue-600 text-[10px] rounded-full border border-blue-100">AWS</span>
        <span className="px-2 py-0.5 bg-blue-50 text-blue-600 text-[10px] rounded-full border border-blue-100">Docker</span>
        <span className="px-2 py-0.5 bg-blue-50 text-blue-600 text-[10px] rounded-full border border-blue-100">GraphQL</span>
        <span className="px-2 py-0.5 bg-blue-50 text-blue-600 text-[10px] rounded-full border border-blue-100">MongoDB</span>
      </div>
    </div>
  </div>
);

// Executive Template Thumbnail with real content - Finance/Business Leadership Industry
export const ExecutiveTemplateThumbnail: React.FC = () => (
  <div className="w-full h-full bg-white overflow-hidden flex flex-col">
    {/* Header - centered for executive */}
    <div className="p-4 pt-5 text-center border-b-2 border-blue-800">
      <div className="font-serif font-semibold text-lg tracking-wide">VICTORIA REYNOLDS</div>
      <div className="text-xs text-blue-800 font-medium uppercase tracking-wider">Chief Financial Officer</div>
      
      {/* Contact row */}
      <div className="flex justify-center flex-wrap gap-x-4 mt-2 text-xs">
        <div className="flex items-center gap-1">
          <svg className="w-3 h-3 text-blue-800" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
          </svg>
          <span>victoria.r@globalfinance.com</span>
        </div>
        <div className="flex items-center gap-1">
          <svg className="w-3 h-3 text-blue-800" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path>
          </svg>
          <span>(555) 987-6543</span>
        </div>
        <div className="flex items-center gap-1">
          <svg className="w-3 h-3 text-blue-800" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
          </svg>
          <span>linkedin.com/in/vreynolds</span>
        </div>
      </div>
    </div>
    
    {/* Summary Box */}
    <div className="px-3 py-2 mx-2 mt-2 bg-gray-50 border-l-4 border-blue-800 shadow-sm">
      <div className="font-medium text-sm mb-1 text-blue-800">EXECUTIVE PROFILE</div>
      <p className="text-xs italic text-gray-700 leading-tight">
        Strategic financial executive with 15+ years guiding Fortune 500 companies through periods of growth, digital transformation, and market expansion. Expertise in M&A, capital optimization, and sustainable growth strategies.
      </p>
    </div>
    
    {/* Core Competencies */}
    <div className="px-3 py-2">
      <div className="font-medium text-sm text-blue-800 uppercase text-center mb-1.5">
        Core Competencies
      </div>
      <div className="grid grid-cols-2 gap-1.5">
        <div className="flex items-center gap-1.5">
          <div className="w-2 h-2 bg-blue-800 rounded-full"></div>
          <span className="text-xs">Strategic Planning</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-2 h-2 bg-blue-800 rounded-full"></div>
          <span className="text-xs">Financial Analysis</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-2 h-2 bg-blue-800 rounded-full"></div>
          <span className="text-xs">M&A Integration</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-2 h-2 bg-blue-800 rounded-full"></div>
          <span className="text-xs">Risk Management</span>
        </div>
      </div>
    </div>
    
    {/* Work Experience */}
    <div className="px-3 py-1">
      <div className="font-medium text-sm text-blue-800 uppercase mb-1.5">
        Professional Experience
      </div>
      
      <div className="mb-2">
        <div className="flex justify-between border-b border-gray-200 pb-0.5">
          <div className="font-bold text-xs uppercase">Chief Financial Officer</div>
          <div className="text-xs text-gray-600">2018 - Present</div>
        </div>
        <div className="text-xs font-medium">Global Financial Holdings, New York, NY</div>
        <ul className="text-xs list-inside space-y-0.5 mt-1 ml-1">
          <li className="truncate">• Led digital finance transformation resulting in 35% cost reduction</li>
          <li className="truncate">• Structured $2B acquisition financing with favorable terms</li>
        </ul>
      </div>
      
      <div className="mb-1">
        <div className="flex justify-between border-b border-gray-200 pb-0.5">
          <div className="font-bold text-xs uppercase">VP of Finance</div>
          <div className="text-xs text-gray-600">2012 - 2018</div>
        </div>
        <div className="text-xs font-medium">Investment Partners LLC, Boston, MA</div>
      </div>
    </div>
    
    {/* Education - two column */}
    <div className="px-3 mt-auto">
      <div className="font-medium text-sm text-blue-800 uppercase mb-1.5">
        Education
      </div>
      <div className="grid grid-cols-2 gap-2">
        <div className="bg-gray-50 p-2 rounded border border-gray-200">
          <div className="font-medium text-xs">MBA, Finance</div>
          <div className="text-xs text-gray-600">Harvard Business School</div>
          <div className="text-xs text-blue-800">2008</div>
        </div>
        <div className="bg-gray-50 p-2 rounded border border-gray-200">
          <div className="font-medium text-xs">BS, Economics</div>
          <div className="text-xs text-gray-600">University of Pennsylvania</div>
          <div className="text-xs text-blue-800">2003</div>
        </div>
      </div>
    </div>
  </div>
);

// Creative Template Thumbnail with real content - Design Industry 
export const CreativeTemplateThumbnail: React.FC = () => (
  <div className="w-full h-full overflow-hidden flex">
    {/* Sidebar */}
    <div className="bg-purple-700 text-white w-[30%] p-3 flex flex-col">
      {/* Photo */}
      <div className="w-16 h-16 mx-auto bg-white rounded-full mb-3 flex items-center justify-center overflow-hidden">
        <svg className="w-12 h-12 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
          <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd"></path>
        </svg>
      </div>
      
      <div className="text-center mb-3">
        <div className="text-sm font-medium tracking-wide">CONTACT</div>
        <div className="h-0.5 w-12 bg-white/60 mx-auto my-1"></div>
      </div>
      
      <div className="text-xs space-y-2">
        <div className="flex items-center gap-1.5">
          <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
          </svg>
          <span>john@designcraft.io</span>
        </div>
        <div className="flex items-center gap-1.5">
          <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path>
          </svg>
          <span>(555) 123-4567</span>
        </div>
        <div className="flex items-center gap-1.5">
          <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
          </svg>
          <span>San Francisco, CA</span>
        </div>
        <div className="flex items-center gap-1.5">
          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm-2 16h-2v-6h2v6zm-1-6.891c-.607 0-1.1-.496-1.1-1.109 0-.612.492-1.109 1.1-1.109s1.1.497 1.1 1.109c0 .613-.493 1.109-1.1 1.109zm8 6.891h-1.998v-2.861c0-1.881-2.002-1.722-2.002 0v2.861h-2v-6h2v1.093c.872-1.616 4-1.736 4 1.548v3.359z"/>
          </svg>
          <span>behance.net/johnanderson</span>
        </div>
      </div>
      
      <div className="mt-4 text-center">
        <div className="text-sm font-medium tracking-wide">SKILLS</div>
        <div className="h-0.5 w-12 bg-white/60 mx-auto my-1"></div>
      </div>
      
      <div className="mt-2 space-y-2.5">
        <div>
          <div className="flex justify-between text-xs mb-1">
            <span>UI Design</span>
            <span>95%</span>
          </div>
          <div className="w-full bg-purple-900/50 h-1.5 rounded-full">
            <div className="bg-white h-1.5 rounded-full" style={{width: '95%'}}></div>
          </div>
        </div>
        
        <div>
          <div className="flex justify-between text-xs mb-1">
            <span>UX Research</span>
            <span>85%</span>
          </div>
          <div className="w-full bg-purple-900/50 h-1.5 rounded-full">
            <div className="bg-white h-1.5 rounded-full" style={{width: '85%'}}></div>
          </div>
        </div>
        
        <div>
          <div className="flex justify-between text-xs mb-1">
            <span>Figma</span>
            <span>90%</span>
          </div>
          <div className="w-full bg-purple-900/50 h-1.5 rounded-full">
            <div className="bg-white h-1.5 rounded-full" style={{width: '90%'}}></div>
          </div>
        </div>
      </div>
      
      <div className="mt-4 text-center">
        <div className="text-sm font-medium tracking-wide">TOOLS</div>
        <div className="h-0.5 w-12 bg-white/60 mx-auto my-1"></div>
      </div>
      
      <div className="flex flex-wrap gap-1.5 mt-2 justify-center">
        <span className="px-2 py-0.5 bg-white/20 text-white text-[10px] rounded-full">Figma</span>
        <span className="px-2 py-0.5 bg-white/20 text-white text-[10px] rounded-full">Sketch</span>
        <span className="px-2 py-0.5 bg-white/20 text-white text-[10px] rounded-full">Adobe XD</span>
        <span className="px-2 py-0.5 bg-white/20 text-white text-[10px] rounded-full">Photoshop</span>
      </div>
    </div>
    
    {/* Main content */}
    <div className="bg-white flex-1 p-3">
      <div className="mb-3">
        <div className="text-xl font-bold text-purple-700">John Anderson</div>
        <div className="text-sm text-purple-600">Product Design Lead</div>
      </div>
      
      <div className="mb-3">
        <div className="text-sm font-semibold text-purple-700 border-b border-purple-200 pb-1">About Me</div>
        <p className="text-xs mt-1.5 leading-relaxed text-gray-700">
          Experienced Product Designer with over 8 years creating user-centered digital experiences for Fortune 500 companies and tech startups. Passionate about solving complex problems through intuitive, accessible, and beautiful interfaces.
        </p>
      </div>
      
      <div className="mb-3">
        <div className="text-sm font-semibold text-purple-700 border-b border-purple-200 pb-1">Experience</div>
        
        <div className="mt-2">
          <div className="flex items-center space-x-1.5">
            <div className="w-2 h-2 bg-purple-700 rounded-full"></div>
            <div className="text-xs font-medium">Product Design Lead</div>
          </div>
          <div className="flex justify-between ml-3.5">
            <div className="text-xs text-gray-600">DesignCraft Studio</div>
            <div className="text-xs text-gray-500">2021-Present</div>
          </div>
          <p className="text-xs ml-3.5 mt-1 text-gray-700">
            Leading a team of 5 designers to create innovative digital products for enterprise clients.
          </p>
        </div>
        
        <div className="mt-3">
          <div className="flex items-center space-x-1.5">
            <div className="w-2 h-2 bg-purple-700 rounded-full"></div>
            <div className="text-xs font-medium">Senior UX/UI Designer</div>
          </div>
          <div className="flex justify-between ml-3.5">
            <div className="text-xs text-gray-600">TechVision Inc.</div>
            <div className="text-xs text-gray-500">2018-2021</div>
          </div>
        </div>
      </div>
      
      <div>
        <div className="text-sm font-semibold text-purple-700 border-b border-purple-200 pb-1">Education</div>
        <div className="mt-2 ml-0.5">
          <div className="text-xs font-medium">BFA, Graphic Design</div>
          <div className="text-xs text-gray-600">Rhode Island School of Design</div>
          <div className="text-xs text-gray-500">2014</div>
        </div>
      </div>
    </div>
  </div>
);

// Minimalist Template Thumbnail with real content
export const MinimalistTemplateThumbnail: React.FC = () => (
  <div className="w-full h-full bg-white overflow-hidden p-3">
    {/* Header - minimalist with name and title */}
    <div className="mb-4 flex justify-between">
      <div>
        <div className="text-lg font-bold text-gray-900">Emma Thompson</div>
        <div className="text-sm text-gray-600">Marketing Director</div>
        <div className="text-xs text-gray-500 mt-1">emma@email.com • (555) 234-5678 • Chicago, IL</div>
      </div>
      <div className="w-12 h-12 bg-gray-100 rounded-full"></div>
    </div>
    
    <div className="w-full h-px bg-gray-200 mb-3"></div>
    
    {/* Summary */}
    <div className="mb-3">
      <div className="text-sm font-bold text-gray-900">Summary</div>
      <p className="text-xs text-gray-700 mt-1 leading-tight">
        Strategic marketing leader with a track record of developing award-winning campaigns and driving measurable business growth.
      </p>
    </div>
    
    {/* Experience */}
    <div className="mb-3">
      <div className="text-sm font-bold text-gray-900">Experience</div>
      
      <div className="mt-1.5">
        <div className="flex justify-between">
          <div className="text-xs font-medium text-gray-800">Marketing Director</div>
          <div className="text-xs text-gray-500">2020 - Present</div>
        </div>
        <div className="text-xs text-gray-600">Brandify Solutions</div>
      </div>
      
      <div className="mt-1.5">
        <div className="flex justify-between">
          <div className="text-xs font-medium text-gray-800">Senior Marketing Manager</div>
          <div className="text-xs text-gray-500">2017 - 2020</div>
        </div>
        <div className="text-xs text-gray-600">Global Media Group</div>
      </div>
    </div>
    
    <div className="w-full h-px bg-gray-200 mb-3"></div>
    
    {/* Skills */}
    <div>
      <div className="text-sm font-bold text-gray-900">Skills</div>
      <div className="flex flex-wrap gap-1.5 mt-1.5">
        <span className="px-2 py-0.5 bg-gray-100 text-gray-700 text-xs">Brand Strategy</span>
        <span className="px-2 py-0.5 bg-gray-100 text-gray-700 text-xs">Digital Marketing</span>
        <span className="px-2 py-0.5 bg-gray-100 text-gray-700 text-xs">Team Leadership</span>
      </div>
    </div>
  </div>
);

// Modern Template Thumbnail with real content
export const ModernTemplateThumbnail: React.FC = () => (
  <div className="w-full h-full overflow-hidden flex flex-col">
    {/* Blue header */}
    <div className="bg-blue-600 p-3 text-white">
      <div className="flex items-center space-x-3">
        <div className="w-12 h-12 bg-white rounded-full flex-shrink-0"></div>
        <div>
          <div className="font-bold text-base">Michael Rodriguez</div>
          <div className="text-xs text-blue-100">Software Developer</div>
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-x-2 gap-y-1 mt-2 text-xs">
        <div>michael.r@email.com</div>
        <div>(555) 456-7890</div>
        <div>San Francisco, CA</div>
        <div>github.com/mrodriguez</div>
      </div>
    </div>
    
    {/* Content */}
    <div className="p-3 flex-1">
      {/* Summary */}
      <div className="mb-3">
        <div className="text-sm font-semibold text-blue-600">PROFILE</div>
        <p className="text-xs mt-1 text-gray-700 leading-tight">
          Full-stack developer with expertise in JavaScript, React, and Node.js, passionate about creating efficient, user-friendly applications.
        </p>
      </div>
      
      {/* Experience */}
      <div className="mb-3">
        <div className="text-sm font-semibold text-blue-600">EXPERIENCE</div>
        
        <div className="mt-1">
          <div className="flex justify-between">
            <div className="text-xs font-semibold">Software Developer</div>
            <div className="text-xs text-gray-500">2021 - Present</div>
          </div>
          <div className="text-xs text-gray-600">Tech Innovations Inc.</div>
          <p className="text-xs mt-1 text-gray-700 ml-2">
            • Developed responsive web applications using React<br/>
            • Implemented RESTful APIs with Node.js and Express
          </p>
        </div>
      </div>
      
      {/* Skills */}
      <div>
        <div className="text-sm font-semibold text-blue-600">SKILLS</div>
        <div className="flex flex-wrap gap-1.5 mt-1.5">
          <span className="px-2 py-0.5 bg-blue-50 text-blue-700 text-xs rounded-full">JavaScript</span>
          <span className="px-2 py-0.5 bg-blue-50 text-blue-700 text-xs rounded-full">React</span>
          <span className="px-2 py-0.5 bg-blue-50 text-blue-700 text-xs rounded-full">Node.js</span>
          <span className="px-2 py-0.5 bg-blue-50 text-blue-700 text-xs rounded-full">TypeScript</span>
        </div>
      </div>
    </div>
  </div>
);

// Visual Impact Template Thumbnail with real content
export const VisualImpactTemplateThumbnail: React.FC = () => (
  <div className="w-full h-full overflow-hidden flex flex-col">
    {/* Gradient header */}
    <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-3 text-white">
      <div className="flex justify-between items-center">
        <div>
          <div className="font-bold text-lg">Alex Morgan</div>
          <div className="text-sm text-indigo-100">UX/UI Designer</div>
        </div>
        <div className="w-12 h-12 bg-white rounded-full border-2 border-white"></div>
      </div>
    </div>
    
    {/* Profile summary box */}
    <div className="mx-3 mt-3 p-3 bg-gray-50 rounded-lg border-l-4 border-indigo-500 shadow-sm">
      <div className="text-sm font-semibold text-indigo-600 mb-1">Professional Profile</div>
      <p className="text-xs text-gray-700 leading-tight">
        Creative designer with 5+ years of experience crafting engaging digital experiences that balance aesthetic appeal with functional usability.
      </p>
    </div>
    
    {/* Experience with timeline */}
    <div className="px-3 py-2">
      <div className="flex items-center mb-2">
        <span className="text-sm font-semibold"><span className="text-indigo-600">Experience</span> Timeline</span>
      </div>
      
      <div className="relative pl-5 border-l border-gray-200">
        <div className="absolute w-3 h-3 bg-indigo-600 rounded-full left-[-6px] top-0"></div>
        <div className="mb-2">
          <div className="text-xs font-bold text-indigo-600">Senior UX Designer</div>
          <div className="text-xs text-gray-600">DigitalCraft Studio • 2022-Present</div>
          <div className="text-xs mt-1 ml-2">Led redesign of flagship product, increasing user engagement by 40%</div>
        </div>
        
        <div className="absolute w-3 h-3 bg-indigo-600 rounded-full left-[-6px] top-[60px]"></div>
        <div>
          <div className="text-xs font-bold text-indigo-600">UI Designer</div>
          <div className="text-xs text-gray-600">CreativeWorks • 2019-2022</div>
        </div>
      </div>
    </div>
    
    {/* Skills */}
    <div className="px-3 py-1 mt-1">
      <div className="text-sm font-semibold mb-2"><span className="text-indigo-600">Key</span> Skills</div>
      <div className="space-y-1.5">
        <div>
          <div className="flex justify-between text-xs">
            <span>UX Research</span>
          </div>
          <div className="w-full bg-gray-200 h-1.5 rounded-full overflow-hidden">
            <div className="bg-gradient-to-r from-indigo-500 to-purple-500 h-1.5 rounded-full w-[90%]"></div>
          </div>
        </div>
        <div>
          <div className="flex justify-between text-xs">
            <span>Figma</span>
          </div>
          <div className="w-full bg-gray-200 h-1.5 rounded-full overflow-hidden">
            <div className="bg-gradient-to-r from-indigo-500 to-purple-500 h-1.5 rounded-full w-[85%]"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
);

// Infographic Template Thumbnail with real content
export const InfographicTemplateThumbnail: React.FC = () => (
  <div className="w-full h-full overflow-hidden flex flex-col">
    {/* Green header */}
    <div className="bg-emerald-600 p-3 text-white">
      <div className="flex justify-between items-center">
        <div>
          <div className="font-bold text-lg">Sarah Johnson</div>
          <div className="text-sm text-emerald-100">Data Analyst</div>
        </div>
        <div className="w-10 h-10 bg-white rounded-full"></div>
      </div>
    </div>
    
    {/* Summary section */}
    <div className="p-3">
      <div className="text-sm font-semibold text-emerald-600 mb-1">PROFILE</div>
      <div className="p-2 bg-emerald-50 rounded">
        <p className="text-xs text-gray-700">
          Data analyst with expertise in transforming complex datasets into actionable business insights through visualization and statistical analysis.
        </p>
      </div>
    </div>
    
    <div className="px-3 flex gap-3">
      {/* Stats box */}
      <div className="bg-emerald-50 p-2 rounded-lg flex-1">
        <div className="text-xs font-semibold text-emerald-600 mb-1">EXPERTISE</div>
        
        <div className="flex justify-between text-center mt-1">
          <div>
            <div className="w-6 h-14 bg-emerald-500 mx-auto"></div>
            <div className="text-[8px] mt-1">Data<br/>Analysis</div>
          </div>
          <div>
            <div className="w-6 h-10 bg-emerald-400 mx-auto"></div>
            <div className="text-[8px] mt-1">Python</div>
          </div>
          <div>
            <div className="w-6 h-8 bg-emerald-300 mx-auto"></div>
            <div className="text-[8px] mt-1">SQL</div>
          </div>
        </div>
      </div>
      
      {/* Skills list */}
      <div className="bg-emerald-50 p-2 rounded-lg flex-1">
        <div className="text-xs font-semibold text-emerald-600 mb-1">SKILLS</div>
        
        <div className="space-y-1">
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-emerald-600"></div>
            <div className="text-xs">Data Visualization</div>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-emerald-600"></div>
            <div className="text-xs">Statistical Analysis</div>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-emerald-600"></div>
            <div className="text-xs">Machine Learning</div>
          </div>
        </div>
      </div>
    </div>
    
    {/* Experience timeline */}
    <div className="p-3 mt-1">
      <div className="text-sm font-semibold text-emerald-600 mb-1">EXPERIENCE</div>
      
      <div className="bg-emerald-50 p-2 rounded-lg">
        <div className="flex justify-between">
          <div className="text-xs font-medium">Senior Data Analyst</div>
          <div className="text-xs">2021-Present</div>
        </div>
        <div className="text-xs text-gray-600">DataTech Solutions</div>
      </div>
    </div>
  </div>
);

// Executive Plus Template Thumbnail with real content
export const ExecutivePlusTemplateThumbnail: React.FC = () => (
  <div className="w-full h-full overflow-hidden flex flex-col bg-amber-50">
    {/* Header section */}
    <div className="bg-amber-50 border-b border-amber-200 p-3">
      <div className="text-center">
        <div className="font-serif font-bold text-lg text-amber-900">JONATHAN BARNES</div>
        <div className="text-sm text-amber-800">Chief Executive Officer</div>
      </div>
      
      <div className="flex justify-center space-x-4 mt-2 text-xs text-amber-800">
        <div>j.barnes@email.com</div>
        <div>(555) 765-4321</div>
        <div>London, UK</div>
      </div>
    </div>
    
    {/* Executive profile */}
    <div className="p-3">
      <div className="font-serif font-bold text-sm text-amber-900 mb-1">EXECUTIVE PROFILE</div>
      <div className="p-2 bg-white rounded border border-amber-200">
        <p className="text-xs text-amber-900 leading-tight">
          Visionary leader with 20+ years of experience transforming organizations and driving sustainable growth in competitive markets.
        </p>
      </div>
    </div>
    
    {/* Leadership Experience */}
    <div className="px-3 py-1">
      <div className="font-serif font-bold text-sm text-amber-900 mb-1">LEADERSHIP EXPERIENCE</div>
      
      <div className="mb-2">
        <div className="flex justify-between border-b border-amber-200 pb-0.5">
          <div className="text-xs font-semibold text-amber-900">CHIEF EXECUTIVE OFFICER</div>
          <div className="text-xs text-amber-800">2018 - Present</div>
        </div>
        <div className="text-xs text-amber-900">Global Enterprises Ltd</div>
        <div className="flex items-center space-x-1 mt-1">
          <div className="w-1 h-3 bg-amber-500"></div>
          <p className="text-xs text-amber-800">Led company through 40% growth and international expansion</p>
        </div>
      </div>
      
      <div>
        <div className="flex justify-between border-b border-amber-200 pb-0.5">
          <div className="text-xs font-semibold text-amber-900">CHIEF OPERATING OFFICER</div>
          <div className="text-xs text-amber-800">2012 - 2018</div>
        </div>
        <div className="text-xs text-amber-900">Market Leaders Inc</div>
      </div>
    </div>
    
    {/* Core Competencies */}
    <div className="p-3 mt-auto">
      <div className="font-serif font-bold text-sm text-amber-900 mb-1">CORE COMPETENCIES</div>
      <div className="flex flex-wrap gap-1.5">
        <span className="px-2 py-0.5 bg-amber-100 text-amber-800 text-xs border border-amber-200">Strategic Planning</span>
        <span className="px-2 py-0.5 bg-amber-100 text-amber-800 text-xs border border-amber-200">Business Development</span>
        <span className="px-2 py-0.5 bg-amber-100 text-amber-800 text-xs border border-amber-200">Leadership</span>
      </div>
    </div>
  </div>
);