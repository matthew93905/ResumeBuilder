import { Helmet } from "react-helmet-async";

interface FAQItem {
  id: string;
  question: string;
  answer: string;
}

interface FAQPageSchemaProps {
  faqs: FAQItem[];
  pageTitle?: string;
  pageDescription?: string;
}

/**
 * FAQPageSchema generates the structured data markup for the FAQ page
 * This helps search engines understand and display FAQ content in search results
 */
export default function FAQPageSchema({ 
  faqs, 
  pageTitle = "ResumeX Help Center - Frequently Asked Questions",
  pageDescription = "Find answers to common questions about using ResumeX to create professional resumes and advance your career."
}: FAQPageSchemaProps) {
  const faqPageSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": faqs.map(faq => ({
      "@type": "Question",
      "name": faq.question,
      "acceptedAnswer": {
        "@type": "Answer",
        "text": faq.answer
      }
    }))
  };

  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
      {
        "@type": "ListItem",
        "position": 1,
        "name": "Home",
        "item": "https://resumex.replit.app/"
      },
      {
        "@type": "ListItem",
        "position": 2,
        "name": "Help Center",
        "item": "https://resumex.replit.app/help"
      }
    ]
  };

  return (
    <Helmet>
      <title>{pageTitle}</title>
      <meta name="description" content={pageDescription} />
      <meta name="robots" content="index, follow" />
      <link rel="canonical" href="https://resumex.replit.app/help" />
      
      {/* FAQ Structured Data */}
      <script type="application/ld+json">
        {JSON.stringify(faqPageSchema)}
      </script>
      
      {/* Breadcrumb Structured Data */}
      <script type="application/ld+json">
        {JSON.stringify(breadcrumbSchema)}
      </script>
    </Helmet>
  );
}