import { useState } from "react";
import UpgradeModal from "./UpgradeModal";
import { Link } from "wouter";
import { CheckCircle, XCircle, ArrowRight, Zap } from "lucide-react";

export default function PricingSection() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  return (
    <>
      <section id="pricing" className="py-24 px-4 bg-white dark:bg-gray-800">
        <div className="container mx-auto">
          <div className="text-center mb-16 max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 py-2 px-4 bg-accent dark:bg-gray-700 rounded-full text-primary dark:text-white text-sm font-medium mb-4">
              <span className="flex-shrink-0 w-2 h-2 rounded-full bg-primary"></span>
              <span>Simple Pricing</span>
            </div>
            
            <h2 className="font-montserrat font-bold text-3xl md:text-4xl mb-6">
              Choose the <span className="text-gradient">Perfect Plan</span> for Your Career Goals
            </h2>
            
            <p className="text-lg text-muted-foreground">
              No complicated tiers, just straightforward options to help you create the perfect resume
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 max-w-5xl mx-auto">
            {/* Free Plan */}
            <div className="card-hover p-8 relative group transition-all">
              <div className="absolute -inset-px rounded-xl bg-gradient-to-r from-gray-200 to-gray-300 dark:from-gray-700 dark:to-gray-800 opacity-50 group-hover:opacity-100 transition-opacity"></div>
              <div className="relative p-6 bg-white dark:bg-gray-800 rounded-lg z-10">
                <div className="bg-accent w-12 h-12 rounded-lg flex items-center justify-center mb-6">
                  <Zap className="w-5 h-5 text-primary" />
                </div>
                
                <div className="mb-6">
                  <h3 className="text-xl font-semibold mb-2">Free</h3>
                  <div className="flex items-baseline gap-1">
                    <span className="text-4xl font-bold">$0</span>
                    <span className="text-muted-foreground">/forever</span>
                  </div>
                  <p className="text-muted-foreground mt-3">Perfect for creating a basic professional resume</p>
                </div>
                
                <hr className="my-6 border-border" />
                
                <ul className="space-y-4 mb-8">
                  <li className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-emerald-500 flex-shrink-0 mt-0.5" />
                    <span>2 basic ATS-friendly templates</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-emerald-500 flex-shrink-0 mt-0.5" />
                    <span>PDF export functionality</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-emerald-500 flex-shrink-0 mt-0.5" />
                    <span>Real-time preview editing</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-emerald-500 flex-shrink-0 mt-0.5" />
                    <span>Save up to 2 resumes</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <XCircle className="w-5 h-5 text-gray-400 flex-shrink-0 mt-0.5" />
                    <span className="text-muted-foreground">Premium templates</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <XCircle className="w-5 h-5 text-gray-400 flex-shrink-0 mt-0.5" />
                    <span className="text-muted-foreground">AI content suggestions</span>
                  </li>
                </ul>
                
                <Link href="/builder" className="block w-full py-3 border border-primary text-primary hover:bg-primary hover:text-white transition-colors rounded-lg font-medium text-center">
                  Get Started Free
                </Link>
              </div>
            </div>
            
            {/* Pro Plan */}
            <div className="relative group transition-all">
              <div className="absolute -inset-0.5 rounded-xl bg-gradient-to-r from-secondary to-primary blur-sm opacity-75 group-hover:opacity-100 transition-opacity"></div>
              <div className="relative p-6 bg-white dark:bg-gray-800 border-border rounded-lg z-10">
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-secondary to-primary text-white px-4 py-1 rounded-full text-sm font-medium">
                  Recommended
                </div>
                
                <div className="bg-primary/10 dark:bg-primary/20 w-12 h-12 rounded-lg flex items-center justify-center mb-6">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-primary">
                    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-xl font-semibold mb-2">Pro</h3>
                  <div className="flex items-baseline gap-1">
                    <span className="text-4xl font-bold">$9.99</span>
                    <span className="text-muted-foreground">/month</span>
                  </div>
                  <p className="text-muted-foreground mt-3">Everything you need for a standout professional resume</p>
                </div>
                
                <hr className="my-6 border-border" />
                
                <ul className="space-y-4 mb-8">
                  <li className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                    <span><strong>All Free features</strong>, plus:</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                    <span>Access to 12+ premium templates</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                    <span>AI-powered content suggestions</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                    <span>Unlimited resume versions</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                    <span>Advanced customization options</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                    <span>Priority customer support</span>
                  </li>
                </ul>
                
                <button 
                  className="gradient-btn w-full flex items-center justify-center gap-2"
                  onClick={() => setIsModalOpen(true)}
                >
                  Upgrade to Pro <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
          
          <div className="mt-16 text-center">
            <p className="text-muted-foreground max-w-3xl mx-auto mb-4">
              Both plans come with our 100% satisfaction guarantee. Try Pro risk-free with our 14-day money-back guarantee.
            </p>
            <div className="inline-flex items-center gap-1 text-primary">
              <span>Need a custom plan for your team?</span>
              <Link href="#" className="font-medium underline underline-offset-4">Contact us</Link>
            </div>
          </div>
        </div>
      </section>

      <UpgradeModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </>
  );
}
