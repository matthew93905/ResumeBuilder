import { Helmet } from "react-helmet-async";
import CanonicalUrl from "./CanonicalUrl";

interface RouteSEOProps {
  title: string;
  description: string;
  keywords?: string[];
  imagePath?: string;
  noIndex?: boolean;
  path?: string;
  type?: 'website' | 'article' | 'product';
  children?: React.ReactNode;
}

/**
 * Enhanced SEO component for individual routes with OpenGraph and Twitter metadata
 */
export default function RouteSEO({
  title,
  description,
  keywords = [],
  imagePath = "/images/resumex-banner.jpg",
  noIndex = false,
  path,
  type = "website",
  children
}: RouteSEOProps) {
  const imageUrl = imagePath.startsWith("http") 
    ? imagePath 
    : `https://resumex.replit.app${imagePath}`;
  
  const pageUrl = path 
    ? `https://resumex.replit.app${path}` 
    : undefined;

  return (
    <>
      <Helmet>
        {/* Primary Meta Tags */}
        <title>{title}</title>
        <meta name="description" content={description} />
        {keywords.length > 0 && (
          <meta name="keywords" content={keywords.join(", ")} />
        )}
        
        {/* Robots directives */}
        {noIndex ? (
          <meta name="robots" content="noindex, nofollow" />
        ) : (
          <meta name="robots" content="index, follow" />
        )}
        
        {/* Open Graph / Facebook */}
        <meta property="og:type" content={type} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="og:image" content={imageUrl} />
        <meta property="og:site_name" content="ResumeX" />
        
        {/* Twitter Card */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={title} />
        <meta name="twitter:description" content={description} />
        <meta name="twitter:image" content={imageUrl} />
      </Helmet>
      
      <CanonicalUrl path={path} />
      
      {children}
    </>
  );
}