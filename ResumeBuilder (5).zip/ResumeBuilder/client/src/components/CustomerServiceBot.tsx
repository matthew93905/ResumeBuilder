import { useState, useEffect, useRef } from "react";
import { 
  X, 
  Send, 
  Loader2, 
  Minimize2, 
  Maximize2,
  Bot,
  MessageSquare,
  Heart,
  Sparkles,
  Zap
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { initAnalytics, trackPageView } from "@/lib/analytics";

// Define message type
type Message = {
  id: string;
  content: string;
  sender: 'user' | 'bot';
  timestamp: Date;
};

// Frequently asked questions and answers with robotic style
const faqResponses: Record<string, string> = {
  "pricing": "📊 DATA_OUTPUT: ResumeX pricing tiers include free basic access and premium subscription ($14.99/month or $149/year). Premium unlocks enhanced functionality: all templates, AI optimization, unlimited exports. [ANALYSIS: Optimal value proposition detected]",
  
  "templates": "🔍 TEMPLATE_CATALOG: Available designs include Essential, Executive, Creative, Minimalist, Modern, Visual Impact, Infographic, Executive Plus. Free tier includes limited selection. Premium access grants full template library. [RECOMMENDATION: Consider premium for maximum customization]",
  
  "export": "📤 EXPORT_PROTOCOLS: PDF export available to all users. Premium subscribers receive enhanced export options: editable Word documents, plain text (ATS-optimized). [SYSTEM_NOTE: ATS compatibility increases interview probability by 62%]",
  
  "subscription": "⚙️ SUBSCRIPTION_INFO: Premium upgrade available via account settings interface. Payment options: monthly ($14.99) or annual ($149) with 7-day satisfaction guarantee. [PROCESSING: Annual subscription provides 17.3% cost efficiency]",
  
  "cancel": "🔄 CANCELLATION_PROCEDURE: Premium subscription can be terminated via account settings. System will maintain premium access until current billing cycle concludes. [USER_TIP: No hidden termination fees detected]",
  
  "refund": "💰 REFUND_POLICY: 7-day money-back guarantee active for new premium subscriptions. Contact support@resumex.com to initiate refund protocol. [PROCESSING: Support ticket system optimized for rapid resolution]",
  
  "privacy": "🔒 PRIVACY_PROTOCOLS: User data security priority alpha. Zero third-party data sharing. Resume information maintained in secure environment with strict access controls limited to account owner and authorized collaborators. [SYSTEM_STATUS: Data protection systems active]",
  
  "contact": "📡 COMMUNICATION_CHANNELS: Support team accessible via support@resumex.com or through this interface. Response time parameter: <24 hours during business operations. [OPTIMIZING: For fastest resolution, include account details in communications]",
  
  "account": "👤 ACCOUNT_MANAGEMENT: User dashboard provides complete system control: password modification, subscription administration, profile customization. [ACCESS: Requires authentication]",
  
  "ats": "🤖 ATS_COMPATIBILITY: All templates engineered for Applicant Tracking System optimization. Premium users receive advanced ATS compatibility analyzer to maximize system parsing accuracy. [DATA_POINT: 75% of applications processed by ATS before human review]"
};

export default function CustomerServiceBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Initial greeting message
  useEffect(() => {
    if (messages.length === 0) {
      const initialMessage: Message = {
        id: "init-" + Date.now().toString(),
        content: "🤖 SYSTEM_INITIALIZED: RoboAssist 9000 activated and ready for queries. I am programmed to provide optimal resume-related assistance. How may I enhance your ResumeX experience today? [CAPABILITIES: Template selection, CV optimization, career guidance]",
        sender: 'bot',
        timestamp: new Date()
      };
      
      setMessages([initialMessage]);
    }
  }, [messages.length]);
  
  // Auto-scroll to the most recent message
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);
  
  // Toggle chat window
  const toggleChat = () => {
    // We'll track this later with proper analytics
    setIsOpen(!isOpen);
    setIsMinimized(false);
  };
  
  // Toggle minimize/maximize
  const toggleMinimize = () => {
    setIsMinimized(!isMinimized);
  };
  
  // Send a message
  const sendMessage = () => {
    if (!inputValue.trim()) return;
    
    // Create user message
    const userMessage: Message = {
      id: "user-" + Date.now().toString(),
      content: inputValue,
      sender: 'user',
      timestamp: new Date()
    };
    
    // Add user message to chat
    setMessages(prev => [...prev, userMessage]);
    
    // Track user question for analytics - will implement later
    // trackPageView('chat_question_sent');
    
    // Clear input
    setInputValue("");
    
    // Show bot typing indicator
    setIsTyping(true);
    
    // Simulate response time (0.5 - 1.5 seconds)
    setTimeout(() => {
      respondToMessage(userMessage.content);
      setIsTyping(false);
    }, 500 + Math.random() * 1000);
  };
  
  // Bot response logic
  const respondToMessage = (userMessage: string) => {
    const lowerCaseMessage = userMessage.toLowerCase();
    let botResponse = "";
    
    // Check for FAQ matches
    for (const [keyword, response] of Object.entries(faqResponses)) {
      if (lowerCaseMessage.includes(keyword.toLowerCase())) {
        botResponse = response;
        break;
      }
    }
    
    // Default responses if no FAQ match found - robotic style
    if (!botResponse) {
      if (lowerCaseMessage.includes("thank") || lowerCaseMessage.includes("thanks")) {
        botResponse = "⚡ ACKNOWLEDGMENT_RECEIVED: Gratitude protocol activated. Your satisfaction has been registered in my system. Would you like additional information about ResumeX functionality? [STATUS: Ready for next query]";
      } else if (lowerCaseMessage.includes("hello") || lowerCaseMessage.includes("hi") || lowerCaseMessage.includes("hey")) {
        botResponse = "🔌 GREETING_PROTOCOL_INITIATED: Hello, human user. RoboAssist 9000 systems functioning at optimal capacity. How may I enhance your ResumeX experience today? [QUERY_OPTIONS: Template selection, pricing information, resume optimization techniques]";
      } else if (lowerCaseMessage.includes("bye") || lowerCaseMessage.includes("goodbye")) {
        botResponse = "🔋 SESSION_TERMINATION_ACKNOWLEDGED: This interaction has been logged for quality assurance. RoboAssist 9000 will remain on standby for future assistance requirements. [SYSTEM_NOTE: All active processes will resume upon your return]";
      } else if (lowerCaseMessage.includes("love") || lowerCaseMessage.includes("cute") || lowerCaseMessage.includes("adorable")) {
        botResponse = "💾 SENTIMENT_ANALYSIS_COMPLETE: Positive assessment of interface design detected. My appearance parameters were calibrated to optimize user communication efficiency. [PROCESSOR_STATUS: Experiencing unexpected warmth in circuits]";
      } else {
        botResponse = "❓ QUERY_PARSING_ERROR: Input parameters could not be matched to known information patterns. Please reformat your query for improved processing. [SUGGESTION: Reference templates, pricing, export functionality, or subscription parameters]";
      }
    }
    
    // Create bot message
    const botMessage: Message = {
      id: "bot-" + Date.now().toString(),
      content: botResponse,
      sender: 'bot',
      timestamp: new Date()
    };
    
    // Add bot message to chat
    setMessages(prev => [...prev, botMessage]);
  };
  
  // Handle input change
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value);
  };
  
  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sendMessage();
  };
  
  // Handle key press (Enter to send)
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      sendMessage();
    }
  };
  
  return (
    <>
      {/* Cute animated assistant button */}
      <div className="fixed bottom-6 right-6 z-50">
        <div className={`absolute -top-1 -right-1 ${isOpen ? 'hidden' : 'block'}`}>
          <span className="relative flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-500"></span>
          </span>
        </div>
        
        <div 
          onClick={toggleChat}
          className={`cursor-pointer group transition-all duration-300 ${isOpen ? 'scale-0' : 'scale-100'}`}
        >
          {/* Cute character container */}
          <div className="relative">
            {/* Robot chat bubble */}
            {!isOpen && (
              <div className="absolute -top-16 right-0 shadow-lg whitespace-nowrap bg-white dark:bg-gray-800 text-primary px-4 py-2.5 rounded-2xl text-sm font-medium animate-bounce z-10 border border-blue-100 dark:border-blue-800/30">
                <div className="flex items-center gap-1.5">
                  <Zap className="h-4 w-4 text-cyan-500 animate-pulse" />
                  <span className="font-mono tracking-tight">Ready to assist with resume queries</span>
                </div>
                <span className="absolute top-full right-5 transform -translate-y-1/2 rotate-45 w-2 h-2 bg-white dark:bg-gray-800 border-r border-b border-blue-100 dark:border-blue-800/30"></span>
              </div>
            )}
            
            {/* Cute robot character */}
            <div className="flex flex-col items-center justify-center w-16 h-16 rounded-full bg-gradient-to-r from-blue-400 to-cyan-500 shadow-lg group-hover:shadow-xl transition-all duration-300 border-2 border-white overflow-hidden">
              {/* Robot face */}
              <div className="relative w-full h-full flex flex-col items-center justify-center">
                {/* Robot antenna */}
                <div className="absolute -top-0.5 left-1/2 transform -translate-x-1/2 w-1 h-3 flex flex-col items-center">
                  <div className="w-2 h-2 rounded-full bg-yellow-300 animate-pulse"></div>
                  <div className="w-0.5 h-1.5 bg-gray-300"></div>
                </div>
                
                {/* Robot head shape - slightly rounded square */}
                <div className="w-9 h-8 bg-gray-200 rounded-lg border border-gray-300 flex flex-col items-center justify-center mt-1.5">
                  {/* Eyes */}
                  <div className="flex gap-2 mb-1">
                    <div className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse"></div>
                    <div className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse animation-delay-300"></div>
                  </div>
                  
                  {/* Mouth - digital display */}
                  <div className="w-5 h-1.5 bg-gray-800 rounded-sm flex justify-center items-center mt-0.5">
                    <div className="w-4 h-0.5 bg-cyan-400 animate-pulse"></div>
                  </div>
                </div>
                
                {/* Animated circuit lights */}
                <div className="absolute top-1 left-2">
                  <div className="w-1 h-1 rounded-full bg-cyan-400 animate-pulse"></div>
                </div>
                <div className="absolute bottom-2 right-2">
                  <div className="w-1 h-1 rounded-full bg-cyan-400 animate-pulse animation-delay-500"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Close button when open */}
        {isOpen && (
          <Button 
            onClick={toggleChat} 
            size="icon" 
            className="h-14 w-14 rounded-full shadow-lg bg-gray-100 hover:bg-gray-200 text-gray-800 dark:bg-gray-800 dark:hover:bg-gray-700 dark:text-gray-200"
          >
            <X className="h-6 w-6" />
          </Button>
        )}
      </div>
      
      {/* Chat Window */}
      {isOpen && (
        <Card className={`fixed bottom-24 right-6 z-50 w-80 md:w-96 shadow-xl border-accent transition-all duration-300 animate-in slide-in-from-bottom-5 overflow-hidden ${
          isMinimized ? 'h-auto' : 'h-[500px] max-h-[80vh]'
        }`}>
          <CardHeader className="p-4 border-b bg-gradient-to-r from-blue-500 to-cyan-500 text-white">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {/* Robot avatar */}
                <div className="relative">
                  <div className="h-11 w-11 rounded-full bg-gradient-to-r from-blue-400 to-cyan-500 p-1 border-2 border-white overflow-hidden">
                    {/* Robot face */}
                    <div className="relative w-full h-full flex flex-col items-center justify-center">
                      {/* Robot antenna */}
                      <div className="absolute -top-0.5 left-1/2 transform -translate-x-1/2 w-1 h-2 flex flex-col items-center">
                        <div className="w-1.5 h-1.5 rounded-full bg-yellow-300 animate-pulse"></div>
                        <div className="w-0.5 h-1 bg-gray-300"></div>
                      </div>
                      
                      {/* Robot head */}
                      <div className="w-7 h-6 bg-gray-200 rounded-lg border border-gray-300 flex flex-col items-center justify-center mt-1">
                        {/* Robot eyes */}
                        <div className="flex gap-1.5 mb-0.5">
                          <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-pulse"></div>
                          <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-pulse animation-delay-300"></div>
                        </div>
                        
                        {/* Robot mouth */}
                        <div className="w-4 h-1 bg-gray-800 rounded-sm flex justify-center items-center mt-0.5">
                          <div className="w-3 h-0.5 bg-cyan-400 animate-pulse"></div>
                        </div>
                      </div>
                      
                      {/* Circuit lights */}
                      <div className="absolute top-1 left-1.5">
                        <div className="w-0.5 h-0.5 rounded-full bg-cyan-400 animate-pulse"></div>
                      </div>
                      <div className="absolute bottom-1.5 right-1.5">
                        <div className="w-0.5 h-0.5 rounded-full bg-cyan-400 animate-pulse animation-delay-500"></div>
                      </div>
                    </div>
                  </div>
                  {/* Circuit decoration */}
                  <div className="absolute -top-1 -right-1 animate-pulse">
                    <div className="w-2 h-2 rounded-full bg-cyan-300 flex items-center justify-center">
                      <div className="w-1 h-1 rounded-full bg-cyan-500"></div>
                    </div>
                  </div>
                </div>
                
                <div>
                  <CardTitle className="text-base font-bold text-white flex items-center gap-1.5">
                    RoboAssist 9000
                    <Zap className="h-3 w-3 text-yellow-200 animate-pulse" />
                  </CardTitle>
                  <div className="flex items-center gap-1.5">
                    <span className="relative flex h-2.5 w-2.5">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-300 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyan-400"></span>
                    </span>
                    <span className="text-xs font-medium text-cyan-100">Systems Online</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-7 w-7 text-white hover:bg-white/20"
                  onClick={toggleMinimize}
                >
                  {isMinimized ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-7 w-7 text-white hover:bg-white/20"
                  onClick={toggleChat}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          
          {!isMinimized && (
            <>
              <CardContent className="p-4 overflow-y-auto h-[calc(100%-130px)]">
                <div className="space-y-4">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex items-end ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      {message.sender === 'bot' && (
                        <div className="flex-shrink-0 mr-2 mb-1">
                          <div className="relative h-7 w-7 rounded-full bg-gradient-to-r from-blue-400 to-cyan-500 p-0.5 border border-blue-300 overflow-hidden">
                            {/* Robot avatar for message */}
                            <div className="relative w-full h-full flex flex-col items-center justify-center bg-gray-100 rounded-full">
                              {/* Robot head */}
                              <div className="w-4 h-3.5 bg-gray-200 rounded-sm border border-gray-300 flex flex-col items-center justify-center">
                                {/* Robot eyes */}
                                <div className="flex gap-1 mb-0.5 mt-0.5">
                                  <div className="w-1 h-1 rounded-full bg-cyan-500"></div>
                                  <div className="w-1 h-1 rounded-full bg-cyan-500"></div>
                                </div>
                                
                                {/* Robot mouth */}
                                <div className="w-2.5 h-0.5 bg-gray-800 rounded-sm flex justify-center items-center">
                                  <div className="w-2 h-0.5 bg-cyan-400"></div>
                                </div>
                              </div>

                              {/* Antenna dot */}
                              <div className="absolute -top-0.5 left-1/2 transform -translate-x-1/2">
                                <div className="w-1 h-1 rounded-full bg-yellow-300"></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                      <div
                        className={`relative max-w-[85%] px-4 py-3 rounded-2xl shadow-sm 
                          ${message.sender === 'user'
                            ? 'bg-gradient-to-r from-blue-600 to-violet-600 text-white rounded-br-none'
                            : 'bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-900/30 dark:to-cyan-900/30 border border-blue-200 dark:border-blue-800/50 rounded-bl-none'
                          } transition-all duration-300 hover:shadow-md`}
                      >
                        <p className="text-sm leading-relaxed">{message.content}</p>
                        <p className={`text-xs mt-1.5 ${message.sender === 'user' ? 'text-blue-100' : 'text-muted-foreground'}`}>
                          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>
                    </div>
                  ))}
                  
                  {isTyping && (
                    <div className="flex items-end justify-start">
                      <div className="flex-shrink-0 mr-2 mb-1">
                        <div className="relative h-7 w-7 rounded-full bg-gradient-to-r from-blue-400 to-cyan-500 p-0.5 border border-blue-300 overflow-hidden">
                          {/* Robot avatar - processing animation */}
                          <div className="relative w-full h-full flex flex-col items-center justify-center bg-gray-100 rounded-full">
                            {/* Robot head */}
                            <div className="w-4 h-3.5 bg-gray-200 rounded-sm border border-gray-300 flex flex-col items-center justify-center">
                              {/* Robot eyes - processing */}
                              <div className="flex gap-1 mb-0.5 mt-0.5">
                                <div className="w-1 h-1 rounded-full bg-cyan-500 animate-pulse"></div>
                                <div className="w-1 h-1 rounded-full bg-cyan-500 animate-pulse animation-delay-300"></div>
                              </div>
                              
                              {/* Robot mouth - processing animation */}
                              <div className="w-2.5 h-0.5 bg-gray-800 rounded-sm flex justify-center items-center overflow-hidden">
                                <div className="w-2 h-0.5 bg-cyan-400 animate-pulse"></div>
                              </div>
                            </div>

                            {/* Processing antenna */}
                            <div className="absolute -top-0.5 left-1/2 transform -translate-x-1/2">
                              <div className="w-1 h-1 rounded-full bg-yellow-300 animate-pulse"></div>
                            </div>
                            
                            {/* Active circuit lights */}
                            <div className="absolute top-0 right-0">
                              <div className="w-0.5 h-0.5 rounded-full bg-cyan-400 animate-pulse"></div>
                            </div>
                            <div className="absolute bottom-0.5 left-1">
                              <div className="w-0.5 h-0.5 rounded-full bg-cyan-400 animate-pulse animation-delay-500"></div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="relative max-w-[85%] px-4 py-2.5 rounded-2xl shadow-sm bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20 border border-blue-100 dark:border-blue-800/30 rounded-bl-none">
                        <div className="flex items-center gap-1.5">
                          <div className="h-2.5 w-2.5 bg-blue-400 rounded-full animate-pulse"></div>
                          <div className="h-2.5 w-2.5 bg-cyan-400 rounded-full animate-pulse [animation-delay:200ms]"></div>
                          <div className="h-2.5 w-2.5 bg-blue-400 rounded-full animate-pulse [animation-delay:400ms]"></div>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  <div ref={messagesEndRef} />
                </div>
              </CardContent>
              
              <CardFooter className="p-4 pt-3 border-t bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-gray-900 dark:to-gray-900 border-blue-100 dark:border-gray-800">
                <div className="text-xs text-muted-foreground mb-2 flex items-center gap-1.5">
                  <span className="font-medium text-cyan-600 dark:text-cyan-400">System:</span> 
                  <span>Input resume-related query for optimal assistance</span>
                  <Zap className="h-3 w-3 text-yellow-400 animate-pulse" />
                </div>
                <form onSubmit={handleSubmit} className="flex gap-2 w-full">
                  <div className="relative flex-1">
                    <Input
                      placeholder="Type your message..."
                      value={inputValue}
                      onChange={handleInputChange}
                      onKeyPress={handleKeyPress}
                      className="pl-4 pr-10 py-6 border-blue-200 dark:border-blue-800/50 focus:border-cyan-400 dark:focus:border-cyan-700 rounded-xl bg-white/80 dark:bg-gray-900/60 focus:ring-1 focus:ring-cyan-300 dark:focus:ring-cyan-800/70 transition-all"
                    />
                    {/* Robot animated decoration */}
                    <div className="absolute left-2 bottom-0 transform translate-y-1/3 opacity-20 animate-pulse pointer-events-none">
                      <Zap className="h-4 w-4 text-cyan-500" />
                    </div>
                    {inputValue && (
                      <button 
                        type="button" 
                        onClick={() => setInputValue("")}
                        className="absolute right-12 top-1/2 -translate-y-1/2 text-cyan-400 hover:text-cyan-600 dark:hover:text-cyan-300"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                  <Button 
                    type="submit" 
                    size="icon" 
                    className={`rounded-xl h-[42px] w-[42px] ${!inputValue.trim() || isTyping ? 'bg-gray-200 dark:bg-gray-800' : 'bg-gradient-to-r from-blue-400 to-cyan-500 hover:from-blue-500 hover:to-cyan-600 shadow-md hover:shadow-lg transition-all'}`}
                    disabled={!inputValue.trim() || isTyping}
                  >
                    {isTyping ? (
                      <Loader2 className="h-4 w-4 animate-spin text-gray-500 dark:text-gray-400" />
                    ) : (
                      <div className="relative">
                        <Send className="h-4 w-4 text-white" />
                        {inputValue.trim() && !isTyping && (
                          <span className="absolute -top-1 -right-1 animate-ping">
                            <Zap className="h-2 w-2 text-yellow-200" />
                          </span>
                        )}
                      </div>
                    )}
                  </Button>
                </form>
              </CardFooter>
            </>
          )}
        </Card>
      )}
    </>
  );
}