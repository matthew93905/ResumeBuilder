import { Helmet } from "react-helmet-async";

interface BlogSEOProps {
  title: string;
  description: string;
  publishDate: string;
  modifiedDate?: string;
  author: string;
  category: string;
  tags: string[];
  slug: string;
  image?: string;
}

export default function BlogSEO({
  title,
  description,
  publishDate,
  modifiedDate,
  author,
  category,
  tags,
  slug,
  image = "/images/blog-default.jpg"
}: BlogSEOProps) {
  const url = `https://resumex.replit.app/blog/${slug}`;
  const imageUrl = image.startsWith("http") ? image : `https://resumex.replit.app${image}`;
  const isoPublishDate = new Date(publishDate).toISOString();
  const isoModifiedDate = modifiedDate ? new Date(modifiedDate).toISOString() : isoPublishDate;

  // Create JSON-LD schema for BlogPosting
  const blogPostingSchema = {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    "headline": title,
    "description": description,
    "image": imageUrl,
    "author": {
      "@type": "Person",
      "name": author
    },
    "publisher": {
      "@type": "Organization",
      "name": "ResumeX",
      "logo": {
        "@type": "ImageObject",
        "url": "https://resumex.replit.app/logo.png"
      }
    },
    "datePublished": isoPublishDate,
    "dateModified": isoModifiedDate,
    "mainEntityOfPage": url,
    "keywords": tags.join(", "),
    "articleSection": category
  };

  // Create breadcrumb schema
  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
      {
        "@type": "ListItem",
        "position": 1,
        "name": "Home",
        "item": "https://resumex.replit.app/"
      },
      {
        "@type": "ListItem",
        "position": 2,
        "name": "Blog",
        "item": "https://resumex.replit.app/blog"
      },
      {
        "@type": "ListItem",
        "position": 3,
        "name": title,
        "item": url
      }
    ]
  };

  return (
    <Helmet>
      {/* Primary Meta Tags */}
      <title>{`${title} | ResumeX Blog`}</title>
      <meta name="description" content={description} />
      <meta name="keywords" content={tags.join(", ")} />
      <link rel="canonical" href={url} />
      
      {/* Open Graph / Facebook */}
      <meta property="og:type" content="article" />
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      <meta property="og:url" content={url} />
      <meta property="og:image" content={imageUrl} />
      <meta property="article:published_time" content={isoPublishDate} />
      <meta property="article:modified_time" content={isoModifiedDate} />
      <meta property="article:section" content={category} />
      {tags.map((tag, index) => (
        <meta key={index} property="article:tag" content={tag} />
      ))}
      
      {/* Twitter */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={title} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={imageUrl} />
      
      {/* Structured Data */}
      <script type="application/ld+json">
        {JSON.stringify(blogPostingSchema)}
      </script>
      <script type="application/ld+json">
        {JSON.stringify(breadcrumbSchema)}
      </script>
    </Helmet>
  );
}