import { XIcon, Check, ArrowRight } from "lucide-react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function UpgradeModal({ isOpen, onClose }: UpgradeModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center" onClick={onClose}>
      <div className="bg-white dark:bg-gray-800 rounded-xl p-8 max-w-md w-full mx-4 shadow-xl" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-start mb-4">
          <h3 className="font-montserrat font-bold text-xl">Unlock Premium Features</h3>
          <button 
            className="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
            onClick={onClose}
            aria-label="Close modal"
          >
            <XIcon className="h-5 w-5" />
          </button>
        </div>
        
        <p className="text-gray-600 dark:text-gray-400 mb-6">
          Upgrade to Pro for just $9.99/month to access premium templates and AI-powered content suggestions.
        </p>
        
        <div className="bg-accent/30 dark:bg-gray-700 p-4 rounded-lg mb-6">
          <div className="flex items-center mb-3">
            <span className="font-medium">What you'll get:</span>
          </div>
          <ul className="space-y-2">
            <li className="flex items-start">
              <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
              <span>10+ premium templates</span>
            </li>
            <li className="flex items-start">
              <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
              <span>AI-powered content suggestions</span>
            </li>
            <li className="flex items-start">
              <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
              <span>Unlimited resume versions</span>
            </li>
            <li className="flex items-start">
              <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
              <span>Priority customer support</span>
            </li>
          </ul>
        </div>
        
        <div className="space-y-4">
          <Button asChild className="w-full bg-gradient-to-r from-secondary to-primary">
            <Link href="/subscribe" onClick={onClose}>
              <span>Subscribe - $9.99/month</span>
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
          
          <Button asChild variant="outline" className="w-full">
            <Link href="/checkout" onClick={onClose}>
              One-time Purchase - $19.99
            </Link>
          </Button>
          
          <Button 
            variant="ghost"
            className="w-full"
            onClick={onClose}
          >
            No Thanks
          </Button>
        </div>
      </div>
    </div>
  );
}
