import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Sparkles, CheckCircle, XCircle, AlertCircle } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

// Props for the component
interface AIEnhanceButtonProps {
  type: 'summary' | 'job-description' | 'skills';
  content: string | string[];
  jobTitle?: string;
  industry?: string;
  onEnhanced: (enhanced: string | string[]) => void;
}

export default function AIEnhanceButton({
  type,
  content,
  jobTitle = '',
  industry = '',
  onEnhanced
}: AIEnhanceButtonProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [original, setOriginal] = useState<string | string[]>(content);
  const [enhanced, setEnhanced] = useState<string | string[]>('');

  const handleEnhance = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      let result;
      
      if (type === 'summary') {
        const response = await apiRequest('POST', '/api/ai/enhance-summary', {
          summary: content,
          context: `Job title: ${jobTitle}${industry ? `, Industry: ${industry}` : ''}`
        });
        const data = await response.json();
        result = data.enhancedSummary;
        setEnhanced(result);
      } 
      else if (type === 'job-description') {
        if (!Array.isArray(content) || !jobTitle) {
          throw new Error('Job descriptions must be an array and job title is required');
        }
        
        const response = await apiRequest('POST', '/api/ai/enhance-job-descriptions', {
          descriptions: content,
          jobTitle
        });
        const data = await response.json();
        result = data.enhancedDescriptions;
        setEnhanced(result);
      } 
      else if (type === 'skills') {
        const existingSkills = Array.isArray(content) ? content : [content];
        
        const response = await apiRequest('POST', '/api/ai/suggest-skills', {
          jobTitle,
          industry,
          existingSkills
        });
        const data = await response.json();
        result = data.suggestedSkills;
        setEnhanced(result);
      }
    } catch (err) {
      console.error('Error enhancing with AI:', err);
      setError('Failed to enhance content. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleApply = () => {
    onEnhanced(enhanced);
    setIsOpen(false);
  };

  const getTitle = () => {
    switch (type) {
      case 'summary':
        return 'Enhance Professional Summary';
      case 'job-description':
        return 'Enhance Job Descriptions';
      case 'skills':
        return 'Suggest Skills';
    }
  };

  const getDescription = () => {
    switch (type) {
      case 'summary':
        return 'AI will improve your professional summary to be more impactful and highlight your key strengths.';
      case 'job-description':
        return 'AI will enhance your job descriptions with strong action verbs and focus on achievements.';
      case 'skills':
        return 'AI will suggest relevant skills based on your job title and experience.';
    }
  };

  return (
    <>
      <Button 
        variant="ghost" 
        size="sm" 
        className="flex items-center gap-1 text-primary" 
        onClick={() => setIsOpen(true)}
      >
        <Sparkles className="h-4 w-4" />
        <span>AI Enhance</span>
      </Button>
      
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>{getTitle()}</DialogTitle>
            <DialogDescription>{getDescription()}</DialogDescription>
          </DialogHeader>
          
          {error && (
            <div className="bg-red-50 p-3 rounded-md flex items-center gap-2 text-red-700 mb-4">
              <AlertCircle className="h-5 w-5" />
              <p>{error}</p>
            </div>
          )}
          
          <div className="my-4">
            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
                <p className="text-sm text-muted-foreground">
                  AI is enhancing your content...
                </p>
              </div>
            ) : (
              <Tabs defaultValue="original">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="original">Original</TabsTrigger>
                  <TabsTrigger value="enhanced" disabled={!enhanced}>Enhanced</TabsTrigger>
                </TabsList>
                <TabsContent value="original" className="mt-4">
                  {type === 'summary' && (
                    <Textarea 
                      readOnly 
                      value={original as string} 
                      className="min-h-[200px]"
                    />
                  )}
                  
                  {(type === 'job-description' || type === 'skills') && (
                    <div className="border p-3 rounded-md min-h-[200px] overflow-y-auto">
                      <ul className="space-y-2">
                        {Array.isArray(original) && original.map((item, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <span className="text-primary">•</span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </TabsContent>
                <TabsContent value="enhanced" className="mt-4">
                  {type === 'summary' && enhanced && (
                    <Textarea 
                      readOnly 
                      value={enhanced as string} 
                      className="min-h-[200px]"
                    />
                  )}
                  
                  {(type === 'job-description' || type === 'skills') && enhanced && (
                    <div className="border p-3 rounded-md min-h-[200px] overflow-y-auto">
                      <ul className="space-y-2">
                        {Array.isArray(enhanced) && enhanced.map((item, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <span className="text-primary">•</span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            )}
          </div>
          
          <DialogFooter className="flex justify-between">
            <Button 
              variant="outline" 
              onClick={() => setIsOpen(false)}
              className="flex items-center gap-1"
              disabled={isLoading}
            >
              <XCircle className="h-4 w-4" />
              Cancel
            </Button>
            
            {!enhanced && !isLoading && (
              <Button 
                onClick={handleEnhance}
                className="flex items-center gap-1"
              >
                <Sparkles className="h-4 w-4" />
                Enhance with AI
              </Button>
            )}
            
            {enhanced && !isLoading && (
              <Button 
                onClick={handleApply}
                className="flex items-center gap-1"
              >
                <CheckCircle className="h-4 w-4" />
                Apply Changes
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}