import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Badge } from "@/components/ui/badge";
import SocialMediaAdCreator from "@/components/SocialMediaAdCreator";
import { Facebook, Instagram, Linkedin, Twitter, Users, BarChart2, PieChart as PieChartIcon, Link, ExternalLink } from "lucide-react";

// Sample campaign data for the dashboard
const campaignData = [
  {
    id: 1,
    name: "Q2_professional_templates",
    platform: "facebook",
    status: "active",
    startDate: "2025-04-01",
    endDate: "2025-06-30",
    budget: 1500,
    spent: 980,
    impressions: 145782,
    clicks: 4283,
    conversions: 215,
    ctr: 2.94,
    cvr: 5.02,
    cpa: 4.56
  },
  {
    id: 2,
    name: "career_changers_q2",
    platform: "linkedin",
    status: "active",
    startDate: "2025-04-15",
    endDate: "2025-06-30",
    budget: 2800,
    spent: 1740,
    impressions: 89230,
    clicks: 3102,
    conversions: 187,
    ctr: 3.48,
    cvr: 6.03,
    cpa: 9.30
  },
  {
    id: 3,
    name: "summer_graduates",
    platform: "instagram",
    status: "scheduled",
    startDate: "2025-05-15",
    endDate: "2025-07-31",
    budget: 2200,
    spent: 0,
    impressions: 0,
    clicks: 0,
    conversions: 0,
    ctr: 0,
    cvr: 0,
    cpa: 0
  },
  {
    id: 4,
    name: "q1_retargeting",
    platform: "facebook",
    status: "completed",
    startDate: "2025-01-01",
    endDate: "2025-03-31",
    budget: 1200,
    spent: 1200,
    impressions: 128450,
    clicks: 4521,
    conversions: 298,
    ctr: 3.52,
    cvr: 6.59,
    cpa: 4.03
  },
  {
    id: 5,
    name: "premium_features_promo",
    platform: "twitter",
    status: "active",
    startDate: "2025-04-01",
    endDate: "2025-05-15",
    budget: 900,
    spent: 620,
    impressions: 75420,
    clicks: 2185,
    conversions: 97,
    ctr: 2.90,
    cvr: 4.44,
    cpa: 6.39
  }
];

// Chart data
const platformData = [
  { name: "Facebook", value: 45, color: "#1877F2" },
  { name: "LinkedIn", value: 30, color: "#0A66C2" },
  { name: "Instagram", value: 15, color: "#E4405F" },
  { name: "Twitter", value: 10, color: "#1DA1F2" }
];

const conversionData = [
  { name: "Facebook", conversions: 513, clicks: 8804, impressions: 274232 },
  { name: "LinkedIn", conversions: 187, clicks: 3102, impressions: 89230 },
  { name: "Instagram", conversions: 92, clicks: 1850, impressions: 67500 },
  { name: "Twitter", conversions: 97, clicks: 2185, impressions: 75420 }
];

const PLATFORM_ICONS = {
  facebook: <Facebook className="h-4 w-4 text-[#1877F2]" />,
  linkedin: <Linkedin className="h-4 w-4 text-[#0A66C2]" />,
  instagram: <Instagram className="h-4 w-4 text-[#E4405F]" />,
  twitter: <Twitter className="h-4 w-4 text-[#1DA1F2]" />
};

const STATUS_BADGES = {
  active: <Badge className="bg-green-500">Active</Badge>,
  paused: <Badge variant="outline" className="text-yellow-500 border-yellow-500">Paused</Badge>,
  scheduled: <Badge variant="outline" className="text-blue-500 border-blue-500">Scheduled</Badge>,
  completed: <Badge variant="outline" className="text-gray-500">Completed</Badge>
};

export default function SocialMediaCampaigns() {
  const [activeTab, setActiveTab] = useState("overview");
  
  // Calculate summary statistics
  const totalImpressions = campaignData.reduce((sum, campaign) => sum + campaign.impressions, 0);
  const totalClicks = campaignData.reduce((sum, campaign) => sum + campaign.clicks, 0);
  const totalConversions = campaignData.reduce((sum, campaign) => sum + campaign.conversions, 0);
  const totalSpent = campaignData.reduce((sum, campaign) => sum + campaign.spent, 0);
  const averageCTR = totalClicks / totalImpressions * 100 || 0;
  const averageCVR = totalConversions / totalClicks * 100 || 0;
  const averageCPA = totalSpent / totalConversions || 0;
  
  // Format numbers for display
  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toLocaleString();
  };
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold tracking-tight">Social Media Campaigns</h2>
        <Button onClick={() => setActiveTab("create")}>Create Campaign</Button>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <BarChart2 className="h-4 w-4" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="campaigns" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Campaigns
          </TabsTrigger>
          <TabsTrigger value="analytics" className="flex items-center gap-2">
            <PieChartIcon className="h-4 w-4" />
            Analytics
          </TabsTrigger>
          <TabsTrigger value="create" className="flex items-center gap-2">
            <Link className="h-4 w-4" />
            Create
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="p-4 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Total Impressions
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                <div className="text-3xl font-bold">{formatNumber(totalImpressions)}</div>
                <p className="text-xs text-muted-foreground mt-1">Across all platforms</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="p-4 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Total Clicks
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                <div className="text-3xl font-bold">{formatNumber(totalClicks)}</div>
                <p className="text-xs text-muted-foreground mt-1">Avg. CTR: {averageCTR.toFixed(2)}%</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="p-4 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Total Conversions
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                <div className="text-3xl font-bold">{formatNumber(totalConversions)}</div>
                <p className="text-xs text-muted-foreground mt-1">Avg. CVR: {averageCVR.toFixed(2)}%</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="p-4 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Total Spend
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                <div className="text-3xl font-bold">${formatNumber(totalSpent)}</div>
                <p className="text-xs text-muted-foreground mt-1">Avg. CPA: ${averageCPA.toFixed(2)}</p>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Campaign Performance</CardTitle>
                <CardDescription>
                  Clicks and conversions by platform
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={conversionData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis yAxisId="left" orientation="left" />
                    <YAxis yAxisId="right" orientation="right" />
                    <Tooltip />
                    <Legend />
                    <Bar yAxisId="left" dataKey="clicks" name="Clicks" fill="#1E40AF" />
                    <Bar yAxisId="right" dataKey="conversions" name="Conversions" fill="#6366F1" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Traffic Distribution</CardTitle>
                <CardDescription>
                  By social platform
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={platformData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={90}
                      paddingAngle={5}
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {platformData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="campaigns" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Active Campaigns</CardTitle>
              <CardDescription>
                All your current and upcoming social media campaigns
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="py-3 px-2 text-left font-medium">Campaign</th>
                      <th className="py-3 px-2 text-left font-medium">Platform</th>
                      <th className="py-3 px-2 text-left font-medium">Status</th>
                      <th className="py-3 px-2 text-left font-medium">Date Range</th>
                      <th className="py-3 px-2 text-right font-medium">Budget</th>
                      <th className="py-3 px-2 text-right font-medium">Spent</th>
                      <th className="py-3 px-2 text-right font-medium">CTR</th>
                      <th className="py-3 px-2 text-right font-medium">CVR</th>
                      <th className="py-3 px-2 text-right font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {campaignData.map((campaign) => (
                      <tr key={campaign.id} className="border-b">
                        <td className="py-3 px-2 font-medium">
                          {campaign.name}
                        </td>
                        <td className="py-3 px-2">
                          <div className="flex items-center">
                            {PLATFORM_ICONS[campaign.platform as keyof typeof PLATFORM_ICONS]}
                            <span className="ml-2">{campaign.platform.charAt(0).toUpperCase() + campaign.platform.slice(1)}</span>
                          </div>
                        </td>
                        <td className="py-3 px-2">
                          {STATUS_BADGES[campaign.status as keyof typeof STATUS_BADGES]}
                        </td>
                        <td className="py-3 px-2 text-muted-foreground">
                          {new Date(campaign.startDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - 
                          {new Date(campaign.endDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                        </td>
                        <td className="py-3 px-2 text-right">
                          ${campaign.budget}
                        </td>
                        <td className="py-3 px-2 text-right">
                          ${campaign.spent}
                        </td>
                        <td className="py-3 px-2 text-right">
                          {campaign.ctr.toFixed(2)}%
                        </td>
                        <td className="py-3 px-2 text-right">
                          {campaign.cvr.toFixed(2)}%
                        </td>
                        <td className="py-3 px-2 text-right">
                          <Button variant="ghost" size="icon" className="h-8 w-8" disabled={campaign.status === 'completed'}>
                            <ExternalLink className="h-4 w-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Conversion Rate by Platform</CardTitle>
                <CardDescription>
                  Performance comparison across social networks
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={conversionData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip 
                      formatter={(value, name) => {
                        if (name === 'Conversion Rate') return `${value}%`;
                        return value;
                      }}
                    />
                    <Legend />
                    <Bar 
                      dataKey={(entry) => (entry.conversions / entry.clicks * 100).toFixed(2)} 
                      name="Conversion Rate" 
                      fill="#4F46E5"
                    />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Cost Per Acquisition</CardTitle>
                <CardDescription>
                  Cost to acquire a user across platforms
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart 
                    data={[
                      { name: "Facebook", cpa: 4.56 },
                      { name: "LinkedIn", cpa: 9.30 },
                      { name: "Instagram", cpa: 5.72 },
                      { name: "Twitter", cpa: 6.39 }
                    ]} 
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip formatter={(value) => `$${value}`} />
                    <Legend />
                    <Bar dataKey="cpa" name="Cost Per Acquisition" fill="#7C3AED" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Campaign ROI Breakdown</CardTitle>
              <CardDescription>
                Return on investment analysis for each campaign
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="py-3 px-2 text-left font-medium">Campaign</th>
                      <th className="py-3 px-2 text-left font-medium">Platform</th>
                      <th className="py-3 px-2 text-right font-medium">Spent</th>
                      <th className="py-3 px-2 text-right font-medium">Conversions</th>
                      <th className="py-3 px-2 text-right font-medium">Cost/Conv.</th>
                      <th className="py-3 px-2 text-right font-medium">Est. Revenue</th>
                      <th className="py-3 px-2 text-right font-medium">ROI</th>
                    </tr>
                  </thead>
                  <tbody>
                    {campaignData.filter(c => c.conversions > 0).map((campaign) => {
                      // Assume $50 average revenue per customer for ROI calculation
                      const avgRevenue = 50;
                      const totalRevenue = campaign.conversions * avgRevenue;
                      const profit = totalRevenue - campaign.spent;
                      const roi = (profit / campaign.spent) * 100;
                      
                      return (
                        <tr key={campaign.id} className="border-b">
                          <td className="py-3 px-2 font-medium">
                            {campaign.name}
                          </td>
                          <td className="py-3 px-2">
                            <div className="flex items-center">
                              {PLATFORM_ICONS[campaign.platform as keyof typeof PLATFORM_ICONS]}
                              <span className="ml-2">{campaign.platform.charAt(0).toUpperCase() + campaign.platform.slice(1)}</span>
                            </div>
                          </td>
                          <td className="py-3 px-2 text-right">
                            ${campaign.spent}
                          </td>
                          <td className="py-3 px-2 text-right">
                            {campaign.conversions}
                          </td>
                          <td className="py-3 px-2 text-right">
                            ${campaign.cpa.toFixed(2)}
                          </td>
                          <td className="py-3 px-2 text-right">
                            ${totalRevenue}
                          </td>
                          <td className="py-3 px-2 text-right">
                            <span className={roi > 0 ? "text-green-500 font-medium" : "text-red-500 font-medium"}>
                              {roi.toFixed(0)}%
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="create">
          <SocialMediaAdCreator />
        </TabsContent>
      </Tabs>
    </div>
  );
}