import { Link } from "wouter";
import { useState } from "react";
import { HelpCircle, LogOut, MenuIcon, User as UserIcon, XIcon } from "lucide-react";
import ThemeToggle from "@/components/ThemeToggle";
import { useAuth } from "@/hooks/use-auth";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, logout } = useAuth();
  
  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const handleLogout = async () => {
    await logout();
  };
  
  // Function to handle smooth scrolling to section IDs
  const scrollToSection = (e: React.MouseEvent<HTMLAnchorElement>, sectionId: string) => {
    e.preventDefault();
    const section = document.getElementById(sectionId);
    if (section) {
      section.scrollIntoView({ behavior: "smooth" });
      setMobileMenuOpen(false); // Close mobile menu if open
    }
  };

  // Get initials for avatar fallback
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase();
  };

  return (
    <header className="sticky top-0 z-50 bg-white dark:bg-gray-800 border-b border-border transition-colors">
      <div className="container mx-auto px-4 h-20 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center space-x-1.5">
          <span className="font-montserrat font-bold text-2xl text-gradient">ResumeX</span>
        </Link>
        
        {/* Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <a href="#features" className="font-medium hover:text-primary transition-colors" onClick={(e) => scrollToSection(e, 'features')}>
            Features
          </a>
          <a href="#templates" className="font-medium hover:text-primary transition-colors" onClick={(e) => scrollToSection(e, 'templates')}>
            Templates
          </a>
          <a href="#pricing" className="font-medium hover:text-primary transition-colors" onClick={(e) => scrollToSection(e, 'pricing')}>
            Pricing
          </a>
          <Link href="/help" className="font-medium hover:text-primary transition-colors">
            Help Center
          </Link>
          {user && (
            <>
              <Link href="/resumes" className="font-medium hover:text-primary transition-colors">
                My Resumes
              </Link>
              <Link href="/career-explorer" className="font-medium hover:text-primary transition-colors">
                Career Explorer
              </Link>
              <Link href="/career-trends" className="font-medium hover:text-primary transition-colors">
                Career Trends
              </Link>
              <Link href="/career-paths" className="font-medium hover:text-primary transition-colors">
                Career Paths
              </Link>
              <Link href="/cover-letter" className="font-medium hover:text-primary transition-colors">
                Cover Letter
              </Link>
            </>
          )}
        </nav>
        
        {/* Right side actions */}
        <div className="flex items-center space-x-5">
          {/* Dark mode toggle */}
          <ThemeToggle />
          
          {/* User account actions */}
          {user ? (
            <>
              {/* Logged in: User menu */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative rounded-full h-8 w-8 p-0">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback>
                        {user.fullName 
                          ? getInitials(user.fullName) 
                          : user.username.substring(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel className="flex items-center justify-between">
                    <span>My Account</span>
                    {user.isPremium && (
                      <span className="inline-flex items-center gap-1 py-0.5 px-2 bg-gradient-to-r from-amber-400 to-amber-500 text-white text-xs font-semibold rounded-full">
                        PREMIUM
                      </span>
                    )}
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/resumes" className="cursor-pointer">
                      <UserIcon className="mr-2 h-4 w-4" />
                      <span>My Resumes</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/career-explorer" className="cursor-pointer">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 h-4 w-4"><path d="M20 7h-3a2 2 0 0 1-2-2V2"/><path d="M9 11v6a2 2 0 0 0 2 2h7"/><path d="M3 5v14a2 2 0 0 0 2 2h5"/><path d="M12 17a2 2 0 1 0 4 0 2 2 0 1 0-4 0Z"/><path d="m14 17 3-3"/><path d="M4 5a2 2 0 1 0 4 0 2 2 0 1 0-4 0Z"/><path d="M6 5 9 2"/></svg>
                      <span>Career Explorer</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/career-trends" className="cursor-pointer">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 h-4 w-4"><path d="m2 12 8 8 12-12"/><path d="m14 8 5.5-5.5a1.5 1.5 0 0 1 2.1 2.1L16.1 10"/><path d="M4 16.5V20a1 1 0 0 0 1 1h3.5"/><path d="M14 12a2 2 0 0 1-2 2"/></svg>
                      <span>Career Trends</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/career-paths" className="cursor-pointer">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 h-4 w-4"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>
                      <span>Career Paths</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/cover-letter" className="cursor-pointer">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 h-4 w-4"><path d="M21 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v3m18 0v8a2 2 0 0 1-2 2h-2M3 8v8a2 2 0 0 0 2 2h2m0-4v4m0-4h14M7 8v4"/></svg>
                      <span>Cover Letter</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/help" className="cursor-pointer">
                      <HelpCircle className="mr-2 h-4 w-4" />
                      <span>Help Center</span>
                    </Link>
                  </DropdownMenuItem>
                  {user.isAdmin && (
                    <DropdownMenuItem asChild>
                      <Link href="/admin" className="cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 h-4 w-4"><path d="M12 4.5a2.5 2.5 0 0 0-4.96-.46 2.5 2.5 0 0 0-1.98 3 2.5 2.5 0 0 0-1.32 4.24 3 3 0 0 0 .34 5.58 2.5 2.5 0 0 0 2.96 3.08A2.5 2.5 0 0 0 12 19.5a2.5 2.5 0 0 0 4.96.44 2.5 2.5 0 0 0 2.96-3.08 3 3 0 0 0 .34-5.58 2.5 2.5 0 0 0-1.32-4.24 2.5 2.5 0 0 0-1.98-3A2.5 2.5 0 0 0 12 4.5Z"/><path d="m15.7 10.4-5.4 5.4-2-2"/></svg>
                        <span>Admin Dashboard</span>
                      </Link>
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem onClick={handleLogout} className="cursor-pointer">
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              
              {/* Create Resume button */}
              <Link href="/builder" className="gradient-btn hidden md:block">
                Create Resume
              </Link>
            </>
          ) : (
            <>
              {/* Not logged in: Login/Register links */}
              <Link href="/auth" className="font-medium text-primary hover:text-primary/80 transition-colors hidden md:block">
                Login
              </Link>
              <Link href="/auth?tab=register" className="gradient-btn hidden md:block">
                Register
              </Link>
            </>
          )}
          
          {/* Mobile menu button */}
          <button 
            className="md:hidden p-2 rounded-lg hover:bg-accent transition-colors"
            onClick={toggleMobileMenu}
            aria-label="Toggle mobile menu"
          >
            {mobileMenuOpen ? (
              <XIcon className="h-6 w-6" />
            ) : (
              <MenuIcon className="h-6 w-6" />
            )}
          </button>
        </div>
      </div>
      
      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white dark:bg-gray-800 shadow-inner border-t border-border">
          <div className="container mx-auto px-4 py-5 flex flex-col space-y-4">
            <a 
              href="#features" 
              className="py-2.5 font-medium hover:text-primary transition-colors"
              onClick={(e) => scrollToSection(e, 'features')}
            >
              Features
            </a>
            <a 
              href="#templates" 
              className="py-2.5 font-medium hover:text-primary transition-colors"
              onClick={(e) => scrollToSection(e, 'templates')}
            >
              Templates
            </a>
            <a 
              href="#pricing" 
              className="py-2.5 font-medium hover:text-primary transition-colors"
              onClick={(e) => scrollToSection(e, 'pricing')}
            >
              Pricing
            </a>
            <Link 
              href="/help" 
              className="py-2.5 font-medium hover:text-primary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              <div className="flex items-center gap-2">
                <HelpCircle className="h-4 w-4" />
                <span>Help Center</span>
              </div>
            </Link>
            
            {user ? (
              <>
                <div className="flex items-center justify-between">
                  <Link 
                    href="/resumes" 
                    className="py-2.5 font-medium hover:text-primary transition-colors"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    My Resumes
                  </Link>
                  {user.isPremium && (
                    <span className="inline-flex items-center gap-1 py-0.5 px-2 bg-gradient-to-r from-amber-400 to-amber-500 text-white text-xs font-semibold rounded-full">
                      PREMIUM
                    </span>
                  )}
                </div>
                
                <Link 
                  href="/career-explorer" 
                  className="py-2.5 font-medium hover:text-primary transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Career Explorer
                </Link>
                <Link 
                  href="/career-trends" 
                  className="py-2.5 font-medium hover:text-primary transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Career Trends
                </Link>
                <Link 
                  href="/career-paths" 
                  className="py-2.5 font-medium hover:text-primary transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Career Paths
                </Link>
                <Link 
                  href="/cover-letter" 
                  className="py-2.5 font-medium hover:text-primary transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Cover Letter Builder
                </Link>
                {user.isAdmin && (
                  <Link 
                    href="/admin" 
                    className="py-2.5 font-medium hover:text-primary transition-colors"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <div className="flex items-center gap-2">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4"><path d="M12 4.5a2.5 2.5 0 0 0-4.96-.46 2.5 2.5 0 0 0-1.98 3 2.5 2.5 0 0 0-1.32 4.24 3 3 0 0 0 .34 5.58 2.5 2.5 0 0 0 2.96 3.08A2.5 2.5 0 0 0 12 19.5a2.5 2.5 0 0 0 4.96.44 2.5 2.5 0 0 0 2.96-3.08 3 3 0 0 0 .34-5.58 2.5 2.5 0 0 0-1.32-4.24 2.5 2.5 0 0 0-1.98-3A2.5 2.5 0 0 0 12 4.5Z"/><path d="m15.7 10.4-5.4 5.4-2-2"/></svg>
                      <span>Admin Dashboard</span>
                    </div>
                  </Link>
                )}
                <Link 
                  href="/builder" 
                  className="gradient-btn text-center mt-4"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Create Resume
                </Link>
                <button 
                  onClick={() => {
                    handleLogout();
                    setMobileMenuOpen(false);
                  }}
                  className="py-2.5 font-medium text-red-500 hover:text-red-700 transition-colors flex items-center"
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log out</span>
                </button>
              </>
            ) : (
              <>
                <Link 
                  href="/auth" 
                  className="py-2.5 font-medium text-primary hover:text-primary/80 transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Login
                </Link>
                <Link 
                  href="/auth?tab=register" 
                  className="gradient-btn text-center mt-4"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Register
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
