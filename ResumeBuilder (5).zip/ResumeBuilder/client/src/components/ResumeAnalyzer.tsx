import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Sparkles, AlertCircle } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { ResumeData } from "@/hooks/use-resume";

interface ResumeAnalyzerProps {
  resumeData: ResumeData;
}

export default function ResumeAnalyzer({ resumeData }: ResumeAnalyzerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<string>('');

  const handleAnalyze = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await apiRequest('POST', '/api/ai/analyze-resume', {
        resumeData
      });
      
      const data = await response.json();
      setAnalysis(data.analysis);
    } catch (err) {
      console.error('Error analyzing resume with AI:', err);
      setError('Failed to analyze resume. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Button 
        variant="outline" 
        className="flex items-center gap-1 text-primary" 
        onClick={() => setIsOpen(true)}
      >
        <Sparkles className="h-4 w-4" />
        <span>AI Resume Analysis</span>
      </Button>
      
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-[700px]">
          <DialogHeader>
            <DialogTitle>AI Resume Analysis</DialogTitle>
            <DialogDescription>
              Get professional feedback and suggestions to improve your resume.
            </DialogDescription>
          </DialogHeader>
          
          {error && (
            <div className="bg-red-50 p-3 rounded-md flex items-center gap-2 text-red-700 mb-4">
              <AlertCircle className="h-5 w-5" />
              <p>{error}</p>
            </div>
          )}
          
          <div className="my-4">
            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
                <p className="text-sm text-muted-foreground">
                  AI is analyzing your resume...
                </p>
              </div>
            ) : analysis ? (
              <div className="border rounded-md p-4 max-h-[400px] overflow-y-auto">
                <div className="prose prose-sm dark:prose-invert">
                  {analysis.split('\n').map((paragraph, index) => (
                    <p key={index}>{paragraph}</p>
                  ))}
                </div>
              </div>
            ) : (
              <div className="bg-slate-50 dark:bg-slate-900 p-6 rounded-md text-center">
                <p className="text-slate-600 dark:text-slate-300 mb-4">
                  Click the button below to get AI-powered analysis and improvement suggestions for your resume.
                </p>
                <ul className="text-left text-sm space-y-2 mb-6 mx-auto max-w-md">
                  <li className="flex items-start gap-2">
                    <span className="text-primary">•</span>
                    <span>Content gaps and weaknesses</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary">•</span>
                    <span>Impact and clarity opportunities</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary">•</span>
                    <span>Format and structure suggestions</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary">•</span>
                    <span>Industry best practices</span>
                  </li>
                </ul>
              </div>
            )}
          </div>
          
          <DialogFooter className="flex justify-between">
            <Button 
              variant="outline" 
              onClick={() => setIsOpen(false)}
            >
              Close
            </Button>
            
            {!analysis && !isLoading && (
              <Button 
                onClick={handleAnalyze}
                className="flex items-center gap-1"
              >
                <Sparkles className="h-4 w-4" />
                Analyze Resume
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}