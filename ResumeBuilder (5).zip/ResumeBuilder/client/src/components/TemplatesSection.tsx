import { useState } from "react";
import UpgradeModal from "./UpgradeModal";
import { templates } from "@/lib/resumeTemplates";
import { Link } from "wouter";
import { Lock, ArrowRight } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { templateImages } from "@/lib/templateImages";

export default function TemplatesSection() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { user } = useAuth();
  
  const handleTemplateClick = (isPremium: boolean) => {
    // If it's a premium template but user doesn't have premium access, show modal
    if (isPremium && (!user || !user.isPremium)) {
      setIsModalOpen(true);
    }
  };

  return (
    <>
      <section id="templates" className="py-24 px-4 bg-accent dark:bg-gray-900 relative overflow-hidden scroll-mt-20">
        {/* Background decorations */}
        <div className="absolute top-40 right-0 w-80 h-80 bg-purple-100 dark:bg-purple-900/20 rounded-full opacity-40 blur-3xl"></div>
        <div className="absolute bottom-20 left-20 w-96 h-96 bg-blue-100 dark:bg-blue-900/20 rounded-full opacity-40 blur-3xl"></div>
        
        <div className="container mx-auto relative z-10">
          <div className="text-center mb-16 max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 py-2 px-4 bg-white dark:bg-gray-800 rounded-full text-primary dark:text-white text-sm font-medium mb-4">
              <span className="flex-shrink-0 w-2 h-2 rounded-full bg-primary"></span>
              <span>Professional Templates</span>
            </div>
            
            <h2 className="font-montserrat font-bold text-3xl md:text-4xl mb-6">
              Choose from <span className="text-gradient">Beautiful Templates</span> That Stand Out
            </h2>
            
            <p className="text-lg text-muted-foreground">
              Each template is expertly designed to pass ATS systems and catch the recruiter's eye
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {templates.map((template) => (
              <div 
                key={template.id}
                className={`card-hover bg-white dark:bg-gray-800 overflow-hidden group ${template.isPremium ? 'relative' : ''}`}
                onClick={() => handleTemplateClick(template.isPremium)}
              >
                <div className="relative h-80 overflow-hidden">
                  <div className={`w-full h-full transition-transform group-hover:scale-105 ${template.isPremium && (!user || !user.isPremium) ? 'filter blur-sm' : ''}`}>
                    {template.thumbnail}
                  </div>
                  <div className={`absolute top-4 left-4 ${template.isPremium ? 'bg-gradient-to-r from-secondary to-primary' : 'bg-gradient-to-r from-emerald-500 to-emerald-600'} text-white text-xs font-medium px-3 py-1.5 rounded-full`}>
                    {template.isPremium ? 'Premium' : 'Free'}
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="font-montserrat font-semibold text-xl mb-2">{template.name}</h3>
                  <p className="text-muted-foreground mb-6">
                    {template.description}
                  </p>
                  {template.isPremium && (!user || !user.isPremium) ? (
                    <button 
                      onClick={() => setIsModalOpen(true)}
                      className="w-full py-3 border border-primary text-primary rounded-lg hover:bg-primary hover:text-white transition-colors flex items-center justify-center gap-2"
                    >
                      <Lock className="w-4 h-4" /> Upgrade to Pro
                    </button>
                  ) : (
                    <Link 
                      href="/builder" 
                      onClick={() => localStorage.setItem('selectedTemplateId', template.id)}
                      className="gradient-btn w-full flex items-center justify-center gap-2"
                    >
                      Use This Template <ArrowRight className="w-4 h-4" />
                    </Link>
                  )}
                </div>
                
                {/* Lock overlay for premium templates - only show if user doesn't have premium */}
                {template.isPremium && (!user || !user.isPremium) && (
                  <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center">
                    <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-xl text-center max-w-xs">
                      <div className="w-16 h-16 rounded-full bg-accent flex items-center justify-center mx-auto mb-4">
                        <Lock className="w-8 h-8 text-primary" />
                      </div>
                      <h4 className="font-semibold text-xl mb-2">Premium Template</h4>
                      <p className="text-muted-foreground mb-6">Unlock all premium templates and features with our Pro plan</p>
                      <button 
                        className="gradient-btn w-full"
                        onClick={(e) => {
                          e.stopPropagation();
                          setIsModalOpen(true);
                        }}
                      >
                        Upgrade Now
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
          
          <div className="mt-16 text-center">
            <Link 
              href="/builder" 
              onClick={() => localStorage.setItem('selectedTemplateId', 'essential')}
              className="gradient-btn inline-flex items-center gap-2"
            >
              <span>Create Your Resume Now</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>
      
      <UpgradeModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </>
  );
}
