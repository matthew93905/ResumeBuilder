import { useState } from 'react';
import { templates } from '@/lib/resumeTemplates';
import React from 'react';

export default function ImageDebugger() {
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  
  return (
    <div className="p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-xl font-bold mb-4">Template Thumbnail Debugger</h2>
      <div className="grid grid-cols-2 gap-4 mb-6">
        {templates.map(template => (
          <div 
            key={template.id} 
            className={`p-4 border rounded-lg cursor-pointer ${selectedTemplate === template.id ? 'border-primary ring-2 ring-primary/50' : 'border-gray-200'}`}
            onClick={() => setSelectedTemplate(template.id)}
          >
            <p className="font-medium mb-2">{template.name}</p>
            <div className="h-40 overflow-hidden border rounded">
              {template.thumbnail}
            </div>
          </div>
        ))}
      </div>
      
      {selectedTemplate && (
        <div className="p-4 bg-gray-50 rounded-lg">
          <h3 className="font-medium mb-2">Selected Template: {selectedTemplate}</h3>
          <p className="text-sm text-gray-500 mb-4">
            This template is rendering with React SVG components instead of image files.
          </p>
          <div className="p-2 bg-white border rounded">
            {templates.find(t => t.id === selectedTemplate)?.thumbnail}
          </div>
        </div>
      )}
    </div>
  );
}