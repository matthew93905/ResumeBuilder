import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Clipboard, Copy, Facebook, Instagram, Linkedin, Twitter } from "lucide-react";
import { toast } from "@/hooks/use-toast";

// Social media platforms with their specific UTM parameters
const platforms = [
  { id: 'facebook', name: 'Facebook', icon: Facebook, color: '#1877F2', utmMedium: 'social', utmSource: 'facebook' },
  { id: 'instagram', name: 'Instagram', icon: Instagram, color: '#E4405F', utmMedium: 'social', utmSource: 'instagram' },
  { id: 'linkedin', name: 'LinkedIn', icon: Linkedin, color: '#0A66C2', utmMedium: 'social', utmSource: 'linkedin' },
  { id: 'twitter', name: 'Twitter', icon: Twitter, color: '#1DA1F2', utmMedium: 'social', utmSource: 'twitter' }
];

// Campaign types
const campaignTypes = [
  { id: 'awareness', name: 'Brand Awareness', description: 'Introducing ResumeX to new audiences' },
  { id: 'conversion', name: 'Conversion', description: 'Getting users to sign up or subscribe' },
  { id: 'retargeting', name: 'Retargeting', description: 'Bringing back users who visited but didn\'t convert' },
  { id: 'feature', name: 'Feature Highlight', description: 'Promoting specific features like AI tools' },
  { id: 'seasonal', name: 'Seasonal', description: 'Graduation, job hunting season, new year, etc.' }
];

// Target audiences
const targetAudiences = [
  { id: 'students', name: 'Students', description: 'College students and recent graduates' },
  { id: 'professionals', name: 'Mid-Career Professionals', description: 'People with 3-10 years experience' },
  { id: 'executives', name: 'Executives', description: 'Senior professionals and executives' },
  { id: 'career_changers', name: 'Career Changers', description: 'People looking to switch industries' },
  { id: 'creators', name: 'Creatives', description: 'Designers, writers, artists and creators' }
];

export default function SocialMediaAdCreator() {
  const [selectedPlatform, setSelectedPlatform] = useState(platforms[0]);
  const [campaignName, setCampaignName] = useState('spring_2025');
  const [campaignType, setCampaignType] = useState('conversion');
  const [audience, setAudience] = useState('professionals');
  const [adContent, setAdContent] = useState({
    headline: 'Create a professional resume in minutes',
    description: 'Stand out with AI-powered templates that get you interviews. Start for free today!',
    cta: 'Get Started'
  });
  
  // Base URL for the landing page
  const baseUrl = window.location.origin || 'https://resumex.replit.app';
  
  // Generate UTM URL based on the current settings
  const generateUtmUrl = () => {
    const platform = platforms.find(p => p.id === selectedPlatform.id) || platforms[0];
    
    const params = new URLSearchParams({
      utm_source: platform.utmSource,
      utm_medium: platform.utmMedium,
      utm_campaign: campaignName,
      utm_content: audience,
      utm_term: campaignType
    });
    
    return `${baseUrl}/social-landing?${params.toString()}`;
  };
  
  const generatedUrl = generateUtmUrl();
  
  // Copy URL to clipboard
  const copyUrl = () => {
    navigator.clipboard.writeText(generatedUrl).then(() => {
      toast({
        title: "URL copied!",
        description: "The campaign URL has been copied to your clipboard."
      });
    });
  };
  
  // Handle platform selection
  const handlePlatformSelect = (platformId: string) => {
    const platform = platforms.find(p => p.id === platformId);
    if (platform) {
      setSelectedPlatform(platform);
    }
  };
  
  // Preview content specific to the selected platform
  const renderPlatformPreview = () => {
    const PlatformIcon = selectedPlatform.icon;
    
    return (
      <div className="border rounded-lg p-4 mt-4">
        <div className="flex items-center space-x-2 mb-4">
          <PlatformIcon className="h-5 w-5" style={{ color: selectedPlatform.color }} />
          <span className="font-medium">Preview for {selectedPlatform.name}</span>
        </div>
        
        <div className="space-y-3">
          <div className="font-semibold">{adContent.headline}</div>
          <div className="text-sm text-muted-foreground">{adContent.description}</div>
          <div 
            className="text-sm font-medium px-3 py-1 rounded-full text-white inline-block"
            style={{ backgroundColor: selectedPlatform.color }}
          >
            {adContent.cta}
          </div>
        </div>
      </div>
    );
  };
  
  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle>Social Media Campaign Creator</CardTitle>
        <CardDescription>
          Create targeted social media campaigns with proper tracking
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <Tabs defaultValue="campaign" className="w-full">
          <TabsList className="grid grid-cols-3 mb-6">
            <TabsTrigger value="campaign">Campaign Settings</TabsTrigger>
            <TabsTrigger value="content">Ad Content</TabsTrigger>
            <TabsTrigger value="tracking">Tracking URL</TabsTrigger>
          </TabsList>
          
          <TabsContent value="campaign" className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="platform">Platform</Label>
              <div className="grid grid-cols-4 gap-2">
                {platforms.map((platform) => {
                  const PlatformIcon = platform.icon;
                  const isSelected = platform.id === selectedPlatform.id;
                  
                  return (
                    <Button
                      key={platform.id}
                      variant={isSelected ? "default" : "outline"}
                      className="flex-col h-20 space-y-1"
                      onClick={() => handlePlatformSelect(platform.id)}
                    >
                      <PlatformIcon className="h-5 w-5" />
                      <span>{platform.name}</span>
                    </Button>
                  );
                })}
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="campaign-name">Campaign Name</Label>
              <Input
                id="campaign-name"
                value={campaignName}
                onChange={(e) => setCampaignName(e.target.value)}
                placeholder="e.g., spring_2025"
              />
              <p className="text-xs text-muted-foreground">
                Use a descriptive name with underscores instead of spaces
              </p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="campaign-type">Campaign Type</Label>
              <Select value={campaignType} onValueChange={setCampaignType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select campaign type" />
                </SelectTrigger>
                <SelectContent>
                  {campaignTypes.map((type) => (
                    <SelectItem key={type.id} value={type.id}>
                      {type.name} - {type.description}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="audience">Target Audience</Label>
              <Select value={audience} onValueChange={setAudience}>
                <SelectTrigger>
                  <SelectValue placeholder="Select target audience" />
                </SelectTrigger>
                <SelectContent>
                  {targetAudiences.map((audienceType) => (
                    <SelectItem key={audienceType.id} value={audienceType.id}>
                      {audienceType.name} - {audienceType.description}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </TabsContent>
          
          <TabsContent value="content" className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="headline">Headline</Label>
              <Input
                id="headline"
                value={adContent.headline}
                onChange={(e) => setAdContent({...adContent, headline: e.target.value})}
                placeholder="Main headline for your ad"
                maxLength={80}
              />
              <p className="text-xs text-muted-foreground">
                {adContent.headline.length}/80 characters
              </p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={adContent.description}
                onChange={(e) => setAdContent({...adContent, description: e.target.value})}
                placeholder="Compelling description for your ad"
                maxLength={200}
              />
              <p className="text-xs text-muted-foreground">
                {adContent.description.length}/200 characters
              </p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="cta">Call to Action</Label>
              <Input
                id="cta"
                value={adContent.cta}
                onChange={(e) => setAdContent({...adContent, cta: e.target.value})}
                placeholder="e.g., Sign Up, Learn More, Get Started"
                maxLength={25}
              />
              <p className="text-xs text-muted-foreground">
                {adContent.cta.length}/25 characters
              </p>
            </div>
            
            {renderPlatformPreview()}
          </TabsContent>
          
          <TabsContent value="tracking" className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="tracking-url">Campaign URL with UTM Parameters</Label>
              <div className="flex gap-2">
                <Input
                  id="tracking-url"
                  value={generatedUrl}
                  readOnly
                  className="font-mono text-sm"
                />
                <Button variant="outline" size="icon" onClick={copyUrl}>
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                This URL includes tracking parameters for campaign attribution
              </p>
            </div>
            
            <div className="bg-muted/50 p-4 rounded-lg">
              <h3 className="font-medium mb-2">URL Breakdown</h3>
              <ul className="space-y-2 text-sm">
                <li><span className="font-mono">utm_source:</span> {selectedPlatform.utmSource} (the platform)</li>
                <li><span className="font-mono">utm_medium:</span> {selectedPlatform.utmMedium} (marketing channel)</li>
                <li><span className="font-mono">utm_campaign:</span> {campaignName} (campaign identifier)</li>
                <li><span className="font-mono">utm_content:</span> {audience} (target audience)</li>
                <li><span className="font-mono">utm_term:</span> {campaignType} (campaign goal)</li>
              </ul>
            </div>
            
            <div className="bg-primary/10 p-4 rounded-lg border border-primary/20">
              <div className="flex gap-2 items-start">
                <Clipboard className="h-5 w-5 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-medium text-primary">Ready to use</h3>
                  <p className="text-sm">
                    Your campaign URL is ready to use in your {selectedPlatform.name} ads. Our tracking system 
                    will automatically capture this data when users visit the landing page.
                  </p>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      
      <CardFooter className="border-t p-6 flex justify-end">
        <Button onClick={copyUrl}>
          Copy Campaign URL
          <Copy className="h-4 w-4 ml-2" />
        </Button>
      </CardFooter>
    </Card>
  );
}