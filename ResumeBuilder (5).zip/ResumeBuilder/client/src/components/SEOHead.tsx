import { Helmet } from "react-helmet-async";

interface SEOHeadProps {
  title?: string;
  description?: string;
  keywords?: string;
  canonicalUrl?: string;
  ogType?: string;
  ogTitle?: string;
  ogDescription?: string;
  ogImage?: string;
}

export default function SEOHead({
  title = "ResumeX - Build a Professional Resume in Minutes | Best Resume Builder 2025",
  description = "Create a professional resume with ResumeX, the #1 resume builder. Choose from premium templates, customize with AI-powered content, and export to PDF instantly. Get hired faster with ResumeX.",
  keywords = "resume builder, best resume builder, cv builder, professional resume, job application, career, resume templates, AI resume, free resume builder, 2025 resume builder",
  canonicalUrl = typeof window !== "undefined" ? window.location.href : "",
  ogType = "website",
  ogTitle,
  ogDescription,
  ogImage = "/og-image.jpg",
}: SEOHeadProps) {
  // Use provided OG values or fall back to defaults
  const finalOgTitle = ogTitle || title;
  const finalOgDescription = ogDescription || description;

  return (
    <Helmet>
      {/* Primary Meta Tags */}
      <title>{title}</title>
      <meta name="description" content={description} />
      <meta name="keywords" content={keywords} />
      
      {/* Canonical Link */}
      <link rel="canonical" href={canonicalUrl} />
      
      {/* Open Graph / Facebook */}
      <meta property="og:type" content={ogType} />
      <meta property="og:title" content={finalOgTitle} />
      <meta property="og:description" content={finalOgDescription} />
      <meta property="og:url" content={canonicalUrl} />
      <meta property="og:image" content={ogImage} />
      
      {/* Twitter */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={finalOgTitle} />
      <meta name="twitter:description" content={finalOgDescription} />
      <meta name="twitter:image" content={ogImage} />
      
      {/* Additional SEO optimization */}
      <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <meta name="author" content="ResumeX" />
      <meta name="google-site-verification" content="your-verification-code-here" />

      {/* Localization */}
      <meta property="og:locale" content="en_US" />
      <link rel="alternate" hrefLang="en" href={canonicalUrl} />
      
      {/* Mobile optimization */}
      <meta name="format-detection" content="telephone=no" />
      <meta name="apple-mobile-web-app-capable" content="yes" />
      <meta name="apple-mobile-web-app-status-bar-style" content="black" />
      
      {/* Performance optimization hints */}
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
      <link rel="dns-prefetch" href="https://fonts.googleapis.com" />
    </Helmet>
  );
}