import { useState, useEffect, useRef } from 'react';
import { useTheme } from '@/hooks/use-theme';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Play, Pause, RefreshCw } from 'lucide-react';

// Types for career path visualization
export type CareerNode = {
  id: string;
  title: string;
  level: number; // 1-5 for junior to executive
  salary: string;
  skills: string[];
  description: string;
  timeframe: string; // e.g. "1-2 years", "3-5 years"
  isCurrentRole?: boolean;
};

export type CareerPath = {
  id: string;
  name: string;
  description: string;
  nodes: CareerNode[];
};

type CareerPathVisualizationProps = {
  paths: CareerPath[];
  initialPath?: string; // ID of the initially selected path
};

// Constants for visualization layout
const LEVEL_LABELS = ['Entry', 'Junior', 'Mid', 'Senior', 'Lead'];
const NODE_COLORS = [
  'from-blue-500 to-blue-700',
  'from-purple-500 to-purple-700',
  'from-indigo-500 to-indigo-700',
  'from-green-500 to-green-700',
  'from-amber-500 to-amber-700',
];

export default function CareerPathVisualization({ 
  paths, 
  initialPath 
}: CareerPathVisualizationProps) {
  const { theme } = useTheme();
  const [selectedPathId, setSelectedPathId] = useState<string>(initialPath || (paths[0]?.id || ''));
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentNodeIndex, setCurrentNodeIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const animationRef = useRef<number>();
  
  // Get the selected path
  const selectedPath = paths.find(p => p.id === selectedPathId) || paths[0];
  
  // Handle animation frame updates
  useEffect(() => {
    if (isPlaying && selectedPath) {
      const startAnimation = () => {
        setIsAnimating(true);
        animationRef.current = window.setTimeout(() => {
          if (currentNodeIndex < selectedPath.nodes.length - 1) {
            setCurrentNodeIndex(prev => prev + 1);
          } else {
            setIsPlaying(false);
            setIsAnimating(false);
          }
        }, 2000); // 2-second interval between node transitions
      };
      
      startAnimation();
    }
    
    return () => {
      if (animationRef.current) {
        clearTimeout(animationRef.current);
      }
    };
  }, [isPlaying, currentNodeIndex, selectedPath]);
  
  // Reset animation when path changes
  useEffect(() => {
    setCurrentNodeIndex(0);
    setIsPlaying(false);
    setIsAnimating(false);
    
    if (animationRef.current) {
      clearTimeout(animationRef.current);
    }
  }, [selectedPathId]);
  
  // Toggle animation playback
  const togglePlayback = () => {
    setIsPlaying(prev => !prev);
  };
  
  // Reset animation
  const resetAnimation = () => {
    setCurrentNodeIndex(0);
    setIsPlaying(false);
    setIsAnimating(false);
    
    if (animationRef.current) {
      clearTimeout(animationRef.current);
    }
  };
  
  // Jump to specific node
  const jumpToNode = (index: number) => {
    setCurrentNodeIndex(index);
    setIsPlaying(false);
    setIsAnimating(false);
    
    if (animationRef.current) {
      clearTimeout(animationRef.current);
    }
  };
  
  if (!selectedPath) {
    return <div>No career paths available</div>;
  }
  
  return (
    <div className="w-full space-y-6">
      {/* Path selector */}
      <div className="flex flex-wrap gap-2">
        {paths.map((path, index) => (
          <Button
            key={path.id}
            variant={selectedPathId === path.id ? "default" : "outline"}
            className={selectedPathId === path.id ? `bg-gradient-to-r ${NODE_COLORS[index % NODE_COLORS.length]}` : ""}
            onClick={() => setSelectedPathId(path.id)}
          >
            {path.name}
          </Button>
        ))}
      </div>
      
      {/* Path description */}
      <div className="text-sm text-muted-foreground">
        {selectedPath.description}
      </div>
      
      {/* Visualization controls */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={togglePlayback}
            className="h-8 w-8"
          >
            {isPlaying ? <Pause size={16} /> : <Play size={16} />}
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={resetAnimation}
            className="h-8 w-8"
          >
            <RefreshCw size={16} />
          </Button>
        </div>
        <div className="text-sm text-muted-foreground">
          {currentNodeIndex + 1} of {selectedPath.nodes.length} positions
        </div>
      </div>
      
      {/* Career path visualization */}
      <div className="relative min-h-[400px] w-full border rounded-lg p-6 bg-background">
        {/* Career level indicators */}
        <div className="absolute left-0 top-0 bottom-0 w-24 flex flex-col justify-between p-6 border-r">
          {LEVEL_LABELS.map((label, index) => (
            <div 
              key={label} 
              className="text-xs font-medium text-muted-foreground"
              style={{ top: `${(index * 100) / (LEVEL_LABELS.length - 1)}%` }}
            >
              {label}
            </div>
          ))}
        </div>
        
        {/* Career path track */}
        <div className="absolute left-24 right-0 top-0 bottom-0">
          <div className="relative h-full ml-10">
            {/* Vertical track line */}
            <div className="absolute left-0 top-6 bottom-6 w-0.5 bg-muted" />
            
            {/* Career nodes */}
            {selectedPath.nodes.map((node, index) => {
              const nodeTop = 100 - ((node.level - 1) * 100) / (LEVEL_LABELS.length - 1);
              const isActive = index <= currentNodeIndex;
              const isCurrent = index === currentNodeIndex;
              
              return (
                <motion.div
                  key={node.id}
                  className="absolute left-0 min-w-max"
                  style={{ top: `${nodeTop}%` }}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ 
                    opacity: isActive ? 1 : 0.5, 
                    x: isActive ? 0 : -10,
                    scale: isCurrent ? 1.05 : 1
                  }}
                  transition={{ duration: 0.5 }}
                >
                  {/* Node point */}
                  <div className="relative flex">
                    <div 
                      className={`h-4 w-4 rounded-full -ml-2 mt-3 ${
                        isActive 
                          ? `bg-gradient-to-r ${NODE_COLORS[index % NODE_COLORS.length]}` 
                          : 'bg-muted'
                      }`}
                    />
                    
                    {/* Node connector */}
                    {index > 0 && (
                      <motion.div 
                        className={`absolute h-0.5 -left-10 top-[10px] ${
                          isActive 
                            ? `bg-gradient-to-r ${NODE_COLORS[index % NODE_COLORS.length]}` 
                            : 'bg-muted'
                        }`}
                        initial={{ width: 0 }}
                        animate={{ width: isActive ? 10 : 0 }}
                        transition={{ duration: 0.5 }}
                      />
                    )}
                    
                    {/* Node content */}
                    <motion.div
                      className={`ml-4 cursor-pointer`}
                      onClick={() => jumpToNode(index)}
                      whileHover={{ scale: 1.02 }}
                    >
                      <Card className={`w-[300px] shadow-md ${
                        isCurrent 
                          ? 'border-primary ring-1 ring-primary/30' 
                          : isActive 
                            ? 'border-primary/50' 
                            : ''
                      }`}>
                        <CardContent className="p-4 space-y-3">
                          <div className="flex justify-between items-start">
                            <h3 className="font-semibold">{node.title}</h3>
                            {node.isCurrentRole && (
                              <Badge variant="secondary">Current</Badge>
                            )}
                          </div>
                          
                          <div className="text-sm">
                            <div className="font-medium text-primary">{node.salary}</div>
                            <div className="text-muted-foreground">{node.timeframe}</div>
                          </div>
                          
                          <div className="flex flex-wrap gap-1">
                            {node.skills.slice(0, 3).map(skill => (
                              <Badge key={skill} variant="outline" className="bg-primary/5">
                                {skill}
                              </Badge>
                            ))}
                            {node.skills.length > 3 && (
                              <Badge variant="outline">+{node.skills.length - 3}</Badge>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
      
      {/* Current position details */}
      {selectedPath.nodes[currentNodeIndex] && (
        <Card className="bg-muted/30">
          <CardContent className="p-6 space-y-4">
            <div className="flex flex-wrap justify-between items-start gap-4">
              <div>
                <h3 className="text-xl font-bold">{selectedPath.nodes[currentNodeIndex].title}</h3>
                <p className="text-muted-foreground">
                  {selectedPath.nodes[currentNodeIndex].timeframe} progression
                </p>
              </div>
              <div className="text-right">
                <div className="text-lg font-semibold">{selectedPath.nodes[currentNodeIndex].salary}</div>
                <div className="text-sm text-muted-foreground">Typical salary range</div>
              </div>
            </div>
            
            <p>{selectedPath.nodes[currentNodeIndex].description}</p>
            
            <div>
              <h4 className="text-sm font-semibold mb-2">Key skills</h4>
              <div className="flex flex-wrap gap-1">
                {selectedPath.nodes[currentNodeIndex].skills.map(skill => (
                  <Badge key={skill} variant="secondary">
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}