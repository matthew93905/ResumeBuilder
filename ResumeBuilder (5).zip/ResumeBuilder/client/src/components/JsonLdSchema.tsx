import { Helmet } from "react-helmet-async";

interface JsonLdSchemaProps {
  schema: Record<string, any> | Array<Record<string, any>>;
}

/**
 * Generic component for adding JSON-LD structured data to any page
 * @param schema JSON-LD schema object or array of schema objects
 */
export default function JsonLdSchema({ schema }: JsonLdSchemaProps) {
  return (
    <Helmet>
      <script type="application/ld+json">
        {JSON.stringify(schema)}
      </script>
    </Helmet>
  );
}