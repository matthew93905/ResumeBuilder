import { useState } from "react";
import { Button } from "@/components/ui/button";
import { templates } from "@/lib/resumeTemplates";
import { useLocation } from "wouter";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function TestTemplateButton() {
  const [open, setOpen] = useState(false);
  const [, navigate] = useLocation();
  
  return (
    <>
      <div className="flex flex-col gap-4 items-center">
        <Button onClick={() => setOpen(true)} variant="outline" className="px-6">
          View Templates
        </Button>
        
        <Button 
          onClick={() => navigate("/builder")} 
          className="bg-gradient-to-r from-secondary to-primary text-white px-8"
        >
          Create Your Resume Now
        </Button>
      </div>
      
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-5xl">
          <DialogHeader>
            <DialogTitle>Choose a Resume Template</DialogTitle>
            <DialogDescription>
              Select a template to start with in the resume builder
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 my-6">
            {templates.map(template => (
              <div 
                key={template.id} 
                className="border rounded-lg overflow-hidden cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => {
                  console.log("Selected template:", template.id);
                  // Store the selected template in localStorage
                  localStorage.setItem('selectedTemplateId', template.id);
                  // Navigate to the builder page
                  navigate("/builder");
                }}
              >
                <div className="relative h-40 bg-accent/10 flex items-center justify-center">
                  <div className="text-xl font-medium text-center">
                    {template.name} Template
                  </div>
                  <span className={`absolute top-2 right-2 text-xs px-2 py-1 rounded-full ${
                    template.isPremium ? 'bg-purple-100 text-purple-700' : 'bg-green-100 text-green-700'
                  }`}>
                    {template.isPremium ? 'Premium' : 'Free'}
                  </span>
                </div>
                <div className="p-4">
                  <h4 className="font-semibold text-lg">{template.name}</h4>
                  <p className="text-sm text-muted-foreground mt-1">{template.description}</p>
                </div>
              </div>
            ))}
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>
              Close
            </Button>
            <Button onClick={() => navigate("/builder")}>
              Go to Builder
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}