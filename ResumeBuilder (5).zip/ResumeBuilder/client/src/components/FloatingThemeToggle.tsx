import { useState, useEffect } from "react";
import { SunIcon, MoonIcon } from "lucide-react";
import { useTheme } from "@/hooks/use-theme";

export default function FloatingThemeToggle() {
  const { theme, toggleTheme } = useTheme();
  const [isVisible, setIsVisible] = useState(false);
  const [isMounted, setIsMounted] = useState(false);
  
  // Avoid hydration mismatch by only rendering after component mounts
  useEffect(() => {
    setIsMounted(true);
    
    // Show floating toggle when user scrolls down
    const handleScroll = () => {
      const scrollY = window.scrollY;
      const showThreshold = 350; // Show after scrolling down 350px
      
      setIsVisible(scrollY > showThreshold);
    };
    
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  if (!isMounted) {
    return null;
  }

  return (
    <div 
      className={`fixed bottom-6 right-6 z-40 transition-all duration-500 ${
        isVisible 
          ? 'translate-y-0 opacity-100' 
          : 'translate-y-10 opacity-0 pointer-events-none'
      }`}
    >
      <button
        onClick={toggleTheme}
        className={`flex items-center justify-center w-12 h-12 rounded-full shadow-lg ${
          theme === 'dark' 
            ? 'bg-gray-800 text-yellow-300 hover:bg-gray-700' 
            : 'bg-white text-blue-600 hover:bg-blue-50'
        } transition-colors duration-300`}
        aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
      >
        {theme === 'dark' ? (
          <SunIcon className="h-6 w-6" />
        ) : (
          <MoonIcon className="h-6 w-6" />
        )}
      </button>
    </div>
  );
}