import { Link } from "wouter";
import { ArrowRight } from "lucide-react";

export default function CallToAction() {
  return (
    <section className="py-24 px-4 bg-gradient-to-r from-secondary to-primary text-white relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute top-1/2 left-1/4 w-64 h-64 bg-white/10 rounded-full mix-blend-overlay blur-xl"></div>
      <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-white/10 rounded-full mix-blend-overlay blur-xl"></div>
      
      <div className="container mx-auto relative z-10">
        <div className="max-w-4xl mx-auto">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="md:w-2/3 text-center md:text-left">
              <h2 className="font-montserrat font-bold text-3xl md:text-4xl leading-tight mb-6">
                Ready to Create Your Professional Resume and Land Your Dream Job?
              </h2>
              <p className="text-xl text-white/80 mb-8 md:pr-12">
                Join thousands of job seekers who have successfully landed interviews with resumes built using ResumeX
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
                <Link href="/builder" className="flex items-center justify-center gap-2 px-8 py-3 bg-white text-primary font-medium rounded-lg shadow-lg hover:shadow-xl transition-all">
                  <span>Create Resume Now</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
                <Link href="/#templates" className="flex items-center justify-center gap-2 px-8 py-3 bg-white/20 backdrop-blur-sm text-white font-medium rounded-lg hover:bg-white/30 transition-all">
                  <span>Explore Templates</span>
                </Link>
              </div>
            </div>
            
            <div className="md:w-1/3 hidden md:block">
              <div className="relative">
                <div className="w-full h-64 bg-white/20 rounded-2xl backdrop-blur-sm flex items-center justify-center overflow-hidden">
                  <div className="absolute inset-0 bg-dots-pattern opacity-20"></div>
                  <div className="transform -rotate-12">
                    <div className="w-60 h-60 bg-white/30 rounded-xl flex items-center justify-center">
                      <div className="w-48 h-48 bg-white/50 rounded-lg flex items-center justify-center">
                        <div className="bg-white rounded-md shadow-lg px-4 py-6 text-center">
                          <div className="text-primary font-bold text-xl">ResumeX</div>
                          <div className="text-gray-700 text-sm mt-1">Professional Builder</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
