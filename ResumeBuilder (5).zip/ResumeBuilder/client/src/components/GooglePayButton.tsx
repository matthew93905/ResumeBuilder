import React, { useEffect, useState } from 'react';

interface GooglePayButtonProps {
  amount: string;
  onSuccess?: (paymentData: any) => void;
  onError?: (error: Error) => void;
}

declare global {
  interface Window {
    google?: {
      payments: {
        api: {
          PaymentsClient: new (config: any) => any;
        }
      }
    }
  }
}

export default function GooglePayButton({ amount, onSuccess, onError }: GooglePayButtonProps) {
  const [paymentsClient, setPaymentsClient] = useState<any>(null);
  const [buttonVisible, setButtonVisible] = useState(false);

  useEffect(() => {
    const loadGooglePayScript = () => {
      if (document.querySelector('script[src="https://pay.google.com/gp/p/js/pay.js"]')) {
        initializeGooglePay();
        return;
      }

      const script = document.createElement('script');
      script.src = 'https://pay.google.com/gp/p/js/pay.js';
      script.onload = initializeGooglePay;
      script.onerror = () => console.error('Failed to load Google Pay script');
      document.head.appendChild(script);
    };

    loadGooglePayScript();
  }, []);

  const initializeGooglePay = () => {
    if (!window.google) {
      console.error('Google Pay API not available');
      return;
    }

    const client = new window.google.payments.api.PaymentsClient({
      environment: 'TEST', // Change to 'PRODUCTION' for live environment
    });

    setPaymentsClient(client);

    const isReadyToPayRequest = {
      apiVersion: 2,
      apiVersionMinor: 0,
      allowedPaymentMethods: [
        {
          type: 'CARD',
          parameters: {
            allowedAuthMethods: ['PAN_ONLY', 'CRYPTOGRAM_3DS'],
            allowedCardNetworks: ['MASTERCARD', 'VISA'],
          },
        },
      ],
    };

    client
      .isReadyToPay(isReadyToPayRequest)
      .then((response: { result: boolean }) => {
        if (response.result) {
          setButtonVisible(true);
        }
      })
      .catch((err: Error) => {
        console.error('Google Pay client initialization error', err);
        if (onError) onError(err);
      });
  };

  const createPaymentRequest = () => {
    return {
      apiVersion: 2,
      apiVersionMinor: 0,
      allowedPaymentMethods: [
        {
          type: 'CARD',
          parameters: {
            allowedAuthMethods: ['PAN_ONLY', 'CRYPTOGRAM_3DS'],
            allowedCardNetworks: ['MASTERCARD', 'VISA', 'AMEX', 'DISCOVER'],
          },
          tokenizationSpecification: {
            type: 'PAYMENT_GATEWAY',
            parameters: {
              gateway: 'stripe', // Replace with your payment gateway
              'stripe:version': '2020-08-27',
              'stripe:publishableKey': import.meta.env.VITE_STRIPE_PUBLIC_KEY as string,
            },
          },
        },
      ],
      merchantInfo: {
        merchantId: '12345678901234567890', // Replace with your Google merchant ID
        merchantName: 'ResumeX',
      },
      transactionInfo: {
        totalPriceStatus: 'FINAL',
        totalPriceLabel: 'Total',
        totalPrice: amount,
        currencyCode: 'USD',
        countryCode: 'US',
      },
    };
  };

  const handlePayment = () => {
    if (!paymentsClient) return;

    const paymentRequest = createPaymentRequest();
    
    paymentsClient
      .loadPaymentData(paymentRequest)
      .then((paymentData: any) => {
        console.log('Google Pay payment success', paymentData);
        if (onSuccess) onSuccess(paymentData);
        
        // Here you would process the payment with your backend
        // sendPaymentDataToProcessor(paymentData);
      })
      .catch((err: any) => {
        console.error('Google Pay payment error', err);
        if (onError) onError(err);
      });
  };

  if (!buttonVisible) return null;

  return (
    <div className="mt-2 mb-2">
      <button
        onClick={handlePayment}
        className="w-full bg-white border border-gray-300 text-gray-800 py-2.5 px-4 rounded-md flex items-center justify-center cursor-pointer hover:bg-gray-50 transition-colors font-medium"
      >
        <div className="flex items-center justify-center">
          <svg width="20" height="20" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg" className="mr-2">
            <path fill="#4285F4" d="M24.12 21.52V27h-12V21.52H24.12z"/>
            <path fill="#34A853" d="M24.12 13v6.52h-12V13h12z"/>
            <path fill="#FBBC04" d="M24.12 27v7H12.12v-7h12z"/>
            <path fill="#EA4335" d="M24.12 13v14h7V13h-7z"/>
          </svg>
          <span>Pay with Google Pay</span>
        </div>
      </button>
    </div>
  );
}