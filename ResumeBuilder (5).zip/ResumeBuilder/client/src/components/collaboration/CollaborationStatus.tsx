import { AlertCircle, Users, Wifi, WifiOff } from 'lucide-react';
import { useWebSocket } from '@/hooks/use-websocket';
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useAuth } from '@/hooks/use-auth';

export function CollaborationStatus() {
  const { user } = useAuth();
  const { connected, connectionError, activeCollaborators } = useWebSocket();
  
  // Don't count current user in the collaborator count
  const otherCollaborators = activeCollaborators.filter(c => c.userId !== user?.id);
  
  // Helper to get initials for avatar
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };
  
  return (
    <div className="flex items-center gap-2">
      {/* Connection status */}
      <Tooltip>
        <TooltipTrigger asChild>
          <div className="flex items-center">
            {connected ? (
              <Wifi className="h-4 w-4 text-green-500" />
            ) : (
              <WifiOff className="h-4 w-4 text-destructive" />
            )}
          </div>
        </TooltipTrigger>
        <TooltipContent>
          {connected 
            ? 'Connected to collaboration server' 
            : connectionError || 'Disconnected from collaboration server'}
        </TooltipContent>
      </Tooltip>
      
      {/* Active collaborators */}
      <Popover>
        <PopoverTrigger asChild>
          <div className="flex items-center gap-1 cursor-pointer">
            <Users className="h-4 w-4" />
            <Badge variant="outline" className="px-1.5 h-5">
              {otherCollaborators.length}
            </Badge>
          </div>
        </PopoverTrigger>
        <PopoverContent className="w-60 p-2">
          <div className="text-sm font-medium mb-2">Active collaborators</div>
          {otherCollaborators.length === 0 ? (
            <div className="text-sm text-muted-foreground py-1">
              No other users currently editing
            </div>
          ) : (
            <div className="space-y-1">
              {otherCollaborators.map(collaborator => (
                <div key={collaborator.userId} className="flex items-center gap-2 p-1 rounded hover:bg-muted">
                  <Avatar className="h-6 w-6">
                    <AvatarFallback className="text-xs">
                      {getInitials(collaborator.username)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 text-sm">
                    {collaborator.username}
                  </div>
                  <Badge variant="secondary" className="text-xs px-1.5 h-5">
                    {collaborator.role}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </PopoverContent>
      </Popover>
      
      {/* Error indicator */}
      {connectionError && (
        <Tooltip>
          <TooltipTrigger asChild>
            <AlertCircle className="h-4 w-4 text-destructive" />
          </TooltipTrigger>
          <TooltipContent>
            {connectionError}
          </TooltipContent>
        </Tooltip>
      )}
    </div>
  );
}