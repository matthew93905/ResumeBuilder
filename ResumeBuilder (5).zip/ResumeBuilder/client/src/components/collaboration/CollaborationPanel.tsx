import { useState } from 'react';
import {
  useCollaborators,
  useAddCollaborator,
  useUpdateCollaboratorRole,
  useRemoveCollaborator,
  useInviteCollaborator,
  useInvitations,
  useDeleteInvitation,
  CollaboratorWithUser,
  Invitation
} from '@/hooks/use-collaboration';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  ShieldCheckIcon, 
  EyeIcon, 
  PencilIcon, 
  UserPlusIcon, 
  MailIcon, 
  ClockIcon,
  TrashIcon,
  CheckCircleIcon,
  XCircleIcon
} from 'lucide-react';
import { format } from 'date-fns';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/use-auth';

// Helper function to get role badges with icons
const RoleBadge = ({ role }: { role: string }) => {
  switch(role) {
    case 'owner':
      return (
        <div className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium rounded-full bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200">
          <ShieldCheckIcon size={12} />
          <span>Owner</span>
        </div>
      );
    case 'editor':
      return (
        <div className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium rounded-full bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200">
          <PencilIcon size={12} />
          <span>Editor</span>
        </div>
      );
    case 'viewer':
      return (
        <div className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium rounded-full bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-200">
          <EyeIcon size={12} />
          <span>Viewer</span>
        </div>
      );
    default:
      return (
        <div className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium rounded-full bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200">
          <span>{role}</span>
        </div>
      );
  }
};

export default function CollaborationPanel({ resumeId }: { resumeId: number | null }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('collaborators');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showInviteDialog, setShowInviteDialog] = useState(false);
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('viewer');
  
  // Queries
  const collaboratorsQuery = useCollaborators(resumeId);
  const invitationsQuery = useInvitations(resumeId);
  
  // Mutations
  const addCollaboratorMutation = useAddCollaborator();
  const updateRoleMutation = useUpdateCollaboratorRole();
  const removeCollaboratorMutation = useRemoveCollaborator();
  const inviteCollaboratorMutation = useInviteCollaborator();
  const deleteInvitationMutation = useDeleteInvitation();
  
  // Handlers
  const handleAddCollaborator = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !role) {
      toast({
        title: 'Missing information',
        description: 'Please provide a username and role',
        variant: 'destructive',
      });
      return;
    }
    
    try {
      if (!resumeId) {
        toast({
          title: 'Error',
          description: 'Resume ID is missing',
          variant: 'destructive',
        });
        return;
      }
      await addCollaboratorMutation.mutateAsync({ resumeId, username, role });
      setUsername('');
      setRole('viewer');
      setShowAddDialog(false);
    } catch (error) {
      // Error is handled by the mutation
    }
  };
  
  const handleInviteCollaborator = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !role) {
      toast({
        title: 'Missing information',
        description: 'Please provide an email and role',
        variant: 'destructive',
      });
      return;
    }
    
    try {
      if (!resumeId) {
        toast({
          title: 'Error',
          description: 'Resume ID is missing',
          variant: 'destructive',
        });
        return;
      }
      await inviteCollaboratorMutation.mutateAsync({ resumeId, email, role });
      setEmail('');
      setRole('viewer');
      setShowInviteDialog(false);
    } catch (error) {
      // Error is handled by the mutation
    }
  };
  
  const handleUpdateRole = async (id: number, newRole: string) => {
    if (!resumeId) return;
    await updateRoleMutation.mutateAsync({ id, role: newRole, resumeId });
  };
  
  const handleRemoveCollaborator = async (id: number) => {
    if (!resumeId) return;
    await removeCollaboratorMutation.mutateAsync({ id, resumeId });
  };
  
  const handleDeleteInvitation = async (id: number) => {
    if (!resumeId) return;
    await deleteInvitationMutation.mutateAsync({ id, resumeId });
  };
  
  // Loading states
  if (collaboratorsQuery.isLoading || invitationsQuery.isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Collaboration</CardTitle>
          <CardDescription>Loading collaboration info...</CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center py-6">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
        </CardContent>
      </Card>
    );
  }
  
  // Error states
  if (collaboratorsQuery.isError || invitationsQuery.isError) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Collaboration</CardTitle>
          <CardDescription>Error loading collaboration information</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-destructive">
            {collaboratorsQuery.error?.message || invitationsQuery.error?.message || "Something went wrong"}
          </p>
          <Button 
            variant="outline" 
            className="mt-4"
            onClick={() => {
              collaboratorsQuery.refetch();
              invitationsQuery.refetch();
            }}
          >
            Try again
          </Button>
        </CardContent>
      </Card>
    );
  }
  
  const collaborators = collaboratorsQuery.data || [];
  const invitations = invitationsQuery.data || [];
  const isOwner = collaborators.some((c: CollaboratorWithUser) => 
    c.userId === user?.id && c.role === 'owner'
  ) || false;
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Collaboration</span>
          {isOwner && (
            <div className="flex gap-2">
              <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" className="gap-1.5">
                    <UserPlusIcon size={14} />
                    <span>Add</span>
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add Collaborator</DialogTitle>
                    <DialogDescription>
                      Add an existing user to collaborate on this resume
                    </DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleAddCollaborator}>
                    <div className="grid gap-4 py-4">
                      <div className="grid gap-2">
                        <Label htmlFor="username">Username</Label>
                        <Input
                          id="username"
                          placeholder="Enter username"
                          value={username}
                          onChange={(e) => setUsername(e.target.value)}
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="role">Role</Label>
                        <Select value={role} onValueChange={setRole}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a role" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="editor">Editor</SelectItem>
                            <SelectItem value="viewer">Viewer</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button 
                        type="submit" 
                        disabled={addCollaboratorMutation.isPending}
                      >
                        {addCollaboratorMutation.isPending ? 'Adding...' : 'Add Collaborator'}
                      </Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
              
              <Dialog open={showInviteDialog} onOpenChange={setShowInviteDialog}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" className="gap-1.5">
                    <MailIcon size={14} />
                    <span>Invite</span>
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Invite by Email</DialogTitle>
                    <DialogDescription>
                      Send an invitation to collaborate on this resume
                    </DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleInviteCollaborator}>
                    <div className="grid gap-4 py-4">
                      <div className="grid gap-2">
                        <Label htmlFor="email">Email</Label>
                        <Input
                          id="email"
                          type="email"
                          placeholder="Enter email address"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="invite-role">Role</Label>
                        <Select value={role} onValueChange={setRole}>
                          <SelectTrigger id="invite-role">
                            <SelectValue placeholder="Select a role" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="editor">Editor</SelectItem>
                            <SelectItem value="viewer">Viewer</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button 
                        type="submit" 
                        disabled={inviteCollaboratorMutation.isPending}
                      >
                        {inviteCollaboratorMutation.isPending ? 'Sending...' : 'Send Invitation'}
                      </Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
          )}
        </CardTitle>
        <CardDescription>
          Manage collaborators and invitations for this resume
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="collaborators" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="w-full mb-4">
            <TabsTrigger value="collaborators" className="flex-1">
              Collaborators ({collaborators.length})
            </TabsTrigger>
            {isOwner && (
              <TabsTrigger value="invitations" className="flex-1">
                Invitations ({invitations.length})
              </TabsTrigger>
            )}
          </TabsList>
          
          <TabsContent value="collaborators">
            {collaborators.length === 0 ? (
              <div className="text-center py-6 text-muted-foreground">
                No collaborators yet
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Role</TableHead>
                    {isOwner && <TableHead className="text-right">Actions</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {collaborators.map((collaborator: CollaboratorWithUser) => (
                    <TableRow key={collaborator.id}>
                      <TableCell>
                        <div className="font-medium">{collaborator.user?.username || 'Unknown'}</div>
                        <div className="text-xs text-muted-foreground">{collaborator.user?.email || ''}</div>
                      </TableCell>
                      <TableCell>
                        <RoleBadge role={collaborator.role} />
                      </TableCell>
                      {isOwner && (
                        <TableCell className="text-right">
                          {/* Can't modify owner role or own role */}
                          {collaborator.role !== 'owner' && collaborator.userId !== user?.id && (
                            <div className="flex justify-end items-center gap-2">
                              <Select 
                                value={collaborator.role} 
                                onValueChange={(value) => handleUpdateRole(collaborator.id, value)}
                                disabled={updateRoleMutation.isPending}
                              >
                                <SelectTrigger className="w-24 h-8">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="editor">Editor</SelectItem>
                                  <SelectItem value="viewer">Viewer</SelectItem>
                                </SelectContent>
                              </Select>
                              
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 text-destructive"
                                onClick={() => handleRemoveCollaborator(collaborator.id)}
                                disabled={removeCollaboratorMutation.isPending}
                              >
                                <TrashIcon size={16} />
                              </Button>
                            </div>
                          )}
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </TabsContent>
          
          {isOwner && (
            <TabsContent value="invitations">
              {invitations.length === 0 ? (
                <div className="text-center py-6 text-muted-foreground">
                  No pending invitations
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Email</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {invitations.map((invitation: Invitation) => (
                      <TableRow key={invitation.id}>
                        <TableCell>
                          <div className="font-medium">{invitation.email}</div>
                          <div className="text-xs text-muted-foreground flex items-center gap-1">
                            <ClockIcon size={12} />
                            <span>Sent {format(new Date(invitation.createdAt), 'MMM d, yyyy')}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <RoleBadge role={invitation.role} />
                        </TableCell>
                        <TableCell>
                          {invitation.accepted ? (
                            <div className="inline-flex items-center gap-1 text-green-600 dark:text-green-400">
                              <CheckCircleIcon size={14} />
                              <span>Accepted</span>
                            </div>
                          ) : (
                            <div className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400">
                              <ClockIcon size={14} />
                              <span>Pending</span>
                            </div>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-destructive"
                            onClick={() => handleDeleteInvitation(invitation.id)}
                            disabled={deleteInvitationMutation.isPending}
                          >
                            <TrashIcon size={16} />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </TabsContent>
          )}
        </Tabs>
      </CardContent>
    </Card>
  );
}