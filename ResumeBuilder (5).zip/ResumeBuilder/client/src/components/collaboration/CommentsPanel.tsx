import { useState } from 'react';
import {
  useComments,
  useAddComment,
  useResolveComment,
  useDeleteComment,
  CommentWithUser
} from '@/hooks/use-collaboration';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useAuth } from '@/hooks/use-auth';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  MoreVerticalIcon, 
  CheckCircleIcon, 
  CircleIcon, 
  TrashIcon,
  SendIcon,
  MessageSquareIcon
} from 'lucide-react';
import { format } from 'date-fns';
import { useToast } from '@/hooks/use-toast';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

export default function CommentsPanel({ resumeId }: { resumeId: number | null }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('all');
  const [commentText, setCommentText] = useState('');
  const [currentSection, setCurrentSection] = useState<string | null>(null);
  
  // Queries and mutations
  const commentsQuery = useComments(resumeId);
  const addCommentMutation = useAddComment();
  const resolveCommentMutation = useResolveComment();
  const deleteCommentMutation = useDeleteComment();
  
  // Handlers
  const handleAddComment = async () => {
    if (!commentText.trim()) {
      toast({
        title: 'Empty comment',
        description: 'Please enter a comment',
        variant: 'destructive',
      });
      return;
    }
    
    try {
      if (!resumeId) {
        toast({
          title: 'Error',
          description: 'Resume ID is missing',
          variant: 'destructive',
        });
        return;
      }
      await addCommentMutation.mutateAsync({
        resumeId,
        content: commentText,
        section: currentSection || undefined
      });
      setCommentText('');
    } catch (error) {
      // Error is handled by the mutation
    }
  };
  
  const handleResolveComment = async (id: number, resolved: boolean) => {
    if (!resumeId) return;
    await resolveCommentMutation.mutateAsync({ id, resolved, resumeId });
  };
  
  const handleDeleteComment = async (id: number) => {
    if (!resumeId) return;
    await deleteCommentMutation.mutateAsync({ id, resumeId });
  };
  
  // Loading and error states
  if (commentsQuery.isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Comments</CardTitle>
          <CardDescription>Loading comments...</CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center py-6">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
        </CardContent>
      </Card>
    );
  }
  
  if (commentsQuery.isError) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Comments</CardTitle>
          <CardDescription>Error loading comments</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-destructive">
            {commentsQuery.error?.message || "Something went wrong"}
          </p>
          <Button 
            variant="outline" 
            className="mt-4"
            onClick={() => commentsQuery.refetch()}
          >
            Try again
          </Button>
        </CardContent>
      </Card>
    );
  }
  
  const comments = commentsQuery.data || [];
  const openComments = comments.filter((c: CommentWithUser) => !c.resolved);
  const resolvedComments = comments.filter((c: CommentWithUser) => c.resolved);
  
  // Helper to get initials for avatar
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };
  
  // Filter comments based on active tab
  const filteredComments = 
    activeTab === 'all' ? comments : 
    activeTab === 'open' ? openComments : 
    resolvedComments;
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Comments</span>
          <span className="text-sm font-normal text-muted-foreground">
            {openComments.length} open
          </span>
        </CardTitle>
        <CardDescription>
          Feedback and suggestions from collaborators
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Comment input */}
        <div className="flex space-x-2">
          <Textarea
            placeholder="Add a comment..."
            value={commentText}
            onChange={(e) => setCommentText(e.target.value)}
            className="resize-none"
          />
          <Button 
            size="icon" 
            onClick={handleAddComment}
            disabled={addCommentMutation.isPending}
          >
            {addCommentMutation.isPending ? (
              <div className="h-4 w-4 animate-spin rounded-full border-2 border-background border-t-transparent" />
            ) : (
              <SendIcon size={16} />
            )}
          </Button>
        </div>
        
        {/* Comments list */}
        <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="w-full mb-4">
            <TabsTrigger value="all" className="flex-1">
              All ({comments.length})
            </TabsTrigger>
            <TabsTrigger value="open" className="flex-1">
              Open ({openComments.length})
            </TabsTrigger>
            <TabsTrigger value="resolved" className="flex-1">
              Resolved ({resolvedComments.length})
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value={activeTab}>
            {filteredComments.length === 0 ? (
              <div className="text-center py-6 text-muted-foreground flex flex-col items-center gap-2">
                <MessageSquareIcon className="h-8 w-8 opacity-50" />
                <p>No comments yet</p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredComments.map((comment: CommentWithUser) => (
                  <div 
                    key={comment.id} 
                    className={`p-4 rounded-lg border ${
                      comment.resolved ? 'bg-muted/50' : 'bg-card'
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex gap-3">
                        <Avatar className="h-8 w-8">
                          <AvatarFallback>
                            {comment.user?.username ? 
                              getInitials(comment.user.username) : 'U'}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium">
                            {comment.user?.username || 'Unknown'}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {format(new Date(comment.createdAt), 'MMM d, yyyy • h:mm a')}
                          </div>
                        </div>
                      </div>
                      
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreVerticalIcon size={14} />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem 
                            onClick={() => handleResolveComment(comment.id, !comment.resolved)}
                          >
                            {comment.resolved ? (
                              <>
                                <CircleIcon size={14} className="mr-2" />
                                <span>Reopen</span>
                              </>
                            ) : (
                              <>
                                <CheckCircleIcon size={14} className="mr-2" />
                                <span>Resolve</span>
                              </>
                            )}
                          </DropdownMenuItem>
                          
                          {comment.userId === user?.id && (
                            <DropdownMenuItem 
                              onClick={() => handleDeleteComment(comment.id)}
                              className="text-destructive"
                            >
                              <TrashIcon size={14} className="mr-2" />
                              <span>Delete</span>
                            </DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                    
                    <div className="mt-2 text-sm">
                      {comment.content}
                    </div>
                    
                    {comment.section && (
                      <div className="mt-2 text-xs inline-flex items-center px-2 py-1 rounded-full bg-muted text-muted-foreground">
                        <span>Section: {comment.section}</span>
                      </div>
                    )}
                    
                    {comment.resolved && (
                      <div className="mt-2 flex items-center gap-1 text-xs text-green-600">
                        <CheckCircleIcon size={12} />
                        <span>Resolved</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}