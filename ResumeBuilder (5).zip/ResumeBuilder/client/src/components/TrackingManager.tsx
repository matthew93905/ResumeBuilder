import { useEffect } from 'react';
import { useLocation } from 'wouter';

/**
 * TrackingManager component handles the processing of tracking parameters
 * from URLs, stores them in localStorage, and ensures they're properly 
 * utilized for analytics while being excluded from canonical URLs.
 */
export default function TrackingManager() {
  const [location] = useLocation();

  useEffect(() => {
    if (typeof window === 'undefined') return;

    // Parse URL parameters
    const url = new URL(window.location.href);
    const params = url.searchParams;
    
    // Track UTM parameters
    const utmParams = {
      utm_source: params.get('utm_source'),
      utm_medium: params.get('utm_medium'),
      utm_campaign: params.get('utm_campaign'),
      utm_term: params.get('utm_term'),
      utm_content: params.get('utm_content'),
      utm_id: params.get('utm_id')
    };
    
    // Track referral sources
    const referralParams = {
      source: params.get('source'),
      ref: params.get('ref'),
      referral: params.get('referral'),
      affiliate_id: params.get('affiliate_id'),
      partner: params.get('partner')
    };
    
    // Track platform-specific click IDs
    const clickIdParams = {
      fbclid: params.get('fbclid'),       // Facebook
      gclid: params.get('gclid'),         // Google Ads
      msclkid: params.get('msclkid'),     // Microsoft/Bing
      ttclid: params.get('ttclid'),       // TikTok
      twclid: params.get('twclid'),       // Twitter/X
      igshid: params.get('igshid')        // Instagram
    };
    
    // Store in localStorage for session persistence
    // Only if actual parameters exist - filter out nulls
    const storeParams = (paramObj: Record<string, string | null>, storageKey: string) => {
      const filteredParams = Object.fromEntries(
        Object.entries(paramObj).filter(([_, value]) => value !== null)
      );
      
      if (Object.keys(filteredParams).length > 0) {
        localStorage.setItem(storageKey, JSON.stringify(filteredParams));
      }
    };
    
    storeParams(utmParams, 'resumex_utm_params');
    storeParams(referralParams, 'resumex_referral_params');
    storeParams(clickIdParams, 'resumex_click_ids');
    
    // Record first touch attribution if it doesn't exist yet
    if (!localStorage.getItem('resumex_first_touch')) {
      const firstTouch = {
        timestamp: new Date().toISOString(),
        landing_page: window.location.href,
        referrer: document.referrer || 'direct',
        ...utmParams,
        ...referralParams
      };
      
      localStorage.setItem('resumex_first_touch', JSON.stringify(firstTouch));
    }
    
    // Record last touch attribution (always updates)
    const lastTouch = {
      timestamp: new Date().toISOString(),
      landing_page: window.location.href,
      referrer: document.referrer || 'direct',
      ...utmParams,
      ...referralParams
    };
    
    localStorage.setItem('resumex_last_touch', JSON.stringify(lastTouch));
    
    // Optionally clear parameters from URL if desired
    // (disabled by default as it affects browser navigation)
    /*
    if (Object.values(utmParams).some(val => val !== null) || 
        Object.values(clickIdParams).some(val => val !== null)) {
      // Create clean URL without tracking parameters
      const cleanUrl = new URL(window.location.href);
      [...Object.keys(utmParams), ...Object.keys(clickIdParams)].forEach(param => {
        cleanUrl.searchParams.delete(param);
      });
      
      // Update browser history without reloading page
      window.history.replaceState({}, document.title, cleanUrl.toString());
    }
    */
  }, [location]);

  // This component doesn't render anything
  return null;
}