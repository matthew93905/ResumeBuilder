import { Eye, LayoutTemplate, Download, Clock4, CheckCircle2, StarIcon } from "lucide-react";

export default function FeaturesSection() {
  return (
    <section id="features" className="py-24 px-4 bg-white dark:bg-gray-800">
      <div className="container mx-auto">
        <div className="text-center mb-16 max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 py-2 px-4 bg-accent dark:bg-gray-700 rounded-full text-primary dark:text-white text-sm font-medium mb-4">
            <span className="flex-shrink-0 w-2 h-2 rounded-full bg-primary"></span>
            <span>Powerful Features</span>
          </div>
          
          <h2 className="font-montserrat font-bold text-3xl md:text-4xl mb-6">
            Everything You Need to <span className="text-gradient">Craft the Perfect Resume</span>
          </h2>
          
          <p className="text-lg text-muted-foreground">
            Our intuitive platform makes building professional resumes easier than ever with these powerful features
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Feature 1 */}
          <div className="feature-card group">
            <div className="feature-icon">
              <Eye className="w-5 h-5" />
            </div>
            <h3 className="text-xl font-semibold mb-3 group-hover:text-primary transition-colors">Real-time Preview</h3>
            <p className="text-muted-foreground">
              See changes instantly as you type. Our WYSIWYG editor ensures what you see is exactly what employers will receive.
            </p>
          </div>
          
          {/* Feature 2 */}
          <div className="feature-card group">
            <div className="feature-icon">
              <LayoutTemplate className="w-5 h-5" />
            </div>
            <h3 className="text-xl font-semibold mb-3 group-hover:text-primary transition-colors">Premium Templates</h3>
            <p className="text-muted-foreground">
              Choose from a variety of ATS-friendly templates designed to impress recruiters across all industries.
            </p>
          </div>
          
          {/* Feature 3 */}
          <div className="feature-card group">
            <div className="feature-icon">
              <Download className="w-5 h-5" />
            </div>
            <h3 className="text-xl font-semibold mb-3 group-hover:text-primary transition-colors">Easy Export</h3>
            <p className="text-muted-foreground">
              Download your finished resume as a professional PDF with a single click, ready to send to employers.
            </p>
          </div>

          {/* Feature 4 */}
          <div className="feature-card group">
            <div className="feature-icon">
              <Clock4 className="w-5 h-5" />
            </div>
            <h3 className="text-xl font-semibold mb-3 group-hover:text-primary transition-colors">Time-Saving Tools</h3>
            <p className="text-muted-foreground">
              Create a professional resume in under 15 minutes with our streamlined process and intuitive interface.
            </p>
          </div>
          
          {/* Feature 5 */}
          <div className="feature-card group">
            <div className="feature-icon">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <h3 className="text-xl font-semibold mb-3 group-hover:text-primary transition-colors">ATS Optimization</h3>
            <p className="text-muted-foreground">
              All templates are optimized to pass through Applicant Tracking Systems that employers use to screen resumes.
            </p>
          </div>
          
          {/* Feature 6 */}
          <div className="feature-card group">
            <div className="feature-icon">
              <StarIcon className="w-5 h-5" />
            </div>
            <h3 className="text-xl font-semibold mb-3 group-hover:text-primary transition-colors">Expert Designed</h3>
            <p className="text-muted-foreground">
              Templates created by resume experts and HR professionals who know what recruiters are looking for.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
