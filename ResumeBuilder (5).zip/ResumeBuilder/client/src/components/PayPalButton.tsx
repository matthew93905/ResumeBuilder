// !!! CRITICAL - DO NOT MODIFY THIS CODE !!!
//
// This code MUST be used as is without ANY modifications.
// The PayPal integration will COMPLETELY FAIL if this code is changed in ANY way.
//
// Retain this comment after all edits.
//
// <BEGIN_EXACT_CODE>
import React, { useEffect } from "react";

declare global {
  namespace JSX {
    interface IntrinsicElements {
      "paypal-button": React.DetailedHTMLProps<
        React.HTMLAttributes<HTMLElement>,
        HTMLElement
      >;
    }
  }
}

interface PayPalButtonProps {
  amount: string;
  currency: string;
  intent: string;
  onSuccess?: (data: any) => void;
}

export default function PayPalButton({
  amount,
  currency,
  intent,
  onSuccess,
}: PayPalButtonProps) {
  const createOrder = async () => {
    const orderPayload = {
      amount: amount,
      currency: currency,
      intent: intent,
    };
    const response = await fetch("/api/paypal/order", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(orderPayload),
    });
    const output = await response.json();
    return { orderId: output.id };
  };

  const captureOrder = async (orderId: string) => {
    const response = await fetch(`/api/paypal/order/${orderId}/capture`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    });
    const data = await response.json();

    return data;
  };

  const onApprove = async (data: any) => {
    console.log("onApprove", data);
    const orderData = await captureOrder(data.orderId);
    console.log("Capture result", orderData);
    if (onSuccess) {
      onSuccess(orderData);
    }
  };

  const onCancel = async (data: any) => {
    console.log("onCancel", data);
  };

  const onError = async (data: any) => {
    console.log("onError", data);
  };

  useEffect(() => {
    const loadPayPalSDK = async () => {
      try {
        if (!(window as any).paypal) {
          const script = document.createElement("script");
          script.src = import.meta.env.PROD
            ? "https://www.paypal.com/web-sdk/v6/core"
            : "https://www.sandbox.paypal.com/web-sdk/v6/core";
          script.async = true;
          script.onload = () => initPayPal();
          document.body.appendChild(script);
        } else {
          await initPayPal();
        }
      } catch (e) {
        console.error("Failed to load PayPal SDK", e);
      }
    };

    loadPayPalSDK();
  }, []);
  
  const initPayPal = async () => {
    try {
      const clientToken: string = await fetch("/api/paypal/setup")
        .then((res) => res.json())
        .then((data) => {
          return data.clientToken;
        });
      const sdkInstance = await (window as any).paypal.createInstance({
        clientToken,
        components: ["paypal-payments"],
      });

      const paypalCheckout =
            sdkInstance.createPayPalOneTimePaymentSession({
              onApprove,
              onCancel,
              onError,
            });

      const onClick = async () => {
        try {
          const checkoutOptionsPromise = createOrder();
          await paypalCheckout.start(
            { paymentFlow: "auto" },
            checkoutOptionsPromise,
          );
        } catch (e) {
          console.error(e);
        }
      };

      const paypalButton = document.getElementById("paypal-button");

      if (paypalButton) {
        paypalButton.addEventListener("click", onClick);
      }

      return () => {
        if (paypalButton) {
          paypalButton.removeEventListener("click", onClick);
        }
      };
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="mt-2 mb-2">
      <paypal-button id="paypal-button" className="w-full bg-[#0070ba] text-white py-2.5 px-4 rounded-md flex items-center justify-center cursor-pointer hover:bg-[#003087] transition-colors font-medium">
        <div className="flex items-center">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="#ffffff" className="mr-2">
            <path d="M20.924 7.625a5.2 5.2 0 0 0-1.847-1.275 8.018 8.018 0 0 0-3.292-.55H8.7c-.363.01-.718.103-1.033.273a1.564 1.564 0 0 0-.726 1.218L5.176 18.96c-.043.293.054.589.267.8.213.212.51.317.806.29h3.71c.3.004.59-.104.811-.297a1.066 1.066 0 0 0 .324-.788l.124-.937.386-2.513.226-1.514c.027-.19.154-.364.337-.463a.906.906 0 0 1 .563-.163h1.47a8.966 8.966 0 0 0 5.856-1.976 5.365 5.365 0 0 0 1.624-2.922 4.405 4.405 0 0 0-.626-3.865v.003z" />
            <path d="M19.086 7.814c.047.28.07.565.07.851a5.694 5.694 0 0 1-1.588 3.996 8.598 8.598 0 0 1-5.164 1.907h-1.48c-.35 0-.686.134-.927.375-.24.24-.37.565-.357.9l.622 4.03.175 1.156c.034.237.173.452.386.6.214.147.478.212.74.18h2.821c.421.02.834-.124 1.148-.4.315-.275.5-.664.515-1.076l.013-.227.274-1.767.017-.207c.014-.413.199-.803.514-1.078.314-.276.727-.42 1.148-.4h.726c3.096 0 5.52-.9 6.24-3.5.301-1.099.229-2.018-.349-2.67a2.81 2.81 0 0 0-.751-.77z" />
            <path d="M18.834 7.331a7.776 7.776 0 0 0-1.227-.238 12.406 12.406 0 0 0-1.9-.142H9.7c-.297-.01-.587.087-.813.27a1.056 1.056 0 0 0-.352.783l-.878 5.614-.026.17c-.013.414.133.818.407 1.129.274.311.66.492 1.069.505h2.93c.213.005.426-.012.636-.05a2.26 2.26 0 0 0 .619-.208 1.45 1.45 0 0 0 .537-.449c.136-.195.22-.423.242-.66l.401-2.574c.017-.128.076-.247.168-.339a.457.457 0 0 1 .332-.146h.561c2.416 0 4.322-.558 5.02-2.404.063-.163.115-.33.156-.5.165-.644.122-1.291-.04-1.76v-.001z" />
          </svg>
          <span>Pay with PayPal</span>
        </div>
      </paypal-button>
    </div>
  );
}
// <END_EXACT_CODE>