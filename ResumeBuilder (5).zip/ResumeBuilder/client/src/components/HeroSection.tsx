import { Link } from "wouter";
import { FileText, CheckCircle, ArrowRight, LogOut } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

export default function HeroSection() {
  const { user, logout } = useAuth();
  
  const handleLogout = async () => {
    await logout();
  };
  
  const scrollToTemplates = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    const templatesSection = document.getElementById("templates");
    if (templatesSection) {
      templatesSection.scrollIntoView({ behavior: "smooth" });
    }
  };
  return (
    <section className="py-20 md:py-32 px-4 bg-white dark:bg-gray-800 overflow-hidden relative">
      {/* Background decorations */}
      <div className="absolute -top-20 -right-20 w-80 h-80 bg-accent rounded-full opacity-50 blur-3xl"></div>
      <div className="absolute -bottom-32 -left-32 w-96 h-96 bg-purple-100 dark:bg-purple-900/20 rounded-full opacity-50 blur-3xl"></div>
      
      <div className="container mx-auto relative z-10">
        {/* Only show logout button if user is logged in */}
        {user && (
          <div className="flex justify-end mb-8">
            <button 
              onClick={handleLogout}
              className="flex items-center gap-2 px-5 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-all duration-300"
            >
              <LogOut className="w-4 h-4" />
              <span>Logout</span>
            </button>
          </div>
        )}
        
        <div className="flex flex-col md:flex-row items-center justify-between gap-16">
          {/* Hero content */}
          <div className="md:w-1/2 space-y-8">
            <div className="inline-flex items-center gap-2 py-2 px-4 bg-accent dark:bg-gray-700 rounded-full text-primary dark:text-white text-sm font-medium mb-4">
              <span className="flex-shrink-0 w-2 h-2 rounded-full bg-primary"></span>
              <span>Resume Builder v2.0 is here!</span>
            </div>
            
            <h1 className="font-montserrat font-bold text-4xl md:text-6xl leading-tight">
              Create <span className="text-gradient">Professional</span> Resumes in Minutes
            </h1>
            
            <p className="text-lg text-muted-foreground md:pr-10">
              Craft standout resumes that get you hired. Choose from premium templates, customize with ease, and export to PDF instantly.
            </p>
            
            <div className="pt-4 flex flex-col sm:flex-row gap-5">
              <Link href="/builder" className="gradient-btn inline-flex items-center gap-2">
                <span>Create Resume</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
              
              <a 
                href="#templates" 
                onClick={scrollToTemplates}
                className="inline-flex items-center justify-center px-5 py-3 border border-border rounded-lg text-foreground hover:bg-accent hover:border-primary transition-all duration-300"
              >
                Explore Templates
              </a>
            </div>
            
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 sm:gap-8 pt-4">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <CheckCircle className="w-5 h-5 text-primary" />
                <span>No credit card required</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <CheckCircle className="w-5 h-5 text-primary" />
                <span>ATS-friendly templates</span>
              </div>
            </div>
          </div>
          
          {/* Hero image */}
          <div className="md:w-1/2">
            <div className="relative">
              {/* Modern document illustration */}
              <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl p-6 border border-border relative z-10">
                <div className="flex items-start gap-4 mb-6">
                  <div className="w-20 h-20 bg-accent rounded-xl flex items-center justify-center">
                    <FileText className="w-10 h-10 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="h-5 w-40 bg-accent dark:bg-gray-700 rounded-md mb-2"></div>
                    <div className="h-4 w-full bg-muted dark:bg-gray-700 rounded-md"></div>
                  </div>
                </div>
                
                <div className="space-y-3 mb-6">
                  <div className="h-4 w-full bg-muted dark:bg-gray-700 rounded-md"></div>
                  <div className="h-4 w-11/12 bg-muted dark:bg-gray-700 rounded-md"></div>
                  <div className="h-4 w-10/12 bg-muted dark:bg-gray-700 rounded-md"></div>
                </div>
                
                <div className="h-5 w-32 bg-primary rounded-md mb-3"></div>
                
                <div className="space-y-3 mb-6">
                  <div className="h-4 w-full bg-muted dark:bg-gray-700 rounded-md"></div>
                  <div className="h-4 w-11/12 bg-muted dark:bg-gray-700 rounded-md"></div>
                  <div className="h-4 w-10/12 bg-muted dark:bg-gray-700 rounded-md"></div>
                </div>
                
                <div className="flex flex-wrap gap-2">
                  <div className="h-8 w-20 bg-secondary/20 dark:bg-secondary/40 rounded-md"></div>
                  <div className="h-8 w-24 bg-secondary/20 dark:bg-secondary/40 rounded-md"></div>
                  <div className="h-8 w-16 bg-secondary/20 dark:bg-secondary/40 rounded-md"></div>
                </div>
              </div>
              
              {/* Decorative elements */}
              <div className="absolute top-1/2 -right-10 transform -translate-y-1/2 w-20 h-20 bg-secondary/20 rounded-full blur-xl"></div>
              <div className="absolute -bottom-8 left-16 w-16 h-16 bg-primary/20 rounded-full blur-xl"></div>
              <div className="absolute -top-10 left-20 w-24 h-24 bg-purple/20 rounded-full blur-xl"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
